import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { Crown, RotateCcw, Trophy, Flag, ChevronLeft, Volume2, VolumeX, Music, Music2, User, BarChart3, LogOut, Plus, Settings, X, Lightbulb, AlertTriangle } from "lucide-react";

// ============================================================
// CHESS ENGINE
// ============================================================

const PIECES = {
  wK: "♔", wQ: "♕", wR: "♖", wB: "♗", wN: "♘", wP: "♙",
  bK: "♚", bQ: "♛", bR: "♜", bB: "♝", bN: "♞", bP: "♟",
};

const PIECE_VALUES = { P: 100, N: 320, B: 330, R: 500, Q: 900, K: 20000 };

const PST = {
  P: [
    [ 0,  0,  0,  0,  0,  0,  0,  0],
    [50, 50, 50, 50, 50, 50, 50, 50],
    [10, 10, 20, 30, 30, 20, 10, 10],
    [ 5,  5, 10, 25, 25, 10,  5,  5],
    [ 0,  0,  0, 20, 20,  0,  0,  0],
    [ 5, -5,-10,  0,  0,-10, -5,  5],
    [ 5, 10, 10,-20,-20, 10, 10,  5],
    [ 0,  0,  0,  0,  0,  0,  0,  0],
  ],
  N: [
    [-50,-40,-30,-30,-30,-30,-40,-50],
    [-40,-20,  0,  0,  0,  0,-20,-40],
    [-30,  0, 10, 15, 15, 10,  0,-30],
    [-30,  5, 15, 20, 20, 15,  5,-30],
    [-30,  0, 15, 20, 20, 15,  0,-30],
    [-30,  5, 10, 15, 15, 10,  5,-30],
    [-40,-20,  0,  5,  5,  0,-20,-40],
    [-50,-40,-30,-30,-30,-30,-40,-50],
  ],
  B: [
    [-20,-10,-10,-10,-10,-10,-10,-20],
    [-10,  0,  0,  0,  0,  0,  0,-10],
    [-10,  0,  5, 10, 10,  5,  0,-10],
    [-10,  5,  5, 10, 10,  5,  5,-10],
    [-10,  0, 10, 10, 10, 10,  0,-10],
    [-10, 10, 10, 10, 10, 10, 10,-10],
    [-10,  5,  0,  0,  0,  0,  5,-10],
    [-20,-10,-10,-10,-10,-10,-10,-20],
  ],
  R: [
    [ 0,  0,  0,  0,  0,  0,  0,  0],
    [ 5, 10, 10, 10, 10, 10, 10,  5],
    [-5,  0,  0,  0,  0,  0,  0, -5],
    [-5,  0,  0,  0,  0,  0,  0, -5],
    [-5,  0,  0,  0,  0,  0,  0, -5],
    [-5,  0,  0,  0,  0,  0,  0, -5],
    [-5,  0,  0,  0,  0,  0,  0, -5],
    [ 0,  0,  0,  5,  5,  0,  0,  0],
  ],
  Q: [
    [-20,-10,-10, -5, -5,-10,-10,-20],
    [-10,  0,  0,  0,  0,  0,  0,-10],
    [-10,  0,  5,  5,  5,  5,  0,-10],
    [ -5,  0,  5,  5,  5,  5,  0, -5],
    [  0,  0,  5,  5,  5,  5,  0, -5],
    [-10,  5,  5,  5,  5,  5,  0,-10],
    [-10,  0,  5,  0,  0,  0,  0,-10],
    [-20,-10,-10, -5, -5,-10,-10,-20],
  ],
  K: [
    [-30,-40,-40,-50,-50,-40,-40,-30],
    [-30,-40,-40,-50,-50,-40,-40,-30],
    [-30,-40,-40,-50,-50,-40,-40,-30],
    [-30,-40,-40,-50,-50,-40,-40,-30],
    [-20,-30,-30,-40,-40,-30,-30,-20],
    [-10,-20,-20,-20,-20,-20,-20,-10],
    [ 20, 20,  0,  0,  0,  0, 20, 20],
    [ 20, 30, 10,  0,  0, 10, 30, 20],
  ],
};

const initialBoard = () => [
  ["bR","bN","bB","bQ","bK","bB","bN","bR"],
  ["bP","bP","bP","bP","bP","bP","bP","bP"],
  [null,null,null,null,null,null,null,null],
  [null,null,null,null,null,null,null,null],
  [null,null,null,null,null,null,null,null],
  [null,null,null,null,null,null,null,null],
  ["wP","wP","wP","wP","wP","wP","wP","wP"],
  ["wR","wN","wB","wQ","wK","wB","wN","wR"],
];

const cloneBoard = (b) => b.map((row) => row.slice());
const inBounds = (r, c) => r >= 0 && r < 8 && c >= 0 && c < 8;
const colorOf = (p) => (p ? p[0] : null);
const typeOf = (p) => (p ? p[1] : null);

function generatePseudoMoves(board, color, state) {
  const moves = [];
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (!p || colorOf(p) !== color) continue;
      const t = typeOf(p);
      if (t === "P") addPawnMoves(board, r, c, color, moves, state);
      else if (t === "N") addKnightMoves(board, r, c, color, moves);
      else if (t === "B") addSlideMoves(board, r, c, color, moves, [[-1,-1],[-1,1],[1,-1],[1,1]]);
      else if (t === "R") addSlideMoves(board, r, c, color, moves, [[-1,0],[1,0],[0,-1],[0,1]]);
      else if (t === "Q") addSlideMoves(board, r, c, color, moves, [[-1,-1],[-1,1],[1,-1],[1,1],[-1,0],[1,0],[0,-1],[0,1]]);
      else if (t === "K") addKingMoves(board, r, c, color, moves, state);
    }
  }
  return moves;
}

function addPawnMoves(board, r, c, color, moves, state) {
  const dir = color === "w" ? -1 : 1;
  const startRow = color === "w" ? 6 : 1;
  const promoteRow = color === "w" ? 0 : 7;
  if (inBounds(r + dir, c) && !board[r + dir][c]) {
    if (r + dir === promoteRow) {
      for (const promo of ["Q","R","B","N"]) {
        moves.push({ from:[r,c], to:[r+dir,c], promotion: promo });
      }
    } else {
      moves.push({ from:[r,c], to:[r+dir,c] });
    }
    if (r === startRow && !board[r + 2*dir][c]) {
      moves.push({ from:[r,c], to:[r+2*dir,c], doublePush: true });
    }
  }
  for (const dc of [-1, 1]) {
    const nr = r + dir, nc = c + dc;
    if (!inBounds(nr, nc)) continue;
    const target = board[nr][nc];
    if (target && colorOf(target) !== color) {
      if (nr === promoteRow) {
        for (const promo of ["Q","R","B","N"]) {
          moves.push({ from:[r,c], to:[nr,nc], promotion: promo, capture: true });
        }
      } else {
        moves.push({ from:[r,c], to:[nr,nc], capture: true });
      }
    }
    if (state && state.enPassant && state.enPassant[0] === nr && state.enPassant[1] === nc) {
      moves.push({ from:[r,c], to:[nr,nc], enPassant: true, capture: true });
    }
  }
}

function addKnightMoves(board, r, c, color, moves) {
  const deltas = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
  for (const [dr, dc] of deltas) {
    const nr = r+dr, nc = c+dc;
    if (!inBounds(nr, nc)) continue;
    const t = board[nr][nc];
    if (!t || colorOf(t) !== color) {
      moves.push({ from:[r,c], to:[nr,nc], capture: !!t });
    }
  }
}

function addSlideMoves(board, r, c, color, moves, dirs) {
  for (const [dr, dc] of dirs) {
    let nr = r+dr, nc = c+dc;
    while (inBounds(nr, nc)) {
      const t = board[nr][nc];
      if (!t) {
        moves.push({ from:[r,c], to:[nr,nc] });
      } else {
        if (colorOf(t) !== color) moves.push({ from:[r,c], to:[nr,nc], capture: true });
        break;
      }
      nr += dr; nc += dc;
    }
  }
}

function addKingMoves(board, r, c, color, moves, state) {
  for (let dr = -1; dr <= 1; dr++) {
    for (let dc = -1; dc <= 1; dc++) {
      if (!dr && !dc) continue;
      const nr = r+dr, nc = c+dc;
      if (!inBounds(nr, nc)) continue;
      const t = board[nr][nc];
      if (!t || colorOf(t) !== color) {
        moves.push({ from:[r,c], to:[nr,nc], capture: !!t });
      }
    }
  }
  if (!state) return;
  const rights = state.castling[color];
  const row = color === "w" ? 7 : 0;
  if (r !== row || c !== 4) return;
  if (isSquareAttacked(board, row, 4, color === "w" ? "b" : "w")) return;
  if (rights.k && !board[row][5] && !board[row][6] && board[row][7] === color+"R") {
    if (!isSquareAttacked(board, row, 5, color === "w" ? "b" : "w") &&
        !isSquareAttacked(board, row, 6, color === "w" ? "b" : "w")) {
      moves.push({ from:[r,c], to:[row,6], castle: "k" });
    }
  }
  if (rights.q && !board[row][1] && !board[row][2] && !board[row][3] && board[row][0] === color+"R") {
    if (!isSquareAttacked(board, row, 3, color === "w" ? "b" : "w") &&
        !isSquareAttacked(board, row, 2, color === "w" ? "b" : "w")) {
      moves.push({ from:[r,c], to:[row,2], castle: "q" });
    }
  }
}

function isSquareAttacked(board, r, c, byColor) {
  const dir = byColor === "w" ? 1 : -1;
  for (const dc of [-1, 1]) {
    const pr = r + dir, pc = c + dc;
    if (inBounds(pr, pc) && board[pr][pc] === byColor + "P") return true;
  }
  for (const [dr, dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]) {
    const nr = r+dr, nc = c+dc;
    if (inBounds(nr, nc) && board[nr][nc] === byColor + "N") return true;
  }
  for (const [dr, dc] of [[-1,-1],[-1,1],[1,-1],[1,1]]) {
    let nr = r+dr, nc = c+dc;
    while (inBounds(nr, nc)) {
      const t = board[nr][nc];
      if (t) {
        if (colorOf(t) === byColor && (typeOf(t) === "B" || typeOf(t) === "Q")) return true;
        break;
      }
      nr += dr; nc += dc;
    }
  }
  for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]]) {
    let nr = r+dr, nc = c+dc;
    while (inBounds(nr, nc)) {
      const t = board[nr][nc];
      if (t) {
        if (colorOf(t) === byColor && (typeOf(t) === "R" || typeOf(t) === "Q")) return true;
        break;
      }
      nr += dr; nc += dc;
    }
  }
  for (let dr = -1; dr <= 1; dr++) {
    for (let dc = -1; dc <= 1; dc++) {
      if (!dr && !dc) continue;
      const nr = r+dr, nc = c+dc;
      if (inBounds(nr, nc) && board[nr][nc] === byColor + "K") return true;
    }
  }
  return false;
}

function findKing(board, color) {
  for (let r = 0; r < 8; r++)
    for (let c = 0; c < 8; c++)
      if (board[r][c] === color + "K") return [r, c];
  return null;
}

function isInCheck(board, color) {
  const k = findKing(board, color);
  if (!k) return false;
  return isSquareAttacked(board, k[0], k[1], color === "w" ? "b" : "w");
}

function applyMove(board, move, state) {
  const nb = cloneBoard(board);
  const [fr, fc] = move.from;
  const [tr, tc] = move.to;
  const piece = nb[fr][fc];
  const color = colorOf(piece);
  nb[tr][tc] = piece;
  nb[fr][fc] = null;
  if (move.promotion) nb[tr][tc] = color + move.promotion;
  if (move.enPassant) {
    const dir = color === "w" ? 1 : -1;
    nb[tr + dir][tc] = null;
  }
  if (move.castle === "k") {
    nb[tr][5] = color + "R";
    nb[tr][7] = null;
  }
  if (move.castle === "q") {
    nb[tr][3] = color + "R";
    nb[tr][0] = null;
  }
  const newState = {
    castling: { w: { ...state.castling.w }, b: { ...state.castling.b } },
    enPassant: null,
  };
  if (typeOf(piece) === "K") {
    newState.castling[color].k = false;
    newState.castling[color].q = false;
  }
  if (typeOf(piece) === "R") {
    const row = color === "w" ? 7 : 0;
    if (fr === row && fc === 0) newState.castling[color].q = false;
    if (fr === row && fc === 7) newState.castling[color].k = false;
  }
  const other = color === "w" ? "b" : "w";
  const otherRow = other === "w" ? 7 : 0;
  if (tr === otherRow && tc === 0) newState.castling[other].q = false;
  if (tr === otherRow && tc === 7) newState.castling[other].k = false;
  if (move.doublePush) {
    const dir = color === "w" ? -1 : 1;
    newState.enPassant = [fr + dir, fc];
  }
  return { board: nb, state: newState };
}

function generateLegalMoves(board, color, state) {
  const pseudo = generatePseudoMoves(board, color, state);
  const legal = [];
  for (const mv of pseudo) {
    const { board: nb } = applyMove(board, mv, state);
    if (!isInCheck(nb, color)) legal.push(mv);
  }
  return legal;
}

function evaluate(board) {
  let score = 0;
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (!p) continue;
      const val = PIECE_VALUES[typeOf(p)];
      const table = PST[typeOf(p)];
      const positional = colorOf(p) === "w" ? table[r][c] : table[7-r][c];
      score += colorOf(p) === "w" ? (val + positional) : -(val + positional);
    }
  }
  return score;
}

function search(board, depth, alpha, beta, maximizing, color, state) {
  if (depth === 0) return { score: evaluate(board), move: null };
  const moves = generateLegalMoves(board, color, state);
  if (moves.length === 0) {
    if (isInCheck(board, color)) {
      return { score: maximizing ? -100000 - depth : 100000 + depth, move: null };
    }
    return { score: 0, move: null };
  }
  moves.sort((a, b) => (b.capture ? 1 : 0) - (a.capture ? 1 : 0));
  let bestMove = moves[0];
  if (maximizing) {
    let maxEval = -Infinity;
    for (const mv of moves) {
      const { board: nb, state: ns } = applyMove(board, mv, state);
      const { score } = search(nb, depth-1, alpha, beta, false, color === "w" ? "b" : "w", ns);
      if (score > maxEval) { maxEval = score; bestMove = mv; }
      alpha = Math.max(alpha, score);
      if (beta <= alpha) break;
    }
    return { score: maxEval, move: bestMove };
  } else {
    let minEval = Infinity;
    for (const mv of moves) {
      const { board: nb, state: ns } = applyMove(board, mv, state);
      const { score } = search(nb, depth-1, alpha, beta, true, color === "w" ? "b" : "w", ns);
      if (score < minEval) { minEval = score; bestMove = mv; }
      beta = Math.min(beta, score);
      if (beta <= alpha) break;
    }
    return { score: minEval, move: bestMove };
  }
}

function pickAIMove(board, color, state, level) {
  const moves = generateLegalMoves(board, color, state);
  if (moves.length === 0) return null;
  if (level === "beginner") {
    if (Math.random() < 0.25) {
      const caps = moves.filter(m => m.capture);
      if (caps.length) return caps[Math.floor(Math.random()*caps.length)];
    }
    return moves[Math.floor(Math.random()*moves.length)];
  }
  if (level === "casual") {
    const scored = moves.map(mv => {
      const { board: nb } = applyMove(board, mv, state);
      const s = evaluate(nb);
      return { mv, s: color === "b" ? -s : s };
    });
    scored.sort((a,b) => b.s - a.s);
    if (Math.random() < 0.4) return scored[0].mv;
    const pool = scored.slice(0, Math.min(3, scored.length));
    return pool[Math.floor(Math.random()*pool.length)].mv;
  }
  if (level === "intermediate") {
    const { move } = search(board, 2, -Infinity, Infinity, color === "w", color, state);
    return move || moves[0];
  }
  if (level === "advanced") {
    const { move } = search(board, 3, -Infinity, Infinity, color === "w", color, state);
    return move || moves[0];
  }
  // Master: iterative deepening with a hard time budget (1.8 s) so UI never
  // freezes longer than this even on pathological positions.
  const deadline = Date.now() + 1800;
  let bestMove = moves[0];
  for (let depth = 2; depth <= 4; depth++) {
    if (Date.now() >= deadline && depth > 2) break;
    try {
      const { move } = search(board, depth, -Infinity, Infinity, color === "w", color, state);
      if (move) bestMove = move;
    } catch (e) {
      break;
    }
    if (Date.now() >= deadline) break;
  }
  return bestMove;
}

// ============================================================
// AUDIO SYSTEM (Web Audio API - no external files)
// ============================================================

class AudioManager {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.musicGain = null;
    this.sfxGain = null;
    this.reverbSend = null; // shared reverb bus
    this.reverbOut = null;
    this.musicNodes = [];
    this.musicSubGains = [];
    this.musicTrack = null;
    this.musicEnabled = true;
    this.sfxEnabled = true;
    this.musicStyle = "relaxing"; // "relaxing" | "focus"
    this.isPlaying = false;
    this.arpScheduler = null;
  }

  init() {
    if (this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = 0.9;
    this.masterGain.connect(this.ctx.destination);

    // Subtle master compression for cohesion
    this.compressor = this.ctx.createDynamicsCompressor();
    this.compressor.threshold.value = -18;
    this.compressor.knee.value = 10;
    this.compressor.ratio.value = 3;
    this.compressor.attack.value = 0.01;
    this.compressor.release.value = 0.2;
    this.compressor.connect(this.masterGain);

    this.musicGain = this.ctx.createGain();
    this.musicGain.gain.value = 0.28;
    this.musicGain.connect(this.compressor);

    this.sfxGain = this.ctx.createGain();
    this.sfxGain.gain.value = 0.55;
    this.sfxGain.connect(this.compressor);

    // Reverb send bus: a synthesized impulse response via feedback delay network
    // gives us rich, warm room tone without needing an external IR file.
    this.reverbSend = this.ctx.createGain();
    this.reverbSend.gain.value = 1.0;
    this.reverbOut = this._buildReverb();
    this.reverbSend.connect(this.reverbOut);
    this.reverbOut.connect(this.compressor);
  }

  // Build a lightweight synthetic reverb: a set of feedback delays with lowpass filters.
  // Output node is returned; input is this.reverbSend.
  _buildReverb() {
    const ctx = this.ctx;
    const out = ctx.createGain();
    out.gain.value = 0.35; // reverb return level

    // Multi-tap feedback delay for a room-like tail
    const delays = [0.029, 0.041, 0.053, 0.067, 0.089, 0.113];
    delays.forEach((t) => {
      const d = ctx.createDelay(0.5);
      d.delayTime.value = t;
      const fb = ctx.createGain();
      fb.gain.value = 0.55; // feedback strength (< 1 to decay)
      const lpf = ctx.createBiquadFilter();
      lpf.type = "lowpass";
      lpf.frequency.value = 3200;
      lpf.Q.value = 0.7;
      // Route: reverbSend → delay → lpf → out
      //                    ↑____fb____↓
      this.reverbSend.connect(d);
      d.connect(lpf);
      lpf.connect(out);
      lpf.connect(fb);
      fb.connect(d);
    });
    return out;
  }

  resume() {
    if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
  }

  // Route an SFX node into both the main SFX bus and the reverb bus.
  _routeWithReverb(node, reverbAmount = 0.12) {
    node.connect(this.sfxGain);
    if (this.reverbSend) {
      const send = this.ctx.createGain();
      send.gain.value = reverbAmount;
      node.connect(send);
      send.connect(this.reverbSend);
    }
  }

  // ================================================
  // PIECE SOUNDS - high-fidelity wooden knock
  // ================================================
  // A real wooden chess piece hitting a wooden board has:
  //  - Sharp attack transient (contact noise, ~1-3ms)
  //  - Multi-modal wood resonance (fundamental + inharmonic overtones)
  //  - Exponential decay as energy dissipates through the wood
  //  - Subtle air noise from displacement
  playMove(isCapture = false) {
    if (!this.sfxEnabled || !this.ctx) return;
    const ctx = this.ctx;
    const now = ctx.currentTime;

    // Master gain node for this hit
    const out = ctx.createGain();
    out.gain.value = isCapture ? 0.85 : 0.62;
    this._routeWithReverb(out, 0.18);

    // 1. Attack transient: a tiny burst of filtered noise
    const noiseLen = 0.012;
    const noiseBuf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * noiseLen), ctx.sampleRate);
    const nd = noiseBuf.getChannelData(0);
    for (let i = 0; i < nd.length; i++) {
      nd[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / nd.length, 2);
    }
    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuf;
    const noiseFilter = ctx.createBiquadFilter();
    noiseFilter.type = "bandpass";
    noiseFilter.frequency.value = isCapture ? 2400 : 3600;
    noiseFilter.Q.value = 1.8;
    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(0.7, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.025);
    noise.connect(noiseFilter).connect(noiseGain).connect(out);
    noise.start(now);
    noise.stop(now + noiseLen);

    // 2. Wood resonance modes - three inharmonic partials that decay independently
    const modes = isCapture
      ? [
          { f: 85,  amp: 1.0,  decay: 0.35 }, // deep fundamental
          { f: 220, amp: 0.55, decay: 0.22 },
          { f: 480, amp: 0.28, decay: 0.14 },
          { f: 1100, amp: 0.12, decay: 0.08 },
        ]
      : [
          { f: 145, amp: 0.9,  decay: 0.20 },
          { f: 380, amp: 0.55, decay: 0.14 },
          { f: 720, amp: 0.32, decay: 0.09 },
          { f: 1450, amp: 0.14, decay: 0.05 },
        ];

    modes.forEach((m) => {
      const osc = ctx.createOscillator();
      osc.type = "sine";
      // Slight detune gives a more natural, less synthetic feel
      osc.frequency.setValueAtTime(m.f * (1 + (Math.random() - 0.5) * 0.01), now);
      // Gently drop the pitch as the mode decays (like real wood flex)
      osc.frequency.exponentialRampToValueAtTime(m.f * 0.92, now + m.decay);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, now);
      g.gain.exponentialRampToValueAtTime(m.amp, now + 0.003);
      g.gain.exponentialRampToValueAtTime(0.0001, now + m.decay);
      osc.connect(g).connect(out);
      osc.start(now);
      osc.stop(now + m.decay + 0.02);
    });

    // 3. "Thump" body: a brief low sub-oscillator for physical weight
    const body = ctx.createOscillator();
    body.type = "sine";
    body.frequency.setValueAtTime(isCapture ? 58 : 72, now);
    body.frequency.exponentialRampToValueAtTime(isCapture ? 40 : 50, now + 0.08);
    const bodyGain = ctx.createGain();
    bodyGain.gain.setValueAtTime(0.0001, now);
    bodyGain.gain.exponentialRampToValueAtTime(isCapture ? 0.6 : 0.4, now + 0.005);
    bodyGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.15);
    body.connect(bodyGain).connect(out);
    body.start(now);
    body.stop(now + 0.18);
  }

  // ================================================
  // UI CLICK - crisp, subtle button feedback
  // ================================================
  playClick() {
    if (!this.sfxEnabled || !this.ctx) return;
    const ctx = this.ctx;
    const now = ctx.currentTime;

    const out = ctx.createGain();
    out.gain.value = 0.25; // subtle
    out.connect(this.sfxGain);

    // High-frequency filtered noise burst
    const bufLen = Math.floor(ctx.sampleRate * 0.02);
    const buf = ctx.createBuffer(1, bufLen, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < bufLen; i++) {
      d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / bufLen, 3);
    }
    const noise = ctx.createBufferSource();
    noise.buffer = buf;
    const filter = ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.value = 4500;
    filter.Q.value = 2;
    const ng = ctx.createGain();
    ng.gain.setValueAtTime(0.6, now);
    ng.gain.exponentialRampToValueAtTime(0.0001, now + 0.04);
    noise.connect(filter).connect(ng).connect(out);
    noise.start(now);
    noise.stop(now + 0.05);

    // Tiny pitched tick for definition
    const tick = ctx.createOscillator();
    tick.type = "sine";
    tick.frequency.setValueAtTime(2200, now);
    tick.frequency.exponentialRampToValueAtTime(1400, now + 0.025);
    const tg = ctx.createGain();
    tg.gain.setValueAtTime(0.0001, now);
    tg.gain.exponentialRampToValueAtTime(0.35, now + 0.002);
    tg.gain.exponentialRampToValueAtTime(0.0001, now + 0.04);
    tick.connect(tg).connect(out);
    tick.start(now);
    tick.stop(now + 0.05);
  }

  // ================================================
  // CHECK SOUND - warm bell chime with harmonic overtones
  // ================================================
  playCheck() {
    if (!this.sfxEnabled || !this.ctx) return;
    const ctx = this.ctx;
    const now = ctx.currentTime;

    const out = ctx.createGain();
    out.gain.value = 0.35;
    this._routeWithReverb(out, 0.5); // more reverb on the chime

    // Bell = fundamental + slightly detuned partials (2.76x, 5.4x, 8.93x for real bells)
    // Scaled down to less shrill frequencies for a gentler warning.
    const fundamental = 587.33; // D5
    const partials = [
      { ratio: 1.0,  amp: 0.85, decay: 1.2 },
      { ratio: 2.0,  amp: 0.35, decay: 0.8 }, // octave
      { ratio: 2.76, amp: 0.22, decay: 0.6 }, // bell minor third
      { ratio: 5.4,  amp: 0.12, decay: 0.35 },
    ];
    partials.forEach((p, i) => {
      const o = ctx.createOscillator();
      o.type = "sine";
      o.frequency.value = fundamental * p.ratio;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, now);
      g.gain.exponentialRampToValueAtTime(p.amp, now + 0.01 + i * 0.003);
      g.gain.exponentialRampToValueAtTime(0.0001, now + p.decay);
      o.connect(g).connect(out);
      o.start(now);
      o.stop(now + p.decay + 0.05);
    });
  }

  // ================================================
  // GAME END - triumphant or somber arpeggio with reverb
  // ================================================
  playGameEnd(victory) {
    if (!this.sfxEnabled || !this.ctx) return;
    const ctx = this.ctx;
    const now = ctx.currentTime;

    const out = ctx.createGain();
    out.gain.value = 0.4;
    this._routeWithReverb(out, 0.6);

    // Victory: ascending major triad + octave. Defeat: descending minor sixth.
    const notes = victory
      ? [392.00, 493.88, 587.33, 783.99] // G4 B4 D5 G5 (G major)
      : [440.00, 369.99, 311.13, 246.94]; // A4 F#4 Eb4 B3 (descending)

    notes.forEach((freq, i) => {
      const t = now + i * 0.18;
      // Layered: warm triangle + soft sine harmonic
      const tri = ctx.createOscillator();
      tri.type = "triangle";
      tri.frequency.value = freq;
      const triG = ctx.createGain();
      triG.gain.setValueAtTime(0.0001, t);
      triG.gain.exponentialRampToValueAtTime(0.4, t + 0.02);
      triG.gain.exponentialRampToValueAtTime(0.0001, t + 0.9);
      tri.connect(triG).connect(out);
      tri.start(t);
      tri.stop(t + 0.95);

      const harm = ctx.createOscillator();
      harm.type = "sine";
      harm.frequency.value = freq * 2;
      const harmG = ctx.createGain();
      harmG.gain.setValueAtTime(0.0001, t);
      harmG.gain.exponentialRampToValueAtTime(0.18, t + 0.02);
      harmG.gain.exponentialRampToValueAtTime(0.0001, t + 0.7);
      harm.connect(harmG).connect(out);
      harm.start(t);
      harm.stop(t + 0.75);
    });
  }

  stopMusic() {
    if (this.arpScheduler) {
      clearInterval(this.arpScheduler);
      this.arpScheduler = null;
    }
    if (this.musicTrack) {
      try { this.musicTrack.stop(); } catch(e) {}
      this.musicTrack = null;
    }
    this.musicNodes.forEach(n => {
      try { n.stop(); } catch(e) {}
      try { n.disconnect(); } catch(e) {}
    });
    this.musicNodes = [];
    if (this.musicSubGains) {
      this.musicSubGains.forEach(g => { try { g.disconnect(); } catch(e) {} });
      this.musicSubGains = [];
    }
    this.isPlaying = false;
  }

  startMusic(style) {
    if (!this.ctx) return;
    if (style) this.musicStyle = style;
    this.stopMusic();
    if (!this.musicEnabled) return;
    if (this.isPlaying) return;
    this.isPlaying = true;
    this.musicSubGains = [];

    if (this.musicStyle === "relaxing") {
      this.startRelaxingMusic();
    } else {
      this.startFocusMusic();
    }
  }

  // Helper: create an oscillator with ADSR envelope, routed through an optional filter.
  _makeVoice(freq, oscType, dest, params = {}) {
    const { attack = 0.01, decay = 0.1, sustain = 0.5, release = 0.3, peak = 0.5 } = params;
    const ctx = this.ctx;
    const osc = ctx.createOscillator();
    osc.type = oscType;
    osc.frequency.value = freq;
    const g = ctx.createGain();
    g.gain.value = 0;
    osc.connect(g).connect(dest);
    this.musicNodes.push(osc);
    this.musicSubGains.push(g);
    return { osc, gain: g, attack, decay, sustain, release, peak };
  }

  // ================================================
  // RELAXING MUSIC - lush ambient pads with slow movement
  // ================================================
  startRelaxingMusic() {
    const ctx = this.ctx;
    const now = ctx.currentTime;

    // Master buses
    const padBus = ctx.createBiquadFilter();
    padBus.type = "lowpass";
    padBus.frequency.value = 1100;
    padBus.Q.value = 0.6;
    padBus.connect(this.musicGain);
    // Also send some to reverb
    const padRevSend = ctx.createGain();
    padRevSend.gain.value = 0.4;
    padBus.connect(padRevSend);
    padRevSend.connect(this.reverbSend);
    this.musicSubGains.push(padBus, padRevSend);

    // LFO for slow filter breathing
    const filterLFO = ctx.createOscillator();
    filterLFO.frequency.value = 0.06;
    const filterLFOGain = ctx.createGain();
    filterLFOGain.gain.value = 250;
    filterLFO.connect(filterLFOGain).connect(padBus.frequency);
    filterLFO.start(now);
    this.musicNodes.push(filterLFO);
    this.musicSubGains.push(filterLFOGain);

    // Pad chord: A minor 9 - rich, introspective
    // A2, C3, E3, G3, B3
    const chordFreqs = [110.00, 130.81, 164.81, 196.00, 246.94];
    chordFreqs.forEach((f, i) => {
      // Three detuned oscillators per note for width
      const detunes = [0, +0.5, -0.7];
      detunes.forEach((cents) => {
        const osc = ctx.createOscillator();
        osc.type = i === 0 ? "triangle" : "sine"; // bass is richer
        osc.frequency.value = f;
        osc.detune.value = cents;
        const g = ctx.createGain();
        g.gain.value = 0;
        g.gain.setValueAtTime(0, now);
        g.gain.linearRampToValueAtTime((0.14 - i * 0.012) / detunes.length, now + 5);
        osc.connect(g).connect(padBus);
        osc.start(now);
        this.musicNodes.push(osc);
        this.musicSubGains.push(g);
      });
    });

    // Arpeggio voice with dedicated reverb send (ambient "bells")
    const arpBus = ctx.createGain();
    arpBus.gain.value = 0.07;
    arpBus.connect(this.musicGain);
    const arpRevSend = ctx.createGain();
    arpRevSend.gain.value = 0.7;
    arpBus.connect(arpRevSend);
    arpRevSend.connect(this.reverbSend);
    this.musicSubGains.push(arpBus, arpRevSend);

    // Slow, sparse arpeggio in A aeolian/dorian mix
    const arpNotes = [
      { f: 440.00, dur: 1.8 },   // A4
      { f: 523.25, dur: 1.8 },   // C5
      { f: 659.25, dur: 2.4 },   // E5
      { f: 523.25, dur: 1.4 },   // C5
      { f: 392.00, dur: 2.0 },   // G4
      { f: 587.33, dur: 1.8 },   // D5
      { f: 440.00, dur: 1.6 },   // A4
      { f: 659.25, dur: 2.6 },   // E5
    ];
    const loopLen = arpNotes.reduce((s, n) => s + n.dur, 0);

    const scheduleArp = (startTime) => {
      let t = startTime;
      arpNotes.forEach((n) => {
        // Triangle + sine octave above for bell-like shimmer
        const o = ctx.createOscillator();
        o.type = "triangle";
        o.frequency.value = n.f;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.0001, t);
        g.gain.exponentialRampToValueAtTime(0.5, t + 0.08);
        g.gain.exponentialRampToValueAtTime(0.0001, t + n.dur * 0.9);
        o.connect(g).connect(arpBus);
        o.start(t);
        o.stop(t + n.dur);
        this.musicNodes.push(o);
        this.musicSubGains.push(g);

        // Shimmer partial (sine one octave up, quieter)
        const s = ctx.createOscillator();
        s.type = "sine";
        s.frequency.value = n.f * 2;
        const sg = ctx.createGain();
        sg.gain.setValueAtTime(0.0001, t);
        sg.gain.exponentialRampToValueAtTime(0.14, t + 0.12);
        sg.gain.exponentialRampToValueAtTime(0.0001, t + n.dur * 0.7);
        s.connect(sg).connect(arpBus);
        s.start(t);
        s.stop(t + n.dur);
        this.musicNodes.push(s);
        this.musicSubGains.push(sg);

        t += n.dur;
      });
    };

    this.arpScheduler = setInterval(() => {
      if (!this.musicEnabled || !this.isPlaying) return;
      scheduleArp(this.ctx.currentTime);
    }, loopLen * 1000);
    scheduleArp(now + 4);
  }

  // ================================================
  // FOCUS MUSIC - rhythmic, steady, subtly intense
  // ================================================
  startFocusMusic() {
    const ctx = this.ctx;
    const now = ctx.currentTime;

    // Bus with gentle lowpass
    const bus = ctx.createBiquadFilter();
    bus.type = "lowpass";
    bus.frequency.value = 1800;
    bus.Q.value = 0.9;
    bus.connect(this.musicGain);
    const busRevSend = ctx.createGain();
    busRevSend.gain.value = 0.3;
    bus.connect(busRevSend);
    busRevSend.connect(this.reverbSend);
    this.musicSubGains.push(bus, busRevSend);

    // Bass bus - less reverb, punchier
    const bassBus = ctx.createGain();
    bassBus.gain.value = 0.3;
    bassBus.connect(bus);
    this.musicSubGains.push(bassBus);

    // Pad bus
    const padBus = ctx.createGain();
    padBus.gain.value = 0.22;
    padBus.connect(bus);
    this.musicSubGains.push(padBus);

    // Melody bus - dedicated reverb
    const melBus = ctx.createGain();
    melBus.gain.value = 0.14;
    melBus.connect(this.musicGain);
    const melRev = ctx.createGain();
    melRev.gain.value = 0.55;
    melBus.connect(melRev);
    melRev.connect(this.reverbSend);
    this.musicSubGains.push(melBus, melRev);

    const bassPulse = (t, freq) => {
      // Sine + sub-harmonic for body
      [freq, freq / 2].forEach((f, i) => {
        const o = ctx.createOscillator();
        o.type = "sine";
        o.frequency.setValueAtTime(f, t);
        o.frequency.exponentialRampToValueAtTime(f * 0.85, t + 0.5);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.0001, t);
        g.gain.exponentialRampToValueAtTime(i === 0 ? 0.65 : 0.3, t + 0.015);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.85);
        o.connect(g).connect(bassBus);
        o.start(t);
        o.stop(t + 0.9);
        this.musicNodes.push(o);
        this.musicSubGains.push(g);
      });
    };

    const padChord = (t, freqs, dur) => {
      freqs.forEach((f) => {
        // Two detuned saws for warmth
        [0, +4].forEach((detune) => {
          const o = ctx.createOscillator();
          o.type = "sawtooth";
          o.frequency.value = f;
          o.detune.value = detune;
          const g = ctx.createGain();
          g.gain.setValueAtTime(0, t);
          g.gain.linearRampToValueAtTime(0.1, t + 0.5);
          g.gain.linearRampToValueAtTime(0.1, t + dur - 0.5);
          g.gain.linearRampToValueAtTime(0.0001, t + dur);
          o.connect(g).connect(padBus);
          o.start(t);
          o.stop(t + dur + 0.1);
          this.musicNodes.push(o);
          this.musicSubGains.push(g);
        });
      });
    };

    const melNote = (t, freq, dur) => {
      const o = ctx.createOscillator();
      o.type = "triangle";
      o.frequency.value = freq;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.5, t + 0.03);
      g.gain.exponentialRampToValueAtTime(0.2, t + dur * 0.6);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g).connect(melBus);
      o.start(t);
      o.stop(t + dur + 0.05);
      this.musicNodes.push(o);
      this.musicSubGains.push(g);

      // Harmonic shimmer an octave up
      const h = ctx.createOscillator();
      h.type = "sine";
      h.frequency.value = freq * 2;
      const hg = ctx.createGain();
      hg.gain.setValueAtTime(0.0001, t);
      hg.gain.exponentialRampToValueAtTime(0.15, t + 0.04);
      hg.gain.exponentialRampToValueAtTime(0.0001, t + dur * 0.8);
      h.connect(hg).connect(melBus);
      h.start(t);
      h.stop(t + dur + 0.05);
      this.musicNodes.push(h);
      this.musicSubGains.push(hg);
    };

    const beat = 0.75;
    const loopLen = 16 * beat;

    const scheduleLoop = (startTime) => {
      const bassSeq = [73.42, 110, 87.31, 65.41]; // D2 A2 F2 C2
      for (let i = 0; i < 16; i++) {
        bassPulse(startTime + i * beat, bassSeq[Math.floor(i / 4)]);
      }
      // Progression: Dm7 - Am7 - Fmaj7 - Cmaj7
      const chords = [
        [146.83, 220, 261.63, 349.23],
        [110, 164.81, 196, 261.63],
        [174.61, 220, 261.63, 329.63],
        [130.81, 164.81, 196, 246.94],
      ];
      chords.forEach((ch, i) => padChord(startTime + i * 4 * beat, ch, 4 * beat));
      // Simple melodic line
      const mel = [
        [0, 587.33, 1.5],
        [2, 523.25, 1],
        [3.5, 440, 1.5],
        [6, 493.88, 1],
        [7, 440, 1],
        [9, 523.25, 1.5],
        [10.5, 587.33, 1.5],
        [13, 440, 2],
      ];
      mel.forEach(([b, f, d]) => melNote(startTime + b * beat, f, d * beat));
    };

    scheduleLoop(now);
    this.arpScheduler = setInterval(() => {
      if (this.musicEnabled && this.isPlaying) scheduleLoop(this.ctx.currentTime);
    }, loopLen * 1000);
  }

  clearMusic() {
    this.stopMusic();
  }

  setMusicEnabled(v) {
    this.musicEnabled = v;
    if (!v) this.clearMusic();
  }

  setSfxEnabled(v) {
    this.sfxEnabled = v;
  }

  setMusicVolume(v) {
    if (!this.musicGain) return;
    this.musicGain.gain.value = Math.max(0, Math.min(0.6, v * 0.6));
  }

  setSfxVolume(v) {
    if (!this.sfxGain) return;
    this.sfxGain.gain.value = Math.max(0, Math.min(1, v));
  }
}

const audioManager = new AudioManager();

// ============================================================
// UI
// ============================================================

const LEVELS = [
  { id: "beginner",     name: "Beginner",     tagline: "Learning the moves",         depth: "Random with a spark" },
  { id: "casual",       name: "Casual",       tagline: "A friendly weekend game",    depth: "Shallow tactics" },
  { id: "intermediate", name: "Intermediate", tagline: "Club night at the café",     depth: "Looks 2 moves ahead" },
  { id: "advanced",     name: "Advanced",     tagline: "Sharpen your calculation",   depth: "Looks 3 moves ahead" },
  { id: "master",       name: "Master",       tagline: "Expect no mercy",            depth: "Looks 4 moves ahead" },
];

// Time controls — minutes per side, increment in seconds
const TIME_CONTROLS = [
  { id: "unlimited", name: "Unlimited", tagline: "No clock", minutes: null, increment: 0 },
  { id: "blitz",     name: "Blitz",     tagline: "5 + 0",    minutes: 5,    increment: 0 },
  { id: "rapid",     name: "Rapid",     tagline: "10 + 0",   minutes: 10,   increment: 0 },
  { id: "classical", name: "Classical", tagline: "30 + 0",   minutes: 30,   increment: 0 },
];

const MAX_HINTS_PER_GAME = 3;

// Board themes - each specifies colors for light/dark squares plus last-move and selected accents
const BOARD_THEMES = {
  classic: {
    name: "Classic Wood",
    light: "#efd9b4",
    dark: "#8a5a3c",
    lastLight: "#e8d089",
    lastDark: "#a8823a",
    selLight: "#d4c16b",
    selDark: "#967225",
    frame: "linear-gradient(135deg, #5a3a1f 0%, #3a2411 100%)",
    frameBorder: "rgba(212, 162, 86, 0.3)",
    coordColor: "#d4a256",
  },
  marble: {
    name: "Marble",
    light: "#ece7dc",
    dark: "#7a7975",
    lastLight: "#d8cfa8",
    lastDark: "#8b8578",
    selLight: "#c4b888",
    selDark: "#6d6658",
    frame: "linear-gradient(135deg, #3a3734 0%, #1f1d1b 100%)",
    frameBorder: "rgba(200, 195, 185, 0.25)",
    coordColor: "#b8b3a8",
  },
  tournament: {
    name: "Tournament",
    light: "#eeeed2",
    dark: "#769656",
    lastLight: "#f6f669",
    lastDark: "#baca2b",
    selLight: "#dfd34d",
    selDark: "#5d7a3f",
    frame: "linear-gradient(135deg, #2d3a22 0%, #1a2315 100%)",
    frameBorder: "rgba(180, 200, 140, 0.25)",
    coordColor: "#b4c88c",
  },
  ice: {
    name: "Blue Ice",
    light: "#dee3e6",
    dark: "#8ca2ad",
    lastLight: "#c8d4d8",
    lastDark: "#6d8a96",
    selLight: "#a8c4d0",
    selDark: "#5a7380",
    frame: "linear-gradient(135deg, #2a3842 0%, #151f27 100%)",
    frameBorder: "rgba(170, 200, 220, 0.25)",
    coordColor: "#a8c4d4",
  },
};

// Piece sets - each defines how to render a piece code (e.g. "wK") as a display string
// Using filled Unicode glyphs (♚♛♜♝♞♟) for BOTH sides and distinguishing purely by color.
// This matches how Lichess/Chess.com render pieces: one solid silhouette per piece type,
// colored white or black. Prevents the "white king looks like a black king with halo" bug.
const PIECE_SETS = {
  classic: {
    name: "Classic",
    // Use the filled (black-style) Unicode glyph for BOTH sides, color distinguishes them.
    // CRITICAL: on iOS Safari, chess Unicode can render as 3D color emoji for ♟ but as
    // monochrome text for ♚♛♜♝♞ — causing visual mismatch. We force text rendering via
    // `font-variant-emoji: text` and text-style variation selector U+FE0E.
    glyphs: {
      wK: "♚\uFE0E", wQ: "♛\uFE0E", wR: "♜\uFE0E", wB: "♝\uFE0E", wN: "♞\uFE0E", wP: "♟\uFE0E",
      bK: "♚\uFE0E", bQ: "♛\uFE0E", bR: "♜\uFE0E", bB: "♝\uFE0E", bN: "♞\uFE0E", bP: "♟\uFE0E",
    },
    whiteColor: "#f8f8f8",
    blackColor: "#1a1a1a",
    whiteShadow: "0 2px 3px rgba(0,0,0,0.5)",
    blackShadow: "0 2px 3px rgba(0,0,0,0.45)",
    fontSize: "clamp(1.8rem, 6.5vw, 3.2rem)",
    weight: 400,
    // Avoid Apple Color Emoji which would render some glyphs as 3D colored shapes.
    fontFamily: "'DejaVu Sans', 'Arial Unicode MS', 'Segoe UI Symbol', 'Symbola', serif",
  },
  medieval: {
    name: "Medieval",
    glyphs: {
      wK: "♚\uFE0E", wQ: "♛\uFE0E", wR: "♜\uFE0E", wB: "♝\uFE0E", wN: "♞\uFE0E", wP: "♟\uFE0E",
      bK: "♚\uFE0E", bQ: "♛\uFE0E", bR: "♜\uFE0E", bB: "♝\uFE0E", bN: "♞\uFE0E", bP: "♟\uFE0E",
    },
    whiteColor: "#f8f1dc",
    blackColor: "#141414",
    whiteShadow: "0 3px 5px rgba(0,0,0,0.6)",
    blackShadow: "0 3px 5px rgba(0,0,0,0.5)",
    fontSize: "clamp(2rem, 7.2vw, 3.5rem)",
    weight: 400,
    fontFamily: "'DejaVu Sans', 'Arial Unicode MS', 'Segoe UI Symbol', 'Symbola', serif",
  },
  minimal: {
    name: "Minimalist",
    glyphs: {
      wK: "K", wQ: "Q", wR: "R", wB: "B", wN: "N", wP: "P",
      bK: "K", bQ: "Q", bR: "R", bB: "B", bN: "N", bP: "P",
    },
    whiteColor: "#ffffff",
    blackColor: "#111111",
    whiteShadow: "0 2px 3px rgba(0, 0, 0, 0.5)",
    blackShadow: "0 2px 3px rgba(0, 0, 0, 0.4)",
    fontSize: "clamp(1.4rem, 5vw, 2.6rem)",
    weight: 700,
    fontFamily: "'Cormorant Garamond', Georgia, serif",
  },
};

const files = ["a","b","c","d","e","f","g","h"];
const ranks = ["8","7","6","5","4","3","2","1"];

function squareName(r, c) { return files[c] + ranks[r]; }

function moveToAlgebraic(board, mv, state) {
  const piece = board[mv.from[0]][mv.from[1]];
  const t = typeOf(piece);
  const to = squareName(mv.to[0], mv.to[1]);
  if (mv.castle === "k") return "O-O";
  if (mv.castle === "q") return "O-O-O";
  let prefix = t === "P" ? "" : t;
  if (mv.capture) {
    if (t === "P") prefix = files[mv.from[1]];
    prefix += "x";
  }
  let suffix = "";
  if (mv.promotion) suffix = "=" + mv.promotion;
  return prefix + to + suffix;
}

// ============================================================
// PROFILE STORAGE
// ============================================================

const PROFILES_KEY = "chess-profiles-v1";
const ACTIVE_KEY = "chess-active-profile-v1";
const PREFS_KEY = "chess-prefs-v1";

async function loadPrefs() {
  try {
    const r = await window.storage.get(PREFS_KEY);
    return r ? JSON.parse(r.value) : null;
  } catch {
    return null;
  }
}

async function savePrefs(prefs) {
  try {
    await window.storage.set(PREFS_KEY, JSON.stringify(prefs));
  } catch(e) { console.error(e); }
}

async function loadProfiles() {
  try {
    const r = await window.storage.get(PROFILES_KEY);
    const profiles = r ? JSON.parse(r.value) : [];
    // Backfill fields that were added after initial release
    return profiles.map(p => ({
      ...p,
      rating: typeof p.rating === "number" ? p.rating : 1000,
      achievements: p.achievements || {},
      xp: typeof p.xp === "number" ? p.xp : 0,
      level: typeof p.level === "number" ? p.level : 1,
      nicknames: Array.isArray(p.nicknames) ? p.nicknames : [],
    }));
  } catch {
    return [];
  }
}

async function saveProfiles(profiles) {
  try {
    await window.storage.set(PROFILES_KEY, JSON.stringify(profiles));
  } catch(e) { console.error(e); }
}

async function loadActiveId() {
  try {
    const r = await window.storage.get(ACTIVE_KEY);
    return r ? r.value : null;
  } catch {
    return null;
  }
}

async function saveActiveId(id) {
  try {
    if (id === null) {
      await window.storage.delete(ACTIVE_KEY);
    } else {
      await window.storage.set(ACTIVE_KEY, id);
    }
  } catch(e) { console.error(e); }
}

// ELO baseline ratings for each AI level
const LEVEL_RATINGS = {
  beginner: 800,
  casual: 1100,
  intermediate: 1400,
  advanced: 1700,
  master: 2000,
};

// Achievement definitions: { id, name, description, check(profile, context) }
const ACHIEVEMENTS = [
  { id: "first_win",      name: "First Blood",        desc: "Win your first game",                    icon: "🏅" },
  { id: "streak_5",       name: "Hot Hand",            desc: "Win 5 games in a row",                   icon: "🔥" },
  { id: "streak_10",      name: "On Fire",             desc: "Win 10 games in a row",                  icon: "⚡" },
  { id: "beat_intermediate", name: "Club Player",      desc: "Beat the Intermediate opponent",         icon: "♞" },
  { id: "beat_advanced",  name: "Strong Player",       desc: "Beat the Advanced opponent",             icon: "♜" },
  { id: "beat_master",    name: "Master Slayer",       desc: "Beat the Master opponent",               icon: "👑" },
  { id: "quick_mate",     name: "Swift Checkmate",     desc: "Win in 20 moves or fewer",               icon: "⚔︎" },
  { id: "comeback",       name: "Great Comeback",      desc: "Win after being down material",          icon: "🎭" },
  { id: "games_10",       name: "Regular",             desc: "Play 10 games",                          icon: "📖" },
  { id: "games_50",       name: "Dedicated",           desc: "Play 50 games",                          icon: "📚" },
  { id: "rating_1200",    name: "Rising",              desc: "Reach a rating of 1200",                 icon: "⭐" },
  { id: "rating_1600",    name: "Tournament Player",   desc: "Reach a rating of 1600",                 icon: "✦" },
  { id: "rating_2000",    name: "Expert",              desc: "Reach a rating of 2000",                 icon: "✧" },
];

// Standard ELO update
function updateElo(playerRating, opponentRating, score, k = 32) {
  const expected = 1 / (1 + Math.pow(10, (opponentRating - playerRating) / 400));
  const delta = k * (score - expected);
  return { newRating: Math.round(playerRating + delta), delta: Math.round(delta) };
}

// ============================================================
// LEVELING SYSTEM
// ============================================================
// Points required to complete each level (thresholds grow quadratically so it gets
// progressively harder). Level N requires 50 * N * (N+1) / 2 points.
// L1→2: 50, L2→3: 150, L3→4: 300, L4→5: 500, L5→6: 750, L10→11: 2750, L20→21: 10500
function xpForLevel(level) {
  return Math.round(50 * level * (level + 1) / 2);
}

function levelFromXp(totalXp) {
  let level = 1;
  while (xpForLevel(level) <= totalXp) level++;
  return level;
}

function xpIntoCurrentLevel(totalXp) {
  const level = levelFromXp(totalXp);
  const base = level > 1 ? xpForLevel(level - 1) : 0;
  const next = xpForLevel(level);
  return { current: totalXp - base, needed: next - base, level };
}

// Points awarded for a game result.
// Wins scale with opponent difficulty. Draws give a small amount against stronger opponents.
function xpForResult(level, result, context = {}) {
  if (result === "win") {
    const base = {
      beginner: 20,
      casual: 40,
      intermediate: 70,
      advanced: 110,
      master: 160,
    }[level] || 40;
    // Bonus for quick mate
    const bonus = context.moveCount && context.moveCount <= 20 ? 25 : 0;
    return base + bonus;
  }
  if (result === "draw") {
    return { beginner: 5, casual: 10, intermediate: 15, advanced: 25, master: 35 }[level] || 10;
  }
  return 0;
}

// ============================================================
// NICKNAMES
// ============================================================
// On level-up we pick a random distinctive nickname. Built from two word banks
// so we rarely repeat even across many levels.
const NICKNAME_PREFIXES = [
  "The Silent", "The Cunning", "The Gilded", "The Ruthless", "The Noble",
  "The Iron", "The Velvet", "The Crimson", "The Midnight", "The Patient",
  "The Shadow", "The Radiant", "The Stormborn", "The Obsidian", "The Swift",
  "The Frostbound", "The Goldenhand", "The Wise", "The Unseen", "The Relentless",
  "The Blackwood", "The Highborn", "The Winterstill", "The Everbright",
  "Lord", "Lady", "Sir", "Dame", "Captain", "Brother", "Sister",
  "The Alchemist", "The Oracle", "The Tactician", "The Whisperer",
];
const NICKNAME_EPITHETS = [
  "of the Rook", "of the Gambit", "of Caissa", "of the Open File",
  "of the Long Diagonal", "Endgame", "Knightfall", "Pawnstorm",
  "Kingslayer", "Queenmaker", "Checkweaver", "Silverboard",
  "the Calculator", "the Strategist", "the Artisan", "the Patient",
  "of Sixty-Four Squares", "of Deep Waters", "the Immortal", "Blackfire",
  "Ironblood", "Swiftfoot", "Sharp-Eye", "Stillmind",
  "of the Narrow Path", "Duskwalker", "Dawnbringer", "the Undefeated",
];

// Deterministic-ish pick based on profile + level so the same level always gives the same name
function pickNickname(seed) {
  const hash = (s) => {
    let h = 0;
    for (let i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0;
    return Math.abs(h);
  };
  const h = hash(String(seed));
  const prefix = NICKNAME_PREFIXES[h % NICKNAME_PREFIXES.length];
  const epithet = NICKNAME_EPITHETS[Math.floor(h / NICKNAME_PREFIXES.length) % NICKNAME_EPITHETS.length];
  return `${prefix} ${epithet}`;
}

// ============================================================
// AI OPPONENT NAME GENERATOR
// ============================================================
// Each difficulty level has its own pool of name parts that suit its vibe —
// beginners get friendly/quirky names, masters get intimidating/mythic ones.
// Paired with a themed emoji for visual identity.

const AI_NAMES = {
  beginner: {
    first: ["Benny", "Pip", "Winnie", "Oliver", "Milo", "Daisy", "Clover", "Chip", "Teddy", "Peanut", "Rosie", "Freddy", "Poppy", "Toby", "Ziggy"],
    last: ["Applegate", "Buttercup", "Nibbles", "Whiskers", "Sprout", "Pebble", "Puddle", "Crumble", "Tumble", "Marble", "Biscuit", "Twinkle"],
    emojis: ["🐣", "🍀", "🌼", "🐥", "🌱", "⭐", "🌸", "🎈", "🧸", "🐰", "☀️", "🍯"],
  },
  casual: {
    first: ["Alex", "Jordan", "Casey", "Sam", "Riley", "Morgan", "Quinn", "Avery", "Blake", "Dana", "Emery", "Finn"],
    last: ["Cross", "Lane", "Vale", "Wells", "Brooks", "Stone", "Reeves", "Hart", "Fields", "Shaw", "Wren", "Carter"],
    emojis: ["☕", "📖", "🎲", "🎵", "🪴", "🌊", "🍂", "🎭", "🔖", "🖋️", "🎨", "🌙"],
  },
  intermediate: {
    first: ["Anatoly", "Mira", "Viktor", "Sofia", "Dmitri", "Elena", "Boris", "Nadia", "Yuri", "Katya", "Ivan", "Lyra"],
    last: ["Volkov", "Sokolov", "Markov", "Petrova", "Kirov", "Orlova", "Ravenwood", "Ashford", "Blackthorne", "Winters", "Voss", "Valdyr"],
    emojis: ["♞", "🗡️", "🏛️", "📚", "⚜️", "🕯️", "🪙", "🪞", "🦉", "🗝️", "🍷", "🎩"],
  },
  advanced: {
    first: ["Magnus", "Seraphina", "Kasparov", "Ingrid", "Lucius", "Isolde", "Alaric", "Valentina", "Draven", "Celestia", "Theron", "Vesper"],
    last: ["Blackwood", "Stormcrow", "Ironhand", "Nightshade", "Duskbane", "Frostveil", "Drakemoor", "Shadowmere", "Ravenclaw", "Wyrmsong"],
    emojis: ["⚔️", "🦅", "🐺", "🏴", "🌑", "🗡️", "🦂", "👁️", "🦇", "🜏", "❄️", "🔥"],
  },
  master: {
    first: ["Archon", "Nyx", "Morphy", "Vesuvia", "Tal", "Medusa", "Lasker", "Ouroboros", "Capablanca", "Obsidian", "Alekhine", "Vultura"],
    last: ["the Undying", "of the Void", "Kingsbane", "Worldreaper", "the Immortal", "Doomsayer", "of Endless Night", "the Deathless", "Shadowweaver", "the Unbroken", "Stormbringer", "the Ancient"],
    emojis: ["👑", "🔱", "🐉", "💀", "☠️", "🕷️", "🦂", "⚡", "🌋", "🗿", "🜛", "♛"],
  },
};

// Deterministic per-game name: uses a seed so the same game shows the same name
function pickAiOpponent(level, seed) {
  const pool = AI_NAMES[level] || AI_NAMES.casual;
  const hash = (s) => {
    let h = 0;
    for (let i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0;
    return Math.abs(h);
  };
  const h = hash(String(seed));
  const first = pool.first[h % pool.first.length];
  const last = pool.last[Math.floor(h / pool.first.length) % pool.last.length];
  const emoji = pool.emojis[Math.floor(h / (pool.first.length * pool.last.length)) % pool.emojis.length];
  return { name: `${first} ${last}`, emoji };
}

function makeProfile(name) {
  return {
    id: "p_" + Date.now() + "_" + Math.floor(Math.random() * 10000),
    name: name.trim(),
    created: Date.now(),
    rating: 1000, // starting ELO
    xp: 0,
    level: 1,
    nicknames: [], // array of { level, name, unlockedAt }
    stats: {
      total: 0,
      wins: 0,
      losses: 0,
      draws: 0,
      resigns: 0,
      streak: 0,
      bestStreak: 0,
      byLevel: {},
    },
    achievements: {}, // id -> unlocked timestamp
  };
}

function recordGameResult(profile, level, result, context = {}) {
  // result: "win" | "loss" | "draw" | "resign"
  // context: { moveCount, wasDownMaterial }
  const p = JSON.parse(JSON.stringify(profile));
  // Backfill fields for profiles created before these features existed
  if (typeof p.rating !== "number") p.rating = 1000;
  if (!p.achievements) p.achievements = {};
  if (typeof p.xp !== "number") p.xp = 0;
  if (typeof p.level !== "number") p.level = 1;
  if (!Array.isArray(p.nicknames)) p.nicknames = [];

  p.stats.total += 1;
  if (result === "win") { p.stats.wins += 1; p.stats.streak += 1; }
  else if (result === "loss") { p.stats.losses += 1; p.stats.streak = 0; }
  else if (result === "draw") { p.stats.draws += 1; }
  else if (result === "resign") { p.stats.resigns += 1; p.stats.losses += 1; p.stats.streak = 0; }
  if (p.stats.streak > p.stats.bestStreak) p.stats.bestStreak = p.stats.streak;

  if (!p.stats.byLevel[level]) {
    p.stats.byLevel[level] = { total: 0, wins: 0, losses: 0, draws: 0 };
  }
  p.stats.byLevel[level].total += 1;
  if (result === "win") p.stats.byLevel[level].wins += 1;
  else if (result === "loss" || result === "resign") p.stats.byLevel[level].losses += 1;
  else if (result === "draw") p.stats.byLevel[level].draws += 1;

  // ELO update
  const opponentRating = LEVEL_RATINGS[level] || 1200;
  let score;
  if (result === "win") score = 1;
  else if (result === "draw") score = 0.5;
  else score = 0;
  const { newRating, delta } = updateElo(p.rating, opponentRating, score);
  p.rating = newRating;
  p.lastRatingDelta = delta;

  // Achievement checks
  const unlocked = [];
  const award = (id) => {
    if (!p.achievements[id]) {
      p.achievements[id] = Date.now();
      unlocked.push(id);
    }
  };
  if (result === "win" && p.stats.wins === 1) award("first_win");
  if (p.stats.streak >= 5) award("streak_5");
  if (p.stats.streak >= 10) award("streak_10");
  if (result === "win" && level === "intermediate") award("beat_intermediate");
  if (result === "win" && level === "advanced") award("beat_advanced");
  if (result === "win" && level === "master") award("beat_master");
  if (result === "win" && context.moveCount && context.moveCount <= 20) award("quick_mate");
  if (result === "win" && context.wasDownMaterial) award("comeback");
  if (p.stats.total >= 10) award("games_10");
  if (p.stats.total >= 50) award("games_50");
  if (p.rating >= 1200) award("rating_1200");
  if (p.rating >= 1600) award("rating_1600");
  if (p.rating >= 2000) award("rating_2000");

  // XP + leveling
  const gainedXp = xpForResult(level, result, context);
  const xpBefore = p.xp;
  const levelBefore = p.level;
  p.xp = p.xp + gainedXp;
  const newLevel = levelFromXp(p.xp);
  const levelsGained = [];
  if (newLevel > levelBefore) {
    // Possibly gained multiple levels at once
    for (let lv = levelBefore + 1; lv <= newLevel; lv++) {
      const nick = pickNickname(p.id + ":" + lv);
      p.nicknames.push({ level: lv, name: nick, unlockedAt: Date.now() });
      levelsGained.push({ level: lv, nickname: nick });
    }
    p.level = newLevel;
  }
  p.lastXpGain = gainedXp;
  p.xpBefore = xpBefore;
  p.levelsGained = levelsGained;

  p.newlyUnlocked = unlocked;
  return p;
}

// ============================================================
// MAIN APP
// ============================================================

export default function ChessApp() {
  const [screen, setScreen] = useState("loading"); // loading | profile | menu | game | stats | coord-training
  const [profiles, setProfiles] = useState([]);
  const [activeProfile, setActiveProfile] = useState(null);
  const [level, setLevel] = useState(null);
  const [playerColor, setPlayerColor] = useState("w");
  const [board, setBoard] = useState(initialBoard);
  const [state, setState] = useState({
    castling: { w: { k: true, q: true }, b: { k: true, q: true } },
    enPassant: null,
  });
  const [turn, setTurn] = useState("w");
  const [selected, setSelected] = useState(null);
  const [legalForSelected, setLegalForSelected] = useState([]);
  const [history, setHistory] = useState([]);
  const [captured, setCaptured] = useState({ w: [], b: [] });
  const [status, setStatus] = useState("");
  const [winner, setWinner] = useState(null);
  const [gameEndReason, setGameEndReason] = useState("");
  const [thinking, setThinking] = useState(false);
  const [lastMove, setLastMove] = useState(null);
  const [promotionChoice, setPromotionChoice] = useState(null);
  const [animatingMove, setAnimatingMove] = useState(null); // { from, to, piece, secondary? }
  const [musicEnabled, setMusicEnabled] = useState(true);
  const [sfxEnabled, setSfxEnabled] = useState(true);
  const [musicStyle, setMusicStyle] = useState("relaxing");
  const [newProfileName, setNewProfileName] = useState("");
  const [statsRecorded, setStatsRecorded] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(null); // holds profile to delete

  // Undo: stack of snapshots. Each entry = { board, state, turn, lastMove, captured, history }
  const [moveStack, setMoveStack] = useState([]);

  // Review mode
  const [reviewOpen, setReviewOpen] = useState(false);
  const [reviewIndex, setReviewIndex] = useState(0);
  // gameLog: per-move snapshot for review { board, state, turn, lastMove, san, color, quality?, bestMove? }
  const [gameLog, setGameLog] = useState([]);

  // Achievement toasts
  const [achievementToasts, setAchievementToasts] = useState([]);
  // Level-up modal (queue of levels gained from last game)
  const [levelUpEvent, setLevelUpEvent] = useState(null); // { levelsGained, xpBefore, xpAfter, gainedXp }

  // Current AI opponent identity (regenerated each game)
  const [aiOpponent, setAiOpponent] = useState({ name: "Opponent", emoji: "♟" });

  // Rating delta from last game
  const [lastRatingDelta, setLastRatingDelta] = useState(0);
  const [lastRatingBefore, setLastRatingBefore] = useState(null);

  // Time control selection (persists across games in session)
  const [timeControl, setTimeControl] = useState("unlimited");
  // Clock state: { w: msLeft, b: msLeft }; null timers = unlimited
  const [clock, setClock] = useState({ w: null, b: null });
  const [clockRunning, setClockRunning] = useState(false);
  const clockLastTickRef = useRef(null);

  // Hints
  const [hintsUsed, setHintsUsed] = useState(0);
  const [hintMove, setHintMove] = useState(null); // { from, to }
  const [hintThinking, setHintThinking] = useState(false);

  // Threats overlay
  const [showThreats, setShowThreats] = useState(false);

  // Settings drawer
  const [settingsOpen, setSettingsOpen] = useState(false);

  // Visual preferences
  const [boardTheme, setBoardTheme] = useState("classic");
  const [pieceSet, setPieceSet] = useState("classic");

  // Volume sliders (0..1). Kept separate from the on/off toggles.
  const [sfxVolume, setSfxVolume] = useState(0.7);
  const [musicVolume, setMusicVolume] = useState(0.35);

  // Drag-to-move state
  const [dragging, setDragging] = useState(null); // { from: [r,c], piece, x, y, legalTargets: Set<"r,c"> }

  const boardRef = useRef(null);
  const aiColor = playerColor === "w" ? "b" : "w";

  // Initial load
  useEffect(() => {
    (async () => {
      const ps = await loadProfiles();
      const active = await loadActiveId();
      setProfiles(ps);
      if (active && ps.find(p => p.id === active)) {
        setActiveProfile(ps.find(p => p.id === active));
        setScreen("menu");
      } else {
        setScreen("profile");
      }
      // Load saved visual + audio prefs
      const prefs = await loadPrefs();
      if (prefs) {
        if (prefs.boardTheme && BOARD_THEMES[prefs.boardTheme]) setBoardTheme(prefs.boardTheme);
        if (prefs.pieceSet && PIECE_SETS[prefs.pieceSet]) setPieceSet(prefs.pieceSet);
        if (typeof prefs.sfxVolume === "number") setSfxVolume(prefs.sfxVolume);
        if (typeof prefs.musicVolume === "number") setMusicVolume(prefs.musicVolume);
        if (typeof prefs.musicStyle === "string") setMusicStyle(prefs.musicStyle);
        if (typeof prefs.timeControl === "string") setTimeControl(prefs.timeControl);
      }
    })();
  }, []);

  // Persist prefs when any of them change (after initial load completes)
  const prefsLoadedRef = useRef(false);
  useEffect(() => {
    if (!prefsLoadedRef.current) {
      prefsLoadedRef.current = true;
      return;
    }
    savePrefs({ boardTheme, pieceSet, sfxVolume, musicVolume, musicStyle, timeControl });
  }, [boardTheme, pieceSet, sfxVolume, musicVolume, musicStyle, timeControl]);

  // Audio setup
  useEffect(() => {
    audioManager.setMusicEnabled(musicEnabled);
    if (screen === "game" && musicEnabled) {
      // Always stop any prior music first, then start fresh
      audioManager.stopMusic();
      audioManager.startMusic(musicStyle);
    } else {
      audioManager.stopMusic();
    }
    // Cleanup: if effect re-runs or unmounts, ensure music is stopped
    return () => {
      audioManager.stopMusic();
    };
  }, [screen, musicEnabled, musicStyle]);

  useEffect(() => {
    audioManager.setSfxEnabled(sfxEnabled);
  }, [sfxEnabled]);

  // Sync volume sliders to audio manager
  useEffect(() => {
    audioManager.setSfxVolume(sfxVolume);
  }, [sfxVolume]);
  useEffect(() => {
    audioManager.setMusicVolume(musicVolume);
  }, [musicVolume]);

  const initAudio = () => {
    audioManager.init();
    audioManager.resume();
    // Apply current volumes on first init
    audioManager.setSfxVolume(sfxVolume);
    audioManager.setMusicVolume(musicVolume);
  };

  // Global click-sound delegation: play a click whenever the user taps a <button>.
  // We skip board squares (which have their own wooden-knock SFX) and disabled buttons.
  useEffect(() => {
    const handler = (e) => {
      if (!sfxEnabled) return;
      // Walk up to find the nearest button
      const btn = e.target.closest("button");
      if (!btn) return;
      if (btn.disabled) return;
      // Skip board squares - they make their own piece sound
      if (btn.hasAttribute("data-sq")) return;
      if (btn.closest("[data-no-click-sfx]")) return;
      // Init audio on first interaction (needed for Safari autoplay policy)
      // Apply current volumes so slider settings take effect immediately
      const wasInitialized = !!audioManager.ctx;
      audioManager.init();
      audioManager.resume();
      if (!wasInitialized) {
        audioManager.setSfxVolume(sfxVolume);
        audioManager.setMusicVolume(musicVolume);
      }
      audioManager.playClick();
    };
    document.addEventListener("click", handler, { capture: true });
    return () => document.removeEventListener("click", handler, { capture: true });
  }, [sfxEnabled, sfxVolume, musicVolume]);

  // Save profiles whenever they change
  useEffect(() => {
    if (profiles.length > 0) {
      saveProfiles(profiles);
    }
  }, [profiles]);

  const createProfile = async () => {
    if (!newProfileName.trim()) return;
    const p = makeProfile(newProfileName);
    const next = [...profiles, p];
    setProfiles(next);
    setActiveProfile(p);
    await saveProfiles(next);
    await saveActiveId(p.id);
    setNewProfileName("");
    setScreen("menu");
  };

  const selectProfile = async (p) => {
    setActiveProfile(p);
    await saveActiveId(p.id);
    setScreen("menu");
  };

  const logOut = async () => {
    await saveActiveId(null);
    setActiveProfile(null);
    setScreen("profile");
  };

  const deleteProfile = async (id) => {
    const next = profiles.filter(p => p.id !== id);
    setProfiles(next);
    await saveProfiles(next);
    if (activeProfile && activeProfile.id === id) {
      await saveActiveId(null);
      setActiveProfile(null);
    }
    if (next.length === 0) {
      try { await window.storage.delete(PROFILES_KEY); } catch(e) {}
    }
  };

  const startGame = (lvl, color) => {
    initAudio();
    const initBoard = initialBoard();
    const initState = {
      castling: { w: { k: true, q: true }, b: { k: true, q: true } },
      enPassant: null,
    };
    setLevel(lvl);
    setPlayerColor(color);
    setBoard(initBoard);
    setState(initState);
    setTurn("w");
    setSelected(null);
    setLegalForSelected([]);
    setHistory([]);
    setCaptured({ w: [], b: [] });
    setStatus("");
    setWinner(null);
    setGameEndReason("");
    setLastMove(null);
    setPromotionChoice(null);
    setAnimatingMove(null);
    setStatsRecorded(false);
    setThinking(false); // ensure we don't come into new game already "thinking"
    setDragging(null);  // clear any lingering drag state
    setMoveStack([]);
    setGameLog([{
      board: cloneBoard(initBoard),
      state: initState,
      turn: "w",
      lastMove: null,
      captured: { w: [], b: [] },
      san: null,
      color: null,
    }]);
    setReviewOpen(false);
    setReviewIndex(0);
    setAchievementToasts([]);
    setLevelUpEvent(null); // clear any lingering level-up modal from previous game
    setLastRatingBefore(activeProfile?.rating ?? 1000);
    setLastRatingDelta(0);

    // Generate a new AI opponent identity for this match
    const opponentSeed = lvl + ":" + Date.now() + ":" + Math.random();
    setAiOpponent(pickAiOpponent(lvl, opponentSeed));

    // Initialize clock based on time control
    const tc = TIME_CONTROLS.find(t => t.id === timeControl);
    if (tc && tc.minutes) {
      const ms = tc.minutes * 60 * 1000;
      setClock({ w: ms, b: ms });
      setClockRunning(true);
      clockLastTickRef.current = Date.now();
    } else {
      setClock({ w: null, b: null });
      setClockRunning(false);
      clockLastTickRef.current = null;
    }

    // Reset hints & threats
    setHintsUsed(0);
    setHintMove(null);
    setHintThinking(false);
    setShowThreats(false);

    setScreen("game");
  };

  // Chess clock: ticks down the active side
  // Uses a ref to know if the clock is unlimited so we don't re-run the effect every tick.
  const clockUnlimitedRef = useRef(false);
  useEffect(() => {
    clockUnlimitedRef.current = clock.w === null;
  }, [clock.w]);

  useEffect(() => {
    if (screen !== "game") return;
    if (!clockRunning) return;
    if (winner) return;
    if (clockUnlimitedRef.current) return; // unlimited
    if (animatingMove) return;

    clockLastTickRef.current = Date.now();
    const interval = setInterval(() => {
      const now = Date.now();
      const elapsed = now - clockLastTickRef.current;
      clockLastTickRef.current = now;
      setClock(prev => {
        if (prev[turn] === null) return prev;
        const newTime = Math.max(0, prev[turn] - elapsed);
        return { ...prev, [turn]: newTime };
      });
    }, 100);
    return () => clearInterval(interval);
  }, [screen, clockRunning, turn, winner, animatingMove]);

  // Detect flag-fall
  useEffect(() => {
    if (screen !== "game") return;
    if (winner) return;
    if (clock.w === null) return;
    if (clock[turn] === 0) {
      // The side whose clock ran out loses
      setWinner(turn === "w" ? "b" : "w");
      setGameEndReason("time");
      setClockRunning(false);
    }
  }, [clock, turn, winner, screen]);

  // Game status + audio cues
  useEffect(() => {
    if (screen !== "game") return;
    if (animatingMove) return; // wait for animation
    const legal = generateLegalMoves(board, turn, state);
    if (legal.length === 0) {
      if (isInCheck(board, turn)) {
        setStatus("checkmate");
        const w = turn === "w" ? "b" : "w";
        setWinner(w);
        setGameEndReason("checkmate");
        setClockRunning(false);
      } else {
        setStatus("stalemate");
        setWinner("draw");
        setGameEndReason("stalemate");
        setClockRunning(false);
      }
    } else if (isInCheck(board, turn)) {
      setStatus("check");
      audioManager.playCheck();
    } else {
      setStatus("");
    }
  }, [board, turn, state, screen, animatingMove]);

  // Record stats when game ends
  useEffect(() => {
    if (!winner || statsRecorded || !activeProfile) return;
    let result;
    if (winner === "draw") result = "draw";
    else if (gameEndReason === "resign") result = "resign";
    else if (winner === playerColor) result = "win";
    else result = "loss";

    // Build context for achievement checks
    const moveCount = Math.ceil(history.length / 2);
    // "Was down material" = at some point during the game, the player had less material
    let wasDownMaterial = false;
    for (const entry of gameLog) {
      let w = 0, b = 0;
      for (const p of entry.captured.w) w += PIECE_VALUES[typeOf(p)];
      for (const p of entry.captured.b) b += PIECE_VALUES[typeOf(p)];
      // captured.w = pieces captured from white, so white's material deficit
      // But we store captured pieces as the ones the player TOOK. Need to think:
      // captured[playerColor] = pieces captured from the player's side.
      // If captured[playerColor] material > captured[aiColor] material, player is down.
      let playerLoss = 0, aiLoss = 0;
      for (const p of entry.captured[playerColor]) playerLoss += PIECE_VALUES[typeOf(p)];
      for (const p of entry.captured[aiColor]) aiLoss += PIECE_VALUES[typeOf(p)];
      if (playerLoss - aiLoss >= 300) { wasDownMaterial = true; break; }
    }

    const ratingBefore = activeProfile.rating ?? 1000;
    const updated = recordGameResult(activeProfile, level, result, { moveCount, wasDownMaterial });
    setLastRatingBefore(ratingBefore);
    setLastRatingDelta(updated.lastRatingDelta || 0);

    // Show achievement toasts
    if (updated.newlyUnlocked && updated.newlyUnlocked.length > 0) {
      const toasts = updated.newlyUnlocked.map(id => {
        const def = ACHIEVEMENTS.find(a => a.id === id);
        return { id, ...def };
      });
      setAchievementToasts(toasts);
    }

    // Show level-up modal if any levels were gained
    if (updated.levelsGained && updated.levelsGained.length > 0) {
      setLevelUpEvent({
        levelsGained: updated.levelsGained,
        xpBefore: updated.xpBefore,
        xpAfter: updated.xp,
        gainedXp: updated.lastXpGain,
      });
    }

    setActiveProfile(updated);
    setProfiles(prev => prev.map(p => p.id === updated.id ? updated : p));
    setStatsRecorded(true);

    setTimeout(() => {
      audioManager.playGameEnd(result === "win");
    }, 300);
  }, [winner, statsRecorded, activeProfile, gameEndReason, playerColor, level, history, gameLog, aiColor]);

  // Auto-dismiss achievement toasts one at a time
  useEffect(() => {
    if (achievementToasts.length === 0) return;
    const timer = setTimeout(() => {
      setAchievementToasts(prev => prev.slice(1));
    }, 4500);
    return () => clearTimeout(timer);
  }, [achievementToasts]);

  // AI move trigger
  useEffect(() => {
    if (screen !== "game") return;
    if (winner) return;
    if (turn !== aiColor) return;
    if (animatingMove) return;
    setThinking(true);
    // Give the UI two paint cycles to actually show "thinking…" before the engine
    // search blocks the main thread (especially important at Master depth 4).
    let cancelled = false;
    let raf1 = null, raf2 = null, timer = null;
    raf1 = requestAnimationFrame(() => {
      raf2 = requestAnimationFrame(() => {
        timer = setTimeout(() => {
          if (cancelled) return;
          try {
            const mv = pickAIMove(board, aiColor, state, level);
            if (cancelled) return;
            if (mv) executeMove(mv);
          } catch (err) {
            console.error("AI move failed:", err);
          } finally {
            if (!cancelled) setThinking(false);
          }
        }, 280);
      });
    });
    return () => {
      cancelled = true;
      if (raf1) cancelAnimationFrame(raf1);
      if (raf2) cancelAnimationFrame(raf2);
      if (timer) clearTimeout(timer);
      // Reset thinking in case we tore down mid-think
      setThinking(false);
    };
    // eslint-disable-next-line
  }, [turn, screen, winner, animatingMove]);

  // Execute move: kick off animation; actual board update happens after animation completes
  const executeMove = (mv) => {
    const piece = board[mv.from[0]][mv.from[1]];
    const target = board[mv.to[0]][mv.to[1]];
    const isCapture = !!target || mv.enPassant;
    const movingColor = colorOf(piece);

    // Compute move quality (player moves only) BEFORE committing - using depth 2 best move
    let quality = null;
    let bestMove = null;
    if (movingColor === playerColor) {
      try {
        // What does the engine think is best from this position?
        const { move: best, score: bestScore } = search(board, 2, -Infinity, Infinity, movingColor === "w", movingColor, state);
        bestMove = best;
        // Evaluate position after the played move, at same depth for fair comparison
        const { board: afterPlayed, state: afterPlayedState } = applyMove(board, mv, state);
        // From opponent's perspective at depth 1 more gives us the position evaluation
        const playedEval = -search(afterPlayed, 1, -Infinity, Infinity, movingColor !== "w", movingColor === "w" ? "b" : "w", afterPlayedState).score;
        // Same for best move
        const { board: afterBest, state: afterBestState } = applyMove(board, best, state);
        const bestEval = -search(afterBest, 1, -Infinity, Infinity, movingColor !== "w", movingColor === "w" ? "b" : "w", afterBestState).score;

        // From the moving player's perspective (positive = good)
        const playedFromMover = movingColor === "w" ? playedEval : -playedEval;
        const bestFromMover = movingColor === "w" ? bestEval : -bestEval;
        const cpLoss = bestFromMover - playedFromMover;

        if (cpLoss <= 30) quality = "good";
        else if (cpLoss <= 80) quality = "inaccuracy";
        else if (cpLoss <= 200) quality = "mistake";
        else quality = "blunder";
      } catch(e) {
        quality = null;
      }
    }

    // Set up animation
    const anim = {
      from: mv.from,
      to: mv.to,
      piece,
      move: mv,
      target,
      capturedAt: mv.enPassant
        ? [mv.to[0] + (movingColor === "w" ? 1 : -1), mv.to[1]]
        : (target ? mv.to : null),
    };
    if (mv.castle === "k") {
      anim.secondary = { from: [mv.to[0], 7], to: [mv.to[0], 5], piece: movingColor + "R" };
    } else if (mv.castle === "q") {
      anim.secondary = { from: [mv.to[0], 0], to: [mv.to[0], 3], piece: movingColor + "R" };
    }

    // Push pre-move snapshot to undo stack (for player moves only; AI moves get bundled)
    setMoveStack(prev => [...prev, {
      board: cloneBoard(board),
      state: JSON.parse(JSON.stringify(state)),
      turn,
      lastMove,
      captured: { w: [...captured.w], b: [...captured.b] },
      history: [...history],
      moverColor: movingColor,
    }]);

    setAnimatingMove(anim);
    audioManager.playMove(isCapture);
    setHintMove(null); // clear any showing hint

    const ANIM_MS = 260;
    setTimeout(() => {
      const { board: nb, state: ns } = applyMove(board, mv, state);
      let newCaptured = { w: [...captured.w], b: [...captured.b] };
      if (target) {
        const capColor = colorOf(target);
        newCaptured[capColor === "w" ? "b" : "w"].push(target);
      } else if (mv.enPassant) {
        const dir = movingColor === "w" ? 1 : -1;
        const capt = board[mv.to[0]+dir][mv.to[1]];
        if (capt) newCaptured[colorOf(capt) === "w" ? "b" : "w"].push(capt);
      }
      const san = moveToAlgebraic(board, mv, state);
      setBoard(nb);
      setState(ns);
      setTurn(movingColor === "w" ? "b" : "w");
      setSelected(null);
      setLegalForSelected([]);
      setHistory(h => [...h, { san, color: movingColor, quality, bestMove }]);
      setCaptured(newCaptured);
      setLastMove({ from: mv.from, to: mv.to });
      setAnimatingMove(null);

      // Apply increment (if any) to the mover who just finished their move
      const tc = TIME_CONTROLS.find(t => t.id === timeControl);
      if (tc && tc.minutes && tc.increment > 0) {
        setClock(prev => ({
          ...prev,
          [movingColor]: prev[movingColor] !== null ? prev[movingColor] + tc.increment * 1000 : null,
        }));
      }
      // Reset clock tick reference so the opponent's timer starts fresh
      clockLastTickRef.current = Date.now();
      // Append to game log (post-state snapshot)
      setGameLog(log => [...log, {
        board: cloneBoard(nb),
        state: ns,
        turn: movingColor === "w" ? "b" : "w",
        lastMove: { from: mv.from, to: mv.to },
        captured: newCaptured,
        san,
        color: movingColor,
        quality,
        bestMove,
      }]);
    }, ANIM_MS);
  };

  const handleSquareClick = (r, c) => {
    if (winner || thinking || turn !== playerColor || animatingMove) return;
    const piece = board[r][c];

    if (selected) {
      const moves = legalForSelected.filter(m => m.to[0] === r && m.to[1] === c);
      if (moves.length > 0) {
        if (moves.length > 1 && moves[0].promotion) {
          setPromotionChoice({ moves, from: selected, to: [r, c] });
          return;
        }
        executeMove(moves[0]);
        return;
      }
      if (piece && colorOf(piece) === playerColor) {
        const legal = generateLegalMoves(board, playerColor, state)
          .filter(m => m.from[0] === r && m.from[1] === c);
        setSelected([r, c]);
        setLegalForSelected(legal);
        return;
      }
      setSelected(null);
      setLegalForSelected([]);
      return;
    }

    if (piece && colorOf(piece) === playerColor) {
      const legal = generateLegalMoves(board, playerColor, state)
        .filter(m => m.from[0] === r && m.from[1] === c);
      setSelected([r, c]);
      setLegalForSelected(legal);
    }
  };

  const handlePromotion = (promoType) => {
    const mv = promotionChoice.moves.find(m => m.promotion === promoType);
    if (mv) executeMove(mv);
    setPromotionChoice(null);
  };

  // Drag-to-move handlers
  const handleDragStart = (r, c, clientX, clientY) => {
    if (winner || thinking || animatingMove || turn !== playerColor) return;
    const piece = board[r][c];
    if (!piece || colorOf(piece) !== playerColor) return;
    const legal = generateLegalMoves(board, playerColor, state)
      .filter(m => m.from[0] === r && m.from[1] === c);
    if (legal.length === 0) return;
    setDragging({
      from: [r, c],
      piece,
      x: clientX,
      y: clientY,
      startX: clientX,
      startY: clientY,
      hasMoved: false,
      overSquare: null,
      legalTargets: new Set(legal.map(m => `${m.to[0]},${m.to[1]}`)),
      legalMoves: legal,
    });
    // Also visually select so tap-to-move dots appear as hover target hints
    setSelected([r, c]);
    setLegalForSelected(legal);
  };

  const handleDragOver = (r, c) => {
    if (!dragging) return;
    setDragging(prev => prev ? { ...prev, overSquare: [r, c] } : prev);
  };

  const handleDragDrop = (r, c) => {
    if (!dragging) return;
    const key = `${r},${c}`;
    if (dragging.legalTargets.has(key)) {
      const moves = dragging.legalMoves.filter(m => m.to[0] === r && m.to[1] === c);
      if (moves.length > 1 && moves[0].promotion) {
        setPromotionChoice({ moves, from: dragging.from, to: [r, c] });
      } else if (moves.length > 0) {
        executeMove(moves[0]);
      }
    }
    // Clear drag state regardless
    setDragging(null);
  };

  // Global mouse/touch move listener - track pointer position for the drag ghost
  useEffect(() => {
    if (!dragging) return;
    const onMove = (e) => {
      const pt = e.touches ? e.touches[0] : e;
      if (!pt) return;

      // Detect square under pointer once, then apply all updates in a single setDragging
      let overSquare = null;
      const el = document.elementFromPoint(pt.clientX, pt.clientY);
      if (el) {
        const sqEl = el.closest("[data-sq]");
        if (sqEl) {
          const [dr, dc] = sqEl.getAttribute("data-sq").split("-").map(Number);
          overSquare = playerColor === "b" ? [7 - dr, 7 - dc] : [dr, dc];
        }
      }
      setDragging(prev => {
        if (!prev) return prev;
        const sameSquare = prev.overSquare && overSquare && prev.overSquare[0] === overSquare[0] && prev.overSquare[1] === overSquare[1];
        const dx = pt.clientX - prev.startX;
        const dy = pt.clientY - prev.startY;
        const moved = prev.hasMoved || (dx * dx + dy * dy) > 36; // 6px threshold
        return {
          ...prev,
          x: pt.clientX,
          y: pt.clientY,
          hasMoved: moved,
          overSquare: sameSquare ? prev.overSquare : overSquare,
        };
      });
    };
    const onUp = (e) => {
      // Use last known position to find drop target
      const pt = e.changedTouches ? e.changedTouches[0] : e;
      if (pt) {
        const el = document.elementFromPoint(pt.clientX, pt.clientY);
        if (el) {
          const sqEl = el.closest("[data-sq]");
          if (sqEl) {
            const [dr, dc] = sqEl.getAttribute("data-sq").split("-").map(Number);
            const [r, c] = playerColor === "b" ? [7 - dr, 7 - dc] : [dr, dc];
            handleDragDrop(r, c);
            return;
          }
        }
      }
      setDragging(null);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("touchmove", onMove, { passive: false });
    window.addEventListener("mouseup", onUp);
    window.addEventListener("touchend", onUp);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("touchmove", onMove);
      window.removeEventListener("mouseup", onUp);
      window.removeEventListener("touchend", onUp);
    };
    // eslint-disable-next-line
  }, [dragging?.from, playerColor]);

  const resign = () => {
    setWinner(aiColor);
    setStatus("resigned");
    setGameEndReason("resign");
    setClockRunning(false);
  };

  // Undo: revert the last player move (and the AI reply if any)
  const canUndo = !winner && !animatingMove && !thinking && moveStack.length > 0 && turn === playerColor;
  const undo = () => {
    if (moveStack.length === 0) return;
    // Pop until we land on a state where it's the player's turn
    // In a normal flow: player moves → AI moves → now player's turn
    // moveStack holds pre-move snapshots. The last one was the AI's pre-move (turn=AI).
    // We need to pop back to the player's pre-move snapshot (turn=player).
    let stack = [...moveStack];
    let log = [...gameLog];
    let target = null;
    // Pop AI's pre-move snapshot first (if last move was AI's)
    while (stack.length > 0) {
      const snap = stack.pop();
      // Also pop from game log
      if (log.length > 1) log.pop();
      if (snap.moverColor === playerColor) {
        target = snap;
        break;
      }
    }
    if (!target) return;
    setBoard(target.board);
    setState(target.state);
    setTurn(target.turn);
    setLastMove(target.lastMove);
    setCaptured(target.captured);
    setHistory(target.history);
    setSelected(null);
    setLegalForSelected([]);
    setStatus("");
    setMoveStack(stack);
    setGameLog(log);
    setHintMove(null); // clear hint after undo
  };

  // Hint: request the engine for a good move (depth 2 minimax)
  const canHint = !winner && !animatingMove && !thinking && !hintThinking && hintsUsed < MAX_HINTS_PER_GAME && turn === playerColor;
  const requestHint = () => {
    if (!canHint) return;
    setHintThinking(true);
    // Run on next tick so the "thinking" state can render
    setTimeout(() => {
      try {
        const { move } = search(board, 3, -Infinity, Infinity, playerColor === "w", playerColor, state);
        if (move) {
          setHintMove({ from: move.from, to: move.to });
          setHintsUsed(h => h + 1);
        }
      } catch (e) {
        // fall back: any legal move
        const legal = generateLegalMoves(board, playerColor, state);
        if (legal.length > 0) {
          setHintMove({ from: legal[0].from, to: legal[0].to });
          setHintsUsed(h => h + 1);
        }
      }
      setHintThinking(false);
    }, 50);
  };

  // Threats: find all squares (of the player's pieces) currently attacked by the opponent
  const threatenedSquares = useMemo(() => {
    if (!showThreats) return [];
    const threatened = [];
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const p = board[r][c];
        if (p && colorOf(p) === playerColor) {
          if (isSquareAttacked(board, r, c, playerColor === "w" ? "b" : "w")) {
            threatened.push([r, c]);
          }
        }
      }
    }
    return threatened;
  }, [board, playerColor, showThreats]);

  const backToMenu = () => {
    audioManager.clearMusic();
    setScreen("menu");
  };

  // Display transforms for board orientation
  const displayBoard = useMemo(() => {
    if (playerColor === "b") {
      return board.slice().reverse().map(row => row.slice().reverse());
    }
    return board;
  }, [board, playerColor]);

  const displayCoord = (dr, dc) => {
    if (playerColor === "b") return [7 - dr, 7 - dc];
    return [dr, dc];
  };

  const toDisplayCoord = (r, c) => {
    if (playerColor === "b") return [7 - r, 7 - c];
    return [r, c];
  };

  const isSelected = (r, c) => selected && selected[0] === r && selected[1] === c;
  const isLegalTarget = (r, c) => legalForSelected.some(m => m.to[0] === r && m.to[1] === c);
  const isLastMoveSquare = (r, c) =>
    lastMove && ((lastMove.from[0] === r && lastMove.from[1] === c) ||
                 (lastMove.to[0] === r && lastMove.to[1] === c));

  const kingInCheckSquare = useMemo(() => {
    if (status !== "check" && status !== "checkmate") return null;
    return findKing(board, turn);
  }, [board, turn, status]);

  const materialDiff = useMemo(() => {
    let w = 0, b = 0;
    for (const p of captured.w) w += PIECE_VALUES[typeOf(p)];
    for (const p of captured.b) b += PIECE_VALUES[typeOf(p)];
    return Math.floor((w - b) / 100);
  }, [captured]);

  // ============================================================
  // SHARED STYLES
  // ============================================================

  const appShellStyle = {
    background: "radial-gradient(ellipse at top, #3a2419 0%, #1a0f0a 55%, #0d0605 100%)",
    fontFamily: "'EB Garamond', Georgia, serif",
  };

  const globalStyles = `
    @import url('https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap');
    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    @keyframes kingPulse {
      0%, 100% { box-shadow: inset 0 0 0 3px rgba(220, 50, 47, 0.85), 0 0 20px rgba(220, 50, 47, 0.5); }
      50% { box-shadow: inset 0 0 0 3px rgba(220, 50, 47, 1), 0 0 30px rgba(220, 50, 47, 0.8); }
    }
    @keyframes modalIn {
      from { opacity: 0; transform: scale(0.92); }
      to { opacity: 1; transform: scale(1); }
    }
    @keyframes pieceFadeOut {
      0% { opacity: 1; transform: scale(1); }
      60% { opacity: 0.4; transform: scale(0.85); }
      100% { opacity: 0; transform: scale(0.5); }
    }
    .fade-up { animation: fadeUp 0.8s ease-out both; }
    .king-check { animation: kingPulse 1.2s ease-in-out infinite; }
    .modal-in { animation: modalIn 0.35s ease-out; }
    .level-card:hover .level-arrow { transform: translateX(6px); }
    .level-card:hover .level-name { color: #f4d08a; }
    .piece-sliding {
      transition: transform 0.26s cubic-bezier(0.22, 0.61, 0.36, 1);
      z-index: 20;
      pointer-events: none;
      will-change: transform;
    }
    .piece-capturing {
      animation: pieceFadeOut 0.26s ease-out forwards;
    }
    @keyframes clockPulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.5; }
    }
    .clock-critical { animation: clockPulse 0.9s ease-in-out infinite; }
    @keyframes hintPulse {
      0%, 100% { opacity: 0.4; }
      50% { opacity: 0.9; }
    }
    .hint-marker { animation: hintPulse 1.4s ease-in-out infinite; }
    @keyframes threatPulse {
      0%, 100% { opacity: 0.3; }
      50% { opacity: 0.65; }
    }
    .threat-marker { animation: threatPulse 2s ease-in-out infinite; }
    .volume-slider::-webkit-slider-thumb {
      appearance: none;
      -webkit-appearance: none;
      width: 16px;
      height: 16px;
      border-radius: 50%;
      background: #f4d08a;
      border: 1px solid #8a6d47;
      cursor: pointer;
      box-shadow: 0 1px 3px rgba(0,0,0,0.4);
    }
    .volume-slider::-moz-range-thumb {
      width: 16px;
      height: 16px;
      border-radius: 50%;
      background: #f4d08a;
      border: 1px solid #8a6d47;
      cursor: pointer;
      box-shadow: 0 1px 3px rgba(0,0,0,0.4);
    }
    .noise-bg::before {
      content: "";
      position: absolute; inset: 0;
      background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200'><filter id='n'><feTurbulence baseFrequency='0.9'/><feColorMatrix values='0 0 0 0 1 0 0 0 0 0.9 0 0 0 0 0.7 0 0 0 0.08 0'/></filter><rect width='200' height='200' filter='url(%23n)'/></svg>");
      pointer-events: none;
      mix-blend-mode: overlay;
    }
  `;

  // ============================================================
  // LOADING SCREEN
  // ============================================================
  if (screen === "loading") {
    return (
      <div className="fixed inset-0 flex items-center justify-center" style={appShellStyle}>
        <style>{globalStyles}</style>
        <div style={{ color: "#c9a97a", fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic", fontSize: "1.3rem" }}>
          Opening the chess room…
        </div>
      </div>
    );
  }

  // ============================================================
  // PROFILE SCREEN
  // ============================================================
  if (screen === "profile") {
    return (
      <div className="fixed inset-0 overflow-auto" style={appShellStyle}>
        <style>{globalStyles}</style>
        <div className="noise-bg min-h-screen relative px-6 py-12 md:py-16 max-w-3xl mx-auto">
          <div className="fade-up text-center mb-12">
            <div className="flex items-center justify-center gap-3 mb-4">
              <span style={{ fontSize: "2.5rem", color: "#d4a256" }}>♞</span>
              <span style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 300, letterSpacing: "0.4em", color: "#a88860", fontSize: "0.75rem", textTransform: "uppercase" }}>
                Welcome
              </span>
              <span style={{ fontSize: "2.5rem", color: "#d4a256" }}>♝</span>
            </div>
            <h1 style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontWeight: 500,
              fontStyle: "italic",
              color: "#f0d9a8",
              fontSize: "clamp(2.5rem, 7vw, 4.5rem)",
              lineHeight: 1,
              textShadow: "0 2px 20px rgba(212, 162, 86, 0.2)",
            }}>
              Choose Your Name
            </h1>
            <div style={{ color: "#c9a97a", fontSize: "1.05rem", fontStyle: "italic", marginTop: "1rem", opacity: 0.85 }}>
              Your games, wins and losses will be saved here.
            </div>
          </div>

          {profiles.length > 0 && (
            <div className="fade-up mb-10" style={{ animationDelay: "0.15s" }}>
              <div style={{
                fontFamily: "'Cormorant Garamond', serif",
                color: "#d4a256",
                fontSize: "0.8rem",
                letterSpacing: "0.25em",
                textTransform: "uppercase",
                marginBottom: "1rem",
                textAlign: "center",
              }}>
                Returning Player
              </div>
              <div className="space-y-2">
                {profiles.map(p => (
                  <div key={p.id} className="flex items-center gap-2">
                    <button
                      onClick={() => selectProfile(p)}
                      className="flex-1 text-left transition-all hover:scale-[1.01]"
                      style={{
                        background: "rgba(30, 18, 12, 0.6)",
                        border: "1px solid rgba(138, 109, 71, 0.3)",
                        borderRadius: "2px",
                        padding: "1rem 1.25rem",
                      }}
                    >
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <User size={20} style={{ color: "#d4a256" }} />
                          <div>
                            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1.4rem", color: "#f0d9a8" }}>
                              {p.name}
                            </div>
                            <div style={{ color: "#a88860", fontSize: "0.85rem", fontStyle: "italic" }}>
                              {p.stats.total} games · {p.stats.wins}W · {p.stats.losses}L · {p.stats.draws}D
                            </div>
                          </div>
                        </div>
                        <div style={{ color: "#d4a256", fontSize: "1.3rem" }}>→</div>
                      </div>
                    </button>
                    <button
                      onClick={() => setConfirmDelete(p)}
                      style={{
                        background: "transparent",
                        border: "1px solid rgba(138, 109, 71, 0.3)",
                        color: "#8a6d47",
                        padding: "0.5rem 0.7rem",
                        borderRadius: "2px",
                        cursor: "pointer",
                        fontSize: "0.8rem",
                      }}
                      title="Delete profile"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="fade-up" style={{ animationDelay: "0.3s" }}>
            <div style={{
              fontFamily: "'Cormorant Garamond', serif",
              color: "#d4a256",
              fontSize: "0.8rem",
              letterSpacing: "0.25em",
              textTransform: "uppercase",
              marginBottom: "1rem",
              textAlign: "center",
            }}>
              New Player
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={newProfileName}
                onChange={(e) => setNewProfileName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && createProfile()}
                placeholder="Enter your name…"
                maxLength={30}
                style={{
                  flex: 1,
                  background: "rgba(30, 18, 12, 0.6)",
                  border: "1px solid rgba(138, 109, 71, 0.4)",
                  color: "#f0d9a8",
                  padding: "0.85rem 1.1rem",
                  borderRadius: "2px",
                  fontFamily: "'EB Garamond', serif",
                  fontSize: "1.1rem",
                  outline: "none",
                }}
              />
              <button
                onClick={createProfile}
                disabled={!newProfileName.trim()}
                className="transition-transform hover:scale-105 disabled:opacity-40"
                style={{
                  background: "linear-gradient(180deg, #d4a256, #a87838)",
                  border: "none",
                  color: "#1a0f0a",
                  padding: "0.85rem 1.5rem",
                  fontFamily: "'Cormorant Garamond', serif",
                  fontStyle: "italic",
                  fontSize: "1.15rem",
                  fontWeight: 500,
                  borderRadius: "2px",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: "0.4rem",
                }}
              >
                <Plus size={16} /> Create
              </button>
            </div>
          </div>
        </div>

        {/* Delete profile confirmation modal */}
        {confirmDelete && (
          <div className="fixed inset-0 flex items-center justify-center z-50 p-4" style={{
            background: "rgba(10, 6, 4, 0.85)", backdropFilter: "blur(6px)",
          }}>
            <div className="modal-in" style={{
              background: "linear-gradient(180deg, #3a2419 0%, #1a0f0a 100%)",
              border: "1px solid rgba(212, 162, 86, 0.5)",
              padding: "2rem", borderRadius: "4px",
              maxWidth: "400px", width: "100%",
              textAlign: "center",
            }}>
              <div style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontStyle: "italic", color: "#f0d9a8",
                fontSize: "1.5rem", marginBottom: "0.5rem",
              }}>
                Delete profile?
              </div>
              <div style={{ color: "#a88860", fontSize: "1rem", marginBottom: "1.5rem" }}>
                <span style={{ color: "#e8cfa0" }}>{confirmDelete.name}</span> and their record of{" "}
                {confirmDelete.stats.total} games will be permanently erased.
              </div>
              <div className="flex gap-3 justify-center">
                <button
                  onClick={() => { deleteProfile(confirmDelete.id); setConfirmDelete(null); }}
                  style={{
                    background: "linear-gradient(180deg, #b54a3a, #7a2e24)",
                    border: "none", color: "#f0d9a8",
                    padding: "0.7rem 1.3rem",
                    fontFamily: "'Cormorant Garamond', serif",
                    fontStyle: "italic", fontSize: "1.1rem",
                    fontWeight: 500, borderRadius: "2px", cursor: "pointer",
                  }}
                  className="transition-transform hover:scale-105"
                >
                  Delete
                </button>
                <button
                  onClick={() => setConfirmDelete(null)}
                  style={{
                    background: "transparent",
                    border: "1px solid rgba(212, 162, 86, 0.4)",
                    color: "#c9a97a",
                    padding: "0.7rem 1.3rem",
                    fontFamily: "'Cormorant Garamond', serif",
                    fontStyle: "italic", fontSize: "1.1rem",
                    borderRadius: "2px", cursor: "pointer",
                  }}
                  className="transition-opacity hover:opacity-80"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ============================================================
  // MENU SCREEN
  // ============================================================
  if (screen === "menu") {
    return (
      <div className="fixed inset-0 overflow-auto" style={appShellStyle}>
        <style>{globalStyles}</style>
        <div className="noise-bg min-h-screen relative px-6 py-10 md:py-14 max-w-5xl mx-auto">
          {/* Profile bar */}
          <div className="flex items-center justify-between mb-10 fade-up">
            <div className="flex items-center gap-3">
              <div style={{
                width: "2.4rem", height: "2.4rem", borderRadius: "50%",
                background: "linear-gradient(135deg, #d4a256, #a87838)",
                display: "flex", alignItems: "center", justifyContent: "center",
                color: "#1a0f0a", fontWeight: 600, fontSize: "1.1rem",
                fontFamily: "'Cormorant Garamond', serif",
              }}>
                {activeProfile.name.charAt(0).toUpperCase()}
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span style={{ fontFamily: "'Cormorant Garamond', serif", color: "#f0d9a8", fontSize: "1.2rem", lineHeight: 1 }}>
                    {activeProfile.name}
                  </span>
                  <span style={{
                    background: "linear-gradient(180deg, #d4a256, #a87838)",
                    color: "#1a0f0a",
                    padding: "1px 8px",
                    borderRadius: "10px",
                    fontSize: "0.72rem",
                    fontFamily: "'Cormorant Garamond', serif",
                    letterSpacing: "0.08em",
                    fontWeight: 600,
                  }}>
                    LV {activeProfile.level ?? 1}
                  </span>
                  <span style={{
                    background: "rgba(212, 162, 86, 0.15)",
                    border: "1px solid rgba(212, 162, 86, 0.4)",
                    padding: "1px 8px",
                    borderRadius: "10px",
                    fontSize: "0.72rem",
                    color: "#d4a256",
                    fontFamily: "'Cormorant Garamond', serif",
                    letterSpacing: "0.05em",
                  }}>
                    {activeProfile.rating ?? 1000}
                  </span>
                </div>
                {activeProfile.nicknames && activeProfile.nicknames.length > 0 && (
                  <div style={{
                    color: "#f4d08a",
                    fontSize: "0.82rem",
                    fontStyle: "italic",
                    marginTop: "3px",
                    fontFamily: "'Cormorant Garamond', serif",
                  }}>
                    “{activeProfile.nicknames[activeProfile.nicknames.length - 1].name}”
                  </div>
                )}
                <div style={{ color: "#a88860", fontSize: "0.78rem", fontStyle: "italic", marginTop: "2px" }}>
                  {activeProfile.stats.wins} wins · {activeProfile.stats.total} games
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setScreen("coord-training")}
                className="flex items-center gap-1.5 transition-opacity hover:opacity-80"
                style={{
                  color: "#c9a97a",
                  fontFamily: "'Cormorant Garamond', serif",
                  fontStyle: "italic",
                  fontSize: "0.95rem",
                  background: "transparent", border: "none", cursor: "pointer",
                }}
              >
                <span style={{ fontSize: "0.95rem" }}>⊞</span> Train
              </button>
              <button
                onClick={() => setScreen("stats")}
                className="flex items-center gap-1.5 transition-opacity hover:opacity-80"
                style={{
                  color: "#c9a97a",
                  fontFamily: "'Cormorant Garamond', serif",
                  fontStyle: "italic",
                  fontSize: "0.95rem",
                  background: "transparent", border: "none", cursor: "pointer",
                }}
              >
                <BarChart3 size={16} /> Stats
              </button>
              <button
                onClick={logOut}
                className="flex items-center gap-1.5 transition-opacity hover:opacity-80"
                style={{
                  color: "#c9a97a",
                  fontFamily: "'Cormorant Garamond', serif",
                  fontStyle: "italic",
                  fontSize: "0.95rem",
                  background: "transparent", border: "none", cursor: "pointer",
                }}
              >
                <LogOut size={16} /> Switch
              </button>
            </div>
          </div>

          <div className="fade-up text-center mb-10 md:mb-14">
            <h1 style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontWeight: 500,
              fontStyle: "italic",
              color: "#f0d9a8",
              fontSize: "clamp(3rem, 8vw, 5.5rem)",
              lineHeight: 1,
              letterSpacing: "-0.02em",
              textShadow: "0 2px 20px rgba(212, 162, 86, 0.2)",
            }}>
              The Chess Room
            </h1>
            <div className="mt-4 max-w-xl mx-auto" style={{ color: "#c9a97a", fontSize: "1.1rem", fontStyle: "italic", opacity: 0.85 }}>
              Pull up a chair. Choose your opponent.
            </div>
            <div className="flex justify-center mt-6 gap-4 items-center" style={{ color: "#8a6d47" }}>
              <div style={{ flex: "0 0 60px", height: 1, background: "linear-gradient(to right, transparent, #8a6d47)" }} />
              <span style={{ fontSize: "1.2rem" }}>✦</span>
              <div style={{ flex: "0 0 60px", height: 1, background: "linear-gradient(to left, transparent, #8a6d47)" }} />
            </div>
          </div>

          <div className="space-y-3 mb-10">
            {LEVELS.map((lvl, idx) => (
              <button
                key={lvl.id}
                onClick={() => setLevel(lvl.id)}
                className="level-card fade-up w-full text-left group relative overflow-hidden transition-all duration-300"
                style={{
                  animationDelay: `${0.15 + idx * 0.08}s`,
                  background: level === lvl.id
                    ? "linear-gradient(135deg, rgba(212, 162, 86, 0.15), rgba(139, 69, 19, 0.1))"
                    : "rgba(30, 18, 12, 0.6)",
                  border: level === lvl.id
                    ? "1px solid rgba(212, 162, 86, 0.6)"
                    : "1px solid rgba(138, 109, 71, 0.25)",
                  borderRadius: "2px",
                  padding: "1.25rem 1.5rem",
                  backdropFilter: "blur(4px)",
                  cursor: "pointer",
                }}
              >
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-4 md:gap-6 flex-1 min-w-0">
                    <div style={{
                      fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic",
                      color: "#8a6d47", fontSize: "1.2rem", width: "2rem", flexShrink: 0,
                    }}>
                      {String(idx + 1).padStart(2, "0")}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="level-name transition-colors" style={{
                        fontFamily: "'Cormorant Garamond', serif",
                        fontSize: "clamp(1.5rem, 4vw, 1.9rem)",
                        fontWeight: 500,
                        color: level === lvl.id ? "#f4d08a" : "#e8cfa0",
                        lineHeight: 1.1,
                      }}>
                        {lvl.name}
                      </div>
                      <div style={{ color: "#a88860", fontSize: "0.95rem", fontStyle: "italic", marginTop: "0.15rem" }}>
                        {lvl.tagline}
                      </div>
                    </div>
                  </div>
                  <div className="hidden md:block text-right" style={{ color: "#8a6d47", fontSize: "0.85rem", fontStyle: "italic" }}>
                    {lvl.depth}
                  </div>
                  <div className="level-arrow transition-transform" style={{ color: level === lvl.id ? "#d4a256" : "#6b5537", fontSize: "1.5rem" }}>
                    →
                  </div>
                </div>
              </button>
            ))}
          </div>

          {level && (
            <div className="fade-up space-y-6" style={{ animationDelay: "0.1s" }}>
              <div className="text-center" style={{
                fontFamily: "'Cormorant Garamond', serif",
                color: "#a88860", fontStyle: "italic", fontSize: "1rem", letterSpacing: "0.05em",
              }}>
                — Choose your side —
              </div>
              <div className="flex gap-4 justify-center">
                {[
                  { c: "w", label: "Play as White", icon: "♔" },
                  { c: "b", label: "Play as Black", icon: "♚" },
                ].map((opt) => (
                  <button
                    key={opt.c}
                    onClick={() => setPlayerColor(opt.c)}
                    className="transition-all duration-200"
                    style={{
                      background: playerColor === opt.c
                        ? "linear-gradient(180deg, #d4a256, #a87838)"
                        : "rgba(30, 18, 12, 0.6)",
                      border: playerColor === opt.c ? "1px solid #d4a256" : "1px solid rgba(138, 109, 71, 0.4)",
                      color: playerColor === opt.c ? "#1a0f0a" : "#e8cfa0",
                      padding: "0.75rem 1.5rem",
                      borderRadius: "2px",
                      fontFamily: "'Cormorant Garamond', serif",
                      fontSize: "1.1rem",
                      fontWeight: 500,
                      cursor: "pointer",
                    }}
                  >
                    <span style={{ marginRight: "0.5rem", fontSize: "1.3rem" }}>{opt.icon}</span>
                    {opt.label}
                  </button>
                ))}
              </div>

              {/* Time control picker */}
              <div className="text-center" style={{
                fontFamily: "'Cormorant Garamond', serif",
                color: "#a88860", fontStyle: "italic", fontSize: "1rem", letterSpacing: "0.05em",
              }}>
                — Time control —
              </div>
              <div className="flex gap-2 justify-center flex-wrap">
                {TIME_CONTROLS.map((tc) => (
                  <button
                    key={tc.id}
                    onClick={() => setTimeControl(tc.id)}
                    className="transition-all duration-200"
                    style={{
                      background: timeControl === tc.id
                        ? "linear-gradient(180deg, #d4a256, #a87838)"
                        : "rgba(30, 18, 12, 0.6)",
                      border: timeControl === tc.id ? "1px solid #d4a256" : "1px solid rgba(138, 109, 71, 0.4)",
                      color: timeControl === tc.id ? "#1a0f0a" : "#e8cfa0",
                      padding: "0.55rem 1rem",
                      borderRadius: "2px",
                      fontFamily: "'Cormorant Garamond', serif",
                      fontSize: "0.95rem",
                      fontWeight: 500,
                      cursor: "pointer",
                      textAlign: "center",
                      minWidth: "6rem",
                    }}
                  >
                    <div style={{ fontSize: "1rem", lineHeight: 1.1 }}>{tc.name}</div>
                    <div style={{
                      fontSize: "0.75rem",
                      fontStyle: "italic",
                      opacity: 0.75,
                      marginTop: "2px",
                    }}>
                      {tc.tagline}
                    </div>
                  </button>
                ))}
              </div>

              <div className="flex justify-center pt-2">
                <button
                  onClick={() => startGame(level, playerColor)}
                  className="group relative overflow-hidden transition-all duration-300 hover:scale-105"
                  style={{
                    background: "linear-gradient(180deg, #3a2419 0%, #1a0f0a 100%)",
                    border: "1px solid #d4a256",
                    color: "#f0d9a8",
                    padding: "1rem 3rem",
                    fontFamily: "'Cormorant Garamond', serif",
                    fontStyle: "italic",
                    fontSize: "1.4rem",
                    fontWeight: 500,
                    letterSpacing: "0.05em",
                    cursor: "pointer",
                    boxShadow: "0 4px 20px rgba(212, 162, 86, 0.25)",
                  }}
                >
                  Begin the Game
                  <span style={{ marginLeft: "0.75rem" }}>♟</span>
                </button>
              </div>
            </div>
          )}

          <div className="text-center mt-16" style={{ color: "#5c4628", fontSize: "0.8rem", letterSpacing: "0.2em" }}>
            ♔ ♕ ♖ ♗ ♘ ♙
          </div>
        </div>
      </div>
    );
  }

  // ============================================================
  // STATS SCREEN
  // ============================================================
  if (screen === "stats") {
    const s = activeProfile.stats;
    const winRate = s.total > 0 ? Math.round((s.wins / s.total) * 100) : 0;

    return (
      <div className="fixed inset-0 overflow-auto" style={appShellStyle}>
        <style>{globalStyles}</style>
        <div className="min-h-screen px-6 py-10 max-w-4xl mx-auto">
          <button
            onClick={() => setScreen("menu")}
            className="flex items-center gap-2 mb-8 transition-opacity hover:opacity-80"
            style={{
              color: "#c9a97a",
              fontFamily: "'Cormorant Garamond', serif",
              fontStyle: "italic",
              fontSize: "1.05rem",
              background: "transparent", border: "none", cursor: "pointer",
            }}
          >
            <ChevronLeft size={18} /> Back
          </button>

          <div className="fade-up text-center mb-10">
            <div style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontWeight: 300, letterSpacing: "0.4em", color: "#a88860",
              fontSize: "0.75rem", textTransform: "uppercase", marginBottom: "0.75rem",
            }}>
              {activeProfile.name}'s Record
            </div>
            <h2 style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontWeight: 500, fontStyle: "italic",
              color: "#f0d9a8", fontSize: "clamp(2.5rem, 6vw, 4rem)",
              lineHeight: 1,
            }}>
              The Ledger
            </h2>
          </div>

          {/* Level hero */}
          {(() => {
            const xpInfo = xpIntoCurrentLevel(activeProfile.xp ?? 0);
            const pct = Math.min(100, Math.round((xpInfo.current / xpInfo.needed) * 100));
            const currentNick = activeProfile.nicknames && activeProfile.nicknames.length > 0
              ? activeProfile.nicknames[activeProfile.nicknames.length - 1].name
              : null;
            return (
              <div className="fade-up mb-3" style={{
                animationDelay: "0.03s",
                background: "linear-gradient(135deg, rgba(244, 208, 138, 0.12), rgba(139, 69, 19, 0.08))",
                border: "1px solid rgba(244, 208, 138, 0.35)",
                borderRadius: "2px",
                padding: "1.25rem 1.5rem",
              }}>
                <div className="flex items-baseline justify-between gap-3 flex-wrap">
                  <div>
                    <div style={{
                      color: "#a88860", fontSize: "0.72rem",
                      letterSpacing: "0.25em", textTransform: "uppercase",
                    }}>
                      Level
                    </div>
                    <div style={{
                      fontFamily: "'Cormorant Garamond', serif",
                      fontSize: "2.6rem",
                      color: "#f4d08a",
                      lineHeight: 1,
                      fontWeight: 500,
                    }}>
                      {xpInfo.level}
                    </div>
                  </div>
                  {currentNick && (
                    <div style={{
                      fontFamily: "'Cormorant Garamond', serif",
                      fontStyle: "italic",
                      color: "#f0d9a8",
                      fontSize: "1.1rem",
                      textAlign: "right",
                      flex: 1,
                      minWidth: 0,
                    }}>
                      “{currentNick}”
                    </div>
                  )}
                </div>
                <div className="mt-3" style={{
                  height: "6px",
                  background: "rgba(138, 109, 71, 0.2)",
                  borderRadius: "3px",
                  overflow: "hidden",
                }}>
                  <div style={{
                    height: "100%",
                    width: `${pct}%`,
                    background: "linear-gradient(90deg, #a87838, #f4d08a)",
                  }} />
                </div>
                <div style={{
                  color: "#8a6d47",
                  fontSize: "0.75rem",
                  fontStyle: "italic",
                  marginTop: "4px",
                  textAlign: "right",
                }}>
                  {xpInfo.current} / {xpInfo.needed} XP to level {xpInfo.level + 1}
                </div>
              </div>
            );
          })()}

          {/* Rating hero */}
          <div className="fade-up mb-6" style={{
            animationDelay: "0.05s",
            background: "linear-gradient(135deg, rgba(212, 162, 86, 0.12), rgba(139, 69, 19, 0.08))",
            border: "1px solid rgba(212, 162, 86, 0.4)",
            borderRadius: "2px",
            padding: "1.5rem",
            textAlign: "center",
          }}>
            <div style={{
              color: "#a88860", fontSize: "0.75rem",
              letterSpacing: "0.25em", textTransform: "uppercase",
              marginBottom: "0.25rem",
            }}>
              Current Rating
            </div>
            <div style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontSize: "clamp(3rem, 9vw, 5rem)",
              color: "#f0d9a8",
              fontWeight: 500,
              lineHeight: 1,
              textShadow: "0 2px 20px rgba(212, 162, 86, 0.3)",
            }}>
              {activeProfile.rating ?? 1000}
            </div>
            <div style={{ color: "#c9a97a", fontSize: "0.9rem", fontStyle: "italic", marginTop: "0.4rem" }}>
              {(() => {
                const r = activeProfile.rating ?? 1000;
                if (r < 900) return "Novice";
                if (r < 1200) return "Beginner";
                if (r < 1500) return "Amateur";
                if (r < 1800) return "Club player";
                if (r < 2000) return "Strong club player";
                if (r < 2200) return "Expert";
                return "Master strength";
              })()}
            </div>
          </div>

          {/* Big stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8 fade-up" style={{ animationDelay: "0.1s" }}>
            {[
              { label: "Games", value: s.total },
              { label: "Wins", value: s.wins },
              { label: "Losses", value: s.losses },
              { label: "Draws", value: s.draws },
            ].map((stat) => (
              <div key={stat.label} style={{
                background: "rgba(30, 18, 12, 0.6)",
                border: "1px solid rgba(138, 109, 71, 0.3)",
                borderRadius: "2px",
                padding: "1.25rem 1rem",
                textAlign: "center",
              }}>
                <div style={{
                  fontFamily: "'Cormorant Garamond', serif",
                  fontSize: "2.8rem", color: "#d4a256", lineHeight: 1, fontWeight: 500,
                }}>
                  {stat.value}
                </div>
                <div style={{
                  color: "#a88860", fontSize: "0.75rem",
                  letterSpacing: "0.2em", textTransform: "uppercase", marginTop: "0.4rem",
                }}>
                  {stat.label}
                </div>
              </div>
            ))}
          </div>

          <div className="grid md:grid-cols-2 gap-3 mb-8 fade-up" style={{ animationDelay: "0.2s" }}>
            <div style={{
              background: "rgba(30, 18, 12, 0.6)",
              border: "1px solid rgba(138, 109, 71, 0.3)",
              borderRadius: "2px",
              padding: "1.5rem",
            }}>
              <div style={{ color: "#a88860", fontSize: "0.75rem", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: "0.75rem" }}>
                Win Rate
              </div>
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "3rem", color: "#f0d9a8", lineHeight: 1 }}>
                {winRate}<span style={{ color: "#8a6d47", fontSize: "1.8rem" }}>%</span>
              </div>
              <div style={{
                height: "6px", background: "rgba(138, 109, 71, 0.2)",
                borderRadius: "3px", marginTop: "0.75rem", overflow: "hidden",
              }}>
                <div style={{
                  height: "100%",
                  width: `${winRate}%`,
                  background: "linear-gradient(90deg, #a87838, #d4a256)",
                  transition: "width 0.8s ease",
                }} />
              </div>
            </div>
            <div style={{
              background: "rgba(30, 18, 12, 0.6)",
              border: "1px solid rgba(138, 109, 71, 0.3)",
              borderRadius: "2px",
              padding: "1.5rem",
            }}>
              <div style={{ color: "#a88860", fontSize: "0.75rem", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: "0.75rem" }}>
                Win Streaks
              </div>
              <div className="flex items-baseline gap-4">
                <div>
                  <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "2.5rem", color: "#f0d9a8", lineHeight: 1 }}>
                    {s.streak}
                  </div>
                  <div style={{ color: "#a88860", fontSize: "0.8rem", fontStyle: "italic" }}>current</div>
                </div>
                <div style={{ color: "#5c4628" }}>|</div>
                <div>
                  <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "2.5rem", color: "#d4a256", lineHeight: 1 }}>
                    {s.bestStreak}
                  </div>
                  <div style={{ color: "#a88860", fontSize: "0.8rem", fontStyle: "italic" }}>personal best</div>
                </div>
              </div>
            </div>
          </div>

          {/* By level */}
          <div className="fade-up" style={{ animationDelay: "0.3s" }}>
            <div style={{
              fontFamily: "'Cormorant Garamond', serif",
              color: "#d4a256",
              fontSize: "0.8rem", letterSpacing: "0.25em",
              textTransform: "uppercase", marginBottom: "1rem",
            }}>
              By Difficulty
            </div>
            <div className="space-y-2">
              {LEVELS.map(lvl => {
                const ls = s.byLevel[lvl.id] || { total: 0, wins: 0, losses: 0, draws: 0 };
                const lwr = ls.total > 0 ? Math.round((ls.wins / ls.total) * 100) : 0;
                return (
                  <div key={lvl.id} style={{
                    background: "rgba(30, 18, 12, 0.5)",
                    border: "1px solid rgba(138, 109, 71, 0.25)",
                    borderRadius: "2px",
                    padding: "1rem 1.25rem",
                  }}>
                    <div className="flex items-center justify-between gap-4">
                      <div style={{
                        fontFamily: "'Cormorant Garamond', serif",
                        fontSize: "1.3rem", color: "#e8cfa0", fontWeight: 500, minWidth: "9rem",
                      }}>
                        {lvl.name}
                      </div>
                      <div className="flex-1" style={{
                        height: "4px", background: "rgba(138, 109, 71, 0.15)",
                        borderRadius: "2px", overflow: "hidden",
                      }}>
                        <div style={{
                          height: "100%", width: `${lwr}%`,
                          background: "linear-gradient(90deg, #a87838, #d4a256)",
                        }} />
                      </div>
                      <div style={{ color: "#c9a97a", fontSize: "0.9rem", fontStyle: "italic", minWidth: "10rem", textAlign: "right" }}>
                        {ls.wins}W · {ls.losses}L · {ls.draws}D
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Achievements */}
          <div className="fade-up mt-8" style={{ animationDelay: "0.4s" }}>
            <div className="flex items-baseline justify-between mb-3">
              <div style={{
                fontFamily: "'Cormorant Garamond', serif",
                color: "#d4a256",
                fontSize: "0.8rem", letterSpacing: "0.25em",
                textTransform: "uppercase",
              }}>
                Achievements
              </div>
              <div style={{ color: "#a88860", fontSize: "0.85rem", fontStyle: "italic" }}>
                {Object.keys(activeProfile.achievements || {}).length} / {ACHIEVEMENTS.length} unlocked
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {ACHIEVEMENTS.map(a => {
                const unlocked = !!(activeProfile.achievements && activeProfile.achievements[a.id]);
                return (
                  <div key={a.id} style={{
                    background: unlocked ? "rgba(212, 162, 86, 0.1)" : "rgba(30, 18, 12, 0.4)",
                    border: unlocked ? "1px solid rgba(212, 162, 86, 0.45)" : "1px solid rgba(138, 109, 71, 0.2)",
                    borderRadius: "2px",
                    padding: "0.85rem 1rem",
                    display: "flex",
                    alignItems: "center",
                    gap: "0.8rem",
                    opacity: unlocked ? 1 : 0.55,
                    transition: "all 0.2s ease",
                  }}>
                    <span style={{
                      fontSize: "1.8rem",
                      filter: unlocked ? "none" : "grayscale(1)",
                      flexShrink: 0,
                    }}>
                      {a.icon}
                    </span>
                    <div className="min-w-0">
                      <div style={{
                        fontFamily: "'Cormorant Garamond', serif",
                        color: unlocked ? "#f0d9a8" : "#8a6d47",
                        fontSize: "1.05rem",
                        lineHeight: 1.1,
                        fontWeight: 500,
                      }}>
                        {a.name}
                      </div>
                      <div style={{
                        color: unlocked ? "#c9a97a" : "#6b5537",
                        fontSize: "0.8rem",
                        marginTop: "0.15rem",
                      }}>
                        {a.desc}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Titles / Nicknames */}
          {activeProfile.nicknames && activeProfile.nicknames.length > 0 && (
            <div className="fade-up mt-8" style={{ animationDelay: "0.5s" }}>
              <div className="flex items-baseline justify-between mb-3">
                <div style={{
                  fontFamily: "'Cormorant Garamond', serif",
                  color: "#d4a256",
                  fontSize: "0.8rem", letterSpacing: "0.25em",
                  textTransform: "uppercase",
                }}>
                  Titles Earned
                </div>
                <div style={{ color: "#a88860", fontSize: "0.85rem", fontStyle: "italic" }}>
                  {activeProfile.nicknames.length} {activeProfile.nicknames.length === 1 ? "title" : "titles"}
                </div>
              </div>
              <div className="space-y-1.5">
                {[...activeProfile.nicknames].reverse().map((n, i) => (
                  <div key={n.level} style={{
                    background: i === 0 ? "rgba(244, 208, 138, 0.1)" : "rgba(30, 18, 12, 0.5)",
                    border: i === 0 ? "1px solid rgba(244, 208, 138, 0.4)" : "1px solid rgba(138, 109, 71, 0.25)",
                    borderRadius: "2px",
                    padding: "0.6rem 1rem",
                    display: "flex",
                    alignItems: "center",
                    gap: "0.9rem",
                  }}>
                    <div style={{
                      width: "2.2rem",
                      textAlign: "center",
                      fontFamily: "'Cormorant Garamond', serif",
                      color: i === 0 ? "#f4d08a" : "#8a6d47",
                      fontSize: "0.85rem",
                      fontStyle: "italic",
                      letterSpacing: "0.05em",
                      flexShrink: 0,
                    }}>
                      LV {n.level}
                    </div>
                    <div style={{
                      fontFamily: "'Cormorant Garamond', serif",
                      fontStyle: "italic",
                      color: i === 0 ? "#f0d9a8" : "#c9a97a",
                      fontSize: "1.05rem",
                      flex: 1,
                      minWidth: 0,
                    }}>
                      “{n.name}”
                    </div>
                    {i === 0 && (
                      <span style={{
                        color: "#f4d08a",
                        fontSize: "0.7rem",
                        fontStyle: "italic",
                        letterSpacing: "0.15em",
                        textTransform: "uppercase",
                      }}>
                        Current
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ============================================================
  // COORDINATE TRAINING SCREEN
  // ============================================================
  if (screen === "coord-training") {
    return (
      <CoordTraining
        onBack={() => setScreen("menu")}
        theme={BOARD_THEMES[boardTheme]}
        playerColor={playerColor}
        profile={activeProfile}
        onBestScore={(newBest) => {
          const updated = { ...activeProfile, coordBest: newBest };
          setActiveProfile(updated);
          setProfiles(prev => prev.map(p => p.id === updated.id ? updated : p));
          saveProfiles(profiles.map(p => p.id === updated.id ? updated : p));
        }}
        initAudio={initAudio}
      />
    );
  }

  // ============================================================
  // GAME SCREEN
  // ============================================================
  const sideToMoveText = winner
    ? winner === "draw"
      ? "A draw by stalemate"
      : `${winner === "w" ? "White" : "Black"} wins`
    : turn === playerColor
      ? "Your move"
      : thinking ? "Thinking…" : "Opponent's turn";

  return (
    <div className="fixed inset-0 overflow-auto" style={appShellStyle}>
      <style>{globalStyles}</style>
      <div className="min-h-screen px-3 md:px-6 py-4 md:py-6 max-w-6xl mx-auto">
        {/* Top bar */}
        <div className="flex items-center justify-between mb-3 gap-2">
          <button
            onClick={backToMenu}
            className="flex items-center gap-2 transition-opacity hover:opacity-80"
            style={{
              color: "#c9a97a",
              fontFamily: "'Cormorant Garamond', serif",
              fontStyle: "italic", fontSize: "1.05rem",
              background: "transparent", border: "none", cursor: "pointer",
            }}
          >
            <ChevronLeft size={18} />
            Menu
          </button>
          <div className="flex items-center gap-2">
            <div style={{
              fontFamily: "'Cormorant Garamond', serif",
              color: "#d4a256", fontSize: "1.05rem",
              letterSpacing: "0.15em", textTransform: "uppercase",
            }}>
              {LEVELS.find(l => l.id === level)?.name}
            </div>
            <span style={{ color: "#5c4628" }}>·</span>
            <div style={{
              fontFamily: "'Cormorant Garamond', serif",
              color: "#c9a97a",
              fontSize: "0.9rem",
              fontStyle: "italic",
            }}>
              {activeProfile.rating ?? 1000}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={undo}
              disabled={!canUndo}
              className="flex items-center gap-1.5 transition-opacity hover:opacity-80 disabled:opacity-30"
              style={{
                color: "#c9a97a",
                fontFamily: "'Cormorant Garamond', serif",
                fontStyle: "italic", fontSize: "1.05rem",
                background: "transparent", border: "none",
                cursor: canUndo ? "pointer" : "not-allowed",
              }}
            >
              <RotateCcw size={16} />
              Undo
            </button>
            <button
              onClick={resign}
              disabled={!!winner}
              className="flex items-center gap-1.5 transition-opacity hover:opacity-80 disabled:opacity-30"
              style={{
                color: "#c9a97a",
                fontFamily: "'Cormorant Garamond', serif",
                fontStyle: "italic", fontSize: "1.05rem",
                background: "transparent", border: "none", cursor: "pointer",
              }}
            >
              <Flag size={16} />
              Resign
            </button>
            <button
              onClick={() => { initAudio(); setSettingsOpen(true); }}
              className="transition-opacity hover:opacity-80"
              style={{
                color: "#c9a97a",
                background: "transparent",
                border: "none",
                cursor: "pointer",
                padding: "4px",
                display: "flex",
                alignItems: "center",
              }}
              aria-label="Settings"
            >
              <Settings size={18} />
            </button>
          </div>
        </div>

        {/* Inline quick action: Hint only (settings moved to drawer) */}
        <div className="flex items-center justify-center mb-3">
          <button
            onClick={requestHint}
            disabled={!canHint}
            className="flex items-center gap-1.5 transition-opacity hover:opacity-80 disabled:opacity-40"
            style={{
              background: hintMove ? "linear-gradient(180deg, rgba(244, 208, 138, 0.25), rgba(168, 120, 56, 0.15))" : "rgba(212, 162, 86, 0.12)",
              border: "1px solid rgba(244, 208, 138, 0.4)",
              color: "#f4d08a",
              padding: "0.4rem 1rem",
              fontFamily: "'Cormorant Garamond', serif",
              fontStyle: "italic", fontSize: "0.95rem",
              borderRadius: "2px",
              cursor: canHint ? "pointer" : "not-allowed",
            }}
          >
            <Lightbulb size={14} />
            {hintThinking ? "Thinking…" : "Hint"}
            <span style={{ opacity: 0.7, fontSize: "0.8rem", marginLeft: "0.2rem" }}>
              {MAX_HINTS_PER_GAME - hintsUsed}/{MAX_HINTS_PER_GAME}
            </span>
          </button>
        </div>

        <div className="grid lg:grid-cols-[1fr_280px] gap-6">
          <div>
            <PlayerPanel
              name={aiOpponent.name}
              emoji={aiOpponent.emoji}
              color={aiColor}
              captured={captured[aiColor]}
              materialDiff={aiColor === "w" ? materialDiff : -materialDiff}
              isActive={turn === aiColor && !winner}
              thinking={thinking}
              clockMs={clock[aiColor]}
              pieceSet={PIECE_SETS[pieceSet]}
            />

            <div className="my-3">
              <ChessBoard
                ref={boardRef}
                displayBoard={displayBoard}
                playerColor={playerColor}
                onSquareClick={(dr, dc) => {
                  const [r, c] = displayCoord(dr, dc);
                  handleSquareClick(r, c);
                }}
                isSelected={(dr, dc) => {
                  const [r, c] = displayCoord(dr, dc);
                  return isSelected(r, c);
                }}
                isLegalTarget={(dr, dc) => {
                  const [r, c] = displayCoord(dr, dc);
                  return isLegalTarget(r, c);
                }}
                isLastMove={(dr, dc) => {
                  const [r, c] = displayCoord(dr, dc);
                  return isLastMoveSquare(r, c);
                }}
                isKingInCheck={(dr, dc) => {
                  if (!kingInCheckSquare) return false;
                  const [r, c] = displayCoord(dr, dc);
                  return kingInCheckSquare[0] === r && kingInCheckSquare[1] === c;
                }}
                isHintFrom={(dr, dc) => {
                  if (!hintMove) return false;
                  const [r, c] = displayCoord(dr, dc);
                  return hintMove.from[0] === r && hintMove.from[1] === c;
                }}
                isHintTo={(dr, dc) => {
                  if (!hintMove) return false;
                  const [r, c] = displayCoord(dr, dc);
                  return hintMove.to[0] === r && hintMove.to[1] === c;
                }}
                isThreatened={(dr, dc) => {
                  if (!showThreats) return false;
                  const [r, c] = displayCoord(dr, dc);
                  return threatenedSquares.some(([tr, tc]) => tr === r && tc === c);
                }}
                animatingMove={animatingMove}
                toDisplayCoord={toDisplayCoord}
                theme={BOARD_THEMES[boardTheme]}
                pieceSet={PIECE_SETS[pieceSet]}
                onPieceDragStart={(dr, dc, x, y) => {
                  const [r, c] = displayCoord(dr, dc);
                  handleDragStart(r, c, x, y);
                }}
                onDragOverSquare={(dr, dc) => {
                  const [r, c] = displayCoord(dr, dc);
                  handleDragOver(r, c);
                }}
                onDropSquare={(dr, dc) => {
                  const [r, c] = displayCoord(dr, dc);
                  handleDragDrop(r, c);
                }}
                draggingFrom={dragging && dragging.hasMoved ? toDisplayCoord(dragging.from[0], dragging.from[1]) : null}
              />
            </div>

            <PlayerPanel
              name={activeProfile.name}
              color={playerColor}
              captured={captured[playerColor]}
              materialDiff={playerColor === "w" ? materialDiff : -materialDiff}
              isActive={turn === playerColor && !winner}
              clockMs={clock[playerColor]}
              pieceSet={PIECE_SETS[pieceSet]}
            />

            <div className="mt-3 text-center" style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontStyle: "italic",
              color: status === "check" ? "#e85c44" : "#c9a97a",
              fontSize: "1.1rem", letterSpacing: "0.05em",
            }}>
              {status === "check" && !winner && "Check! "}
              {sideToMoveText}
            </div>
          </div>

          <div className="hidden lg:block" style={{
            background: "rgba(30, 18, 12, 0.6)",
            border: "1px solid rgba(138, 109, 71, 0.3)",
            borderRadius: "2px", padding: "1.25rem",
            backdropFilter: "blur(4px)",
            maxHeight: "70vh", overflowY: "auto",
          }}>
            <div style={{
              fontFamily: "'Cormorant Garamond', serif",
              color: "#d4a256",
              fontSize: "0.8rem", letterSpacing: "0.2em",
              textTransform: "uppercase", marginBottom: "0.75rem",
              paddingBottom: "0.5rem",
              borderBottom: "1px solid rgba(138, 109, 71, 0.3)",
            }}>
              Notation
            </div>
            {history.length === 0 ? (
              <div style={{ color: "#6b5537", fontStyle: "italic", fontSize: "0.95rem" }}>
                The board awaits…
              </div>
            ) : (
              <div style={{ fontFamily: "'EB Garamond', serif", color: "#e8cfa0", fontSize: "0.95rem" }}>
                {Array.from({ length: Math.ceil(history.length / 2) }, (_, i) => {
                  const w = history[i * 2];
                  const b = history[i * 2 + 1];
                  return (
                    <div key={i} className="flex py-0.5">
                      <span style={{ color: "#8a6d47", width: "2rem", fontStyle: "italic" }}>{i + 1}.</span>
                      <span style={{ width: "5rem" }}>{w?.san}</span>
                      <span style={{ width: "5rem" }}>{b?.san || ""}</span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {promotionChoice && (
        <div className="fixed inset-0 flex items-center justify-center z-50 p-4" style={{
          background: "rgba(10, 6, 4, 0.85)", backdropFilter: "blur(6px)",
        }}>
          <div className="modal-in" style={{
            background: "linear-gradient(180deg, #3a2419 0%, #1a0f0a 100%)",
            border: "1px solid rgba(212, 162, 86, 0.5)",
            padding: "2rem", borderRadius: "4px",
            maxWidth: "400px", width: "100%",
          }}>
            <div className="text-center mb-5" style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontStyle: "italic", color: "#f0d9a8", fontSize: "1.5rem",
            }}>
              Promote your pawn
            </div>
            <div className="grid grid-cols-4 gap-2">
              {["Q", "R", "B", "N"].map((p) => {
                const ps = PIECE_SETS[pieceSet];
                const isWhite = playerColor === "w";
                return (
                  <button
                    key={p}
                    onClick={() => handlePromotion(p)}
                    className="transition-transform hover:scale-110"
                    style={{
                      background: "rgba(138, 109, 71, 0.15)",
                      border: "1px solid rgba(138, 109, 71, 0.4)",
                      borderRadius: "2px", padding: "1rem",
                      fontSize: "2.5rem",
                      color: isWhite ? ps.whiteColor : ps.blackColor,
                      textShadow: isWhite ? ps.whiteShadow : ps.blackShadow,
                      fontFamily: ps.fontFamily,
                      fontWeight: ps.weight,
                      cursor: "pointer",
                    }}
                  >
                    {ps.glyphs[playerColor + p]}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {winner && !reviewOpen && (
        <div className="fixed inset-0 flex items-center justify-center z-50 p-4" style={{
          background: "rgba(10, 6, 4, 0.88)", backdropFilter: "blur(6px)",
        }}>
          <div className="modal-in text-center" style={{
            background: "linear-gradient(180deg, #3a2419 0%, #1a0f0a 100%)",
            border: "1px solid rgba(212, 162, 86, 0.5)",
            padding: "2.5rem 2rem", borderRadius: "4px",
            maxWidth: "440px", width: "100%",
            boxShadow: "0 10px 60px rgba(212, 162, 86, 0.15)",
          }}>
            <div className="flex justify-center mb-3">
              {winner === "draw" ? (
                <span style={{ fontSize: "3rem", color: "#d4a256" }}>½–½</span>
              ) : (
                <Trophy size={52} style={{ color: winner === playerColor ? "#d4a256" : "#8a6d47" }} />
              )}
            </div>
            <div style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontStyle: "italic", color: "#f0d9a8",
              fontSize: "2.2rem", lineHeight: 1.1,
            }}>
              {winner === "draw" ? "Drawn Game" : winner === playerColor ? "Victory" : "Defeat"}
            </div>
            <div className="mt-2 mb-4" style={{ color: "#a88860", fontStyle: "italic", fontSize: "1.05rem" }}>
              {gameEndReason === "checkmate" && (winner === playerColor ? "A fine checkmate." : "Checkmate. Well played.")}
              {gameEndReason === "stalemate" && "Stalemate — neither side could claim the day."}
              {gameEndReason === "resign" && "You resigned the game."}
              {gameEndReason === "time" && (winner === playerColor ? "Opponent ran out of time." : "Your clock ran out.")}
            </div>

            {/* Rating change */}
            {statsRecorded && lastRatingBefore !== null && (
              <div style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "0.6rem",
                background: "rgba(212, 162, 86, 0.08)",
                border: "1px solid rgba(138, 109, 71, 0.3)",
                borderRadius: "2px",
                padding: "0.55rem 1rem",
                marginBottom: "0.75rem",
              }}>
                <span style={{ color: "#a88860", fontSize: "0.75rem", letterSpacing: "0.2em", textTransform: "uppercase" }}>
                  Rating
                </span>
                <span style={{ fontFamily: "'Cormorant Garamond', serif", color: "#e8cfa0", fontSize: "1.3rem" }}>
                  {lastRatingBefore}
                </span>
                <span style={{ color: "#6b5537" }}>→</span>
                <span style={{ fontFamily: "'Cormorant Garamond', serif", color: "#f0d9a8", fontSize: "1.3rem", fontWeight: 500 }}>
                  {(activeProfile.rating ?? lastRatingBefore)}
                </span>
                <span style={{
                  color: lastRatingDelta > 0 ? "#7ac96d" : lastRatingDelta < 0 ? "#e85c44" : "#a88860",
                  fontSize: "0.9rem",
                  fontStyle: "italic",
                }}>
                  ({lastRatingDelta > 0 ? "+" : ""}{lastRatingDelta})
                </span>
              </div>
            )}

            {/* XP progress */}
            {statsRecorded && activeProfile.xp !== undefined && (() => {
              const xpInfo = xpIntoCurrentLevel(activeProfile.xp);
              const pct = Math.min(100, Math.round((xpInfo.current / xpInfo.needed) * 100));
              const gained = activeProfile.lastXpGain || 0;
              return (
                <div style={{
                  background: "rgba(212, 162, 86, 0.08)",
                  border: "1px solid rgba(138, 109, 71, 0.3)",
                  borderRadius: "2px",
                  padding: "0.75rem 1rem",
                  marginBottom: "1.25rem",
                  maxWidth: "360px",
                  marginLeft: "auto",
                  marginRight: "auto",
                }}>
                  <div className="flex items-center justify-between mb-1.5">
                    <span style={{ color: "#a88860", fontSize: "0.72rem", letterSpacing: "0.2em", textTransform: "uppercase" }}>
                      Level {xpInfo.level}
                    </span>
                    <span style={{ color: gained > 0 ? "#7ac96d" : "#8a6d47", fontSize: "0.85rem", fontStyle: "italic" }}>
                      {gained > 0 ? `+${gained} XP` : "No XP"}
                    </span>
                  </div>
                  <div style={{
                    height: "6px",
                    background: "rgba(138, 109, 71, 0.2)",
                    borderRadius: "3px",
                    overflow: "hidden",
                  }}>
                    <div style={{
                      height: "100%",
                      width: `${pct}%`,
                      background: "linear-gradient(90deg, #a87838, #d4a256)",
                      transition: "width 0.8s ease",
                    }} />
                  </div>
                  <div style={{
                    textAlign: "right",
                    color: "#8a6d47",
                    fontSize: "0.72rem",
                    fontStyle: "italic",
                    marginTop: "3px",
                  }}>
                    {xpInfo.current} / {xpInfo.needed}
                  </div>
                </div>
              );
            })()}

            <div className="flex gap-2 justify-center flex-wrap">
              <button
                onClick={() => startGame(level, playerColor)}
                style={{
                  background: "linear-gradient(180deg, #d4a256, #a87838)",
                  border: "none", color: "#1a0f0a",
                  padding: "0.7rem 1.3rem",
                  fontFamily: "'Cormorant Garamond', serif",
                  fontStyle: "italic", fontSize: "1.1rem",
                  fontWeight: 500, borderRadius: "2px", cursor: "pointer",
                }}
                className="flex items-center gap-2 transition-transform hover:scale-105"
              >
                <RotateCcw size={16} /> Play again
              </button>
              <button
                onClick={() => { setReviewIndex(gameLog.length - 1); setReviewOpen(true); }}
                disabled={gameLog.length <= 1}
                style={{
                  background: "transparent",
                  border: "1px solid rgba(212, 162, 86, 0.5)",
                  color: "#d4a256",
                  padding: "0.7rem 1.3rem",
                  fontFamily: "'Cormorant Garamond', serif",
                  fontStyle: "italic", fontSize: "1.1rem",
                  borderRadius: "2px", cursor: "pointer",
                }}
                className="flex items-center gap-2 transition-transform hover:scale-105 disabled:opacity-30"
              >
                <BarChart3 size={15} /> Review
              </button>
              <button
                onClick={backToMenu}
                style={{
                  background: "transparent",
                  border: "1px solid rgba(212, 162, 86, 0.4)",
                  color: "#c9a97a",
                  padding: "0.7rem 1.3rem",
                  fontFamily: "'Cormorant Garamond', serif",
                  fontStyle: "italic", fontSize: "1.1rem",
                  borderRadius: "2px", cursor: "pointer",
                }}
                className="transition-opacity hover:opacity-80"
              >
                Menu
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Post-game review modal */}
      {reviewOpen && gameLog.length > 0 && (
        <ReviewModal
          gameLog={gameLog}
          reviewIndex={reviewIndex}
          setReviewIndex={setReviewIndex}
          playerColor={playerColor}
          onClose={() => setReviewOpen(false)}
        />
      )}

      {/* Drag ghost - floating piece that follows the pointer.
          Only renders once user has moved > 6px so simple taps don't flash a ghost. */}
      {dragging && dragging.hasMoved && (
        <div style={{
          position: "fixed",
          left: dragging.x,
          top: dragging.y,
          transform: "translate(-50%, -50%)",
          zIndex: 100,
          pointerEvents: "none",
          fontSize: PIECE_SETS[pieceSet].fontSize,
          color: colorOf(dragging.piece) === "w" ? PIECE_SETS[pieceSet].whiteColor : PIECE_SETS[pieceSet].blackColor,
          textShadow: colorOf(dragging.piece) === "w" ? PIECE_SETS[pieceSet].whiteShadow : PIECE_SETS[pieceSet].blackShadow,
          fontWeight: PIECE_SETS[pieceSet].weight,
          fontFamily: PIECE_SETS[pieceSet].fontFamily,
          filter: "drop-shadow(0 6px 10px rgba(0,0,0,0.5))",
          opacity: 0.95,
          lineHeight: 1,
        }}>
          {PIECE_SETS[pieceSet].glyphs[dragging.piece]}
        </div>
      )}

      {/* Settings drawer */}
      {settingsOpen && (
        <div
          className="fixed inset-0 z-50"
          onClick={() => setSettingsOpen(false)}
          style={{
            background: "rgba(10, 6, 4, 0.55)",
            backdropFilter: "blur(3px)",
            animation: "fadeIn 0.2s ease-out",
          }}
        >
          <style>{`
            @keyframes fadeIn { from { opacity: 0 } to { opacity: 1 } }
            @keyframes slideIn { from { transform: translateX(100%) } to { transform: translateX(0) } }
            .settings-drawer { animation: slideIn 0.28s cubic-bezier(0.22, 0.61, 0.36, 1); }
          `}</style>
          <div
            className="settings-drawer"
            onClick={(e) => e.stopPropagation()}
            style={{
              position: "absolute",
              top: 0,
              right: 0,
              height: "100%",
              width: "min(360px, 90vw)",
              background: "linear-gradient(180deg, #3a2419 0%, #1a0f0a 100%)",
              borderLeft: "1px solid rgba(212, 162, 86, 0.3)",
              boxShadow: "-15px 0 50px rgba(0, 0, 0, 0.6)",
              padding: "1.5rem 1.25rem",
              overflowY: "auto",
              display: "flex",
              flexDirection: "column",
            }}
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontStyle: "italic",
                color: "#f0d9a8",
                fontSize: "1.6rem",
                lineHeight: 1,
              }}>
                Settings
              </div>
              <button
                onClick={() => setSettingsOpen(false)}
                style={{
                  color: "#c9a97a",
                  background: "transparent",
                  border: "none",
                  cursor: "pointer",
                  padding: "4px",
                  display: "flex",
                }}
                aria-label="Close settings"
              >
                <X size={20} />
              </button>
            </div>

            {/* Game aids section */}
            {/* Appearance section */}
            <SettingsSection title="Appearance">
              <div style={{ color: "#a88860", fontSize: "0.7rem", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: "0.5rem" }}>
                Board theme
              </div>
              <div className="grid grid-cols-2 gap-2 mb-4">
                {Object.entries(BOARD_THEMES).map(([id, t]) => (
                  <button
                    key={id}
                    onClick={() => setBoardTheme(id)}
                    style={{
                      background: boardTheme === id ? "rgba(212, 162, 86, 0.15)" : "rgba(30, 18, 12, 0.5)",
                      border: boardTheme === id ? "1px solid #d4a256" : "1px solid rgba(138, 109, 71, 0.3)",
                      borderRadius: "2px",
                      padding: "0.5rem",
                      cursor: "pointer",
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      gap: "0.35rem",
                    }}
                  >
                    {/* Mini preview */}
                    <div style={{
                      width: "100%", aspectRatio: "2/1",
                      background: t.frame,
                      padding: "3px",
                      borderRadius: "2px",
                      border: `1px solid ${t.frameBorder}`,
                    }}>
                      <div style={{
                        display: "grid",
                        gridTemplateColumns: "repeat(4, 1fr)",
                        gridTemplateRows: "repeat(2, 1fr)",
                        width: "100%", height: "100%",
                      }}>
                        {[0,1,2,3,4,5,6,7].map(i => {
                          const r = Math.floor(i / 4), c = i % 4;
                          return (
                            <div key={i} style={{
                              background: (r + c) % 2 === 0 ? t.light : t.dark,
                            }} />
                          );
                        })}
                      </div>
                    </div>
                    <div style={{
                      fontFamily: "'Cormorant Garamond', serif",
                      fontSize: "0.85rem",
                      color: boardTheme === id ? "#f4d08a" : "#c9a97a",
                      fontStyle: "italic",
                    }}>
                      {t.name}
                    </div>
                  </button>
                ))}
              </div>

              <div style={{ color: "#a88860", fontSize: "0.7rem", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: "0.5rem" }}>
                Piece set
              </div>
              <div className="grid grid-cols-3 gap-2">
                {Object.entries(PIECE_SETS).map(([id, p]) => (
                  <button
                    key={id}
                    onClick={() => setPieceSet(id)}
                    style={{
                      background: pieceSet === id ? "rgba(212, 162, 86, 0.15)" : "rgba(30, 18, 12, 0.5)",
                      border: pieceSet === id ? "1px solid #d4a256" : "1px solid rgba(138, 109, 71, 0.3)",
                      borderRadius: "2px",
                      padding: "0.6rem 0.4rem",
                      cursor: "pointer",
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      gap: "0.3rem",
                    }}
                  >
                    <div style={{
                      fontSize: "1.7rem",
                      fontFamily: p.fontFamily,
                      fontWeight: p.weight,
                      color: "#f0d9a8",
                      lineHeight: 1,
                    }}>
                      {p.glyphs.wN}{p.glyphs.wK}
                    </div>
                    <div style={{
                      fontFamily: "'Cormorant Garamond', serif",
                      fontSize: "0.78rem",
                      color: pieceSet === id ? "#f4d08a" : "#c9a97a",
                      fontStyle: "italic",
                      textAlign: "center",
                    }}>
                      {p.name}
                    </div>
                  </button>
                ))}
              </div>
            </SettingsSection>

            {/* Game aids section */}
            <SettingsSection title="Game Aids">
              <ToggleRow
                label="Show threats"
                description="Highlight your pieces under attack"
                active={showThreats}
                onClick={() => setShowThreats(v => !v)}
                accent="danger"
              />
            </SettingsSection>

            {/* Sound section */}
            <SettingsSection title="Sound">
              <ToggleRow
                label="Piece sounds"
                description="Wooden move and capture clicks"
                active={sfxEnabled}
                onClick={() => { initAudio(); setSfxEnabled(v => !v); }}
              />
              {sfxEnabled && (
                <VolumeSlider
                  label="Effects volume"
                  value={sfxVolume}
                  onChange={setSfxVolume}
                />
              )}
              <ToggleRow
                label="Music"
                description="Ambient background music"
                active={musicEnabled}
                onClick={() => { initAudio(); setMusicEnabled(v => !v); }}
              />
              {musicEnabled && (
                <>
                  <VolumeSlider
                    label="Music volume"
                    value={musicVolume}
                    onChange={setMusicVolume}
                  />
                  <div style={{ marginTop: "0.75rem" }}>
                    <div style={{
                      color: "#a88860", fontSize: "0.7rem",
                      letterSpacing: "0.2em", textTransform: "uppercase",
                      marginBottom: "0.5rem",
                    }}>
                      Style
                    </div>
                    <div className="flex gap-2">
                      {[
                        { id: "relaxing", label: "Relaxing" },
                        { id: "focus", label: "Focus" },
                      ].map(opt => (
                        <button
                          key={opt.id}
                          onClick={() => { initAudio(); setMusicStyle(opt.id); }}
                          style={{
                            flex: 1,
                            background: musicStyle === opt.id ? "linear-gradient(180deg, #d4a256, #a87838)" : "rgba(30, 18, 12, 0.6)",
                            border: "1px solid rgba(138, 109, 71, 0.3)",
                            color: musicStyle === opt.id ? "#1a0f0a" : "#c9a97a",
                            padding: "0.5rem 0.8rem",
                            fontFamily: "'Cormorant Garamond', serif",
                            fontStyle: "italic", fontSize: "0.95rem",
                            borderRadius: "2px", cursor: "pointer",
                          }}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </SettingsSection>

            <div style={{ flex: 1 }} />

            {/* Footer hint */}
            <div style={{
              color: "#6b5537",
              fontSize: "0.78rem",
              fontStyle: "italic",
              textAlign: "center",
              paddingTop: "1rem",
              borderTop: "1px solid rgba(138, 109, 71, 0.2)",
            }}>
              Tap outside to close
            </div>
          </div>
        </div>
      )}

      {/* Level-up modal */}
      {levelUpEvent && (
        <div
          className="fixed inset-0 flex items-center justify-center z-[60] p-4"
          style={{ background: "rgba(10, 6, 4, 0.9)", backdropFilter: "blur(8px)" }}
          onClick={() => setLevelUpEvent(null)}
        >
          <style>{`
            @keyframes levelUpBurst {
              0% { transform: scale(0.6) rotate(-5deg); opacity: 0; }
              60% { transform: scale(1.08) rotate(2deg); opacity: 1; }
              100% { transform: scale(1) rotate(0); opacity: 1; }
            }
            .level-up-burst { animation: levelUpBurst 0.7s cubic-bezier(0.34, 1.56, 0.64, 1); }
            @keyframes shine {
              0%, 100% { opacity: 0.5; }
              50% { opacity: 1; }
            }
            .level-shine { animation: shine 2s ease-in-out infinite; }
          `}</style>
          <div
            className="level-up-burst text-center"
            onClick={(e) => e.stopPropagation()}
            style={{
              background: "linear-gradient(180deg, #4a3424 0%, #1a0f0a 100%)",
              border: "1px solid rgba(244, 208, 138, 0.6)",
              padding: "2.5rem 2rem",
              borderRadius: "4px",
              maxWidth: "460px",
              width: "100%",
              boxShadow: "0 10px 80px rgba(244, 208, 138, 0.25)",
              position: "relative",
              overflow: "hidden",
            }}
          >
            {/* Golden glow backdrop */}
            <div
              className="level-shine"
              style={{
                position: "absolute",
                top: "-40%",
                left: "50%",
                transform: "translateX(-50%)",
                width: "120%",
                height: "100%",
                background: "radial-gradient(ellipse at center, rgba(244, 208, 138, 0.25), transparent 60%)",
                pointerEvents: "none",
              }}
            />
            <div style={{ position: "relative", zIndex: 1 }}>
              <div style={{
                color: "#a88860",
                fontSize: "0.75rem",
                letterSpacing: "0.35em",
                textTransform: "uppercase",
                marginBottom: "0.5rem",
              }}>
                Level Up
              </div>
              <div style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: "clamp(3rem, 10vw, 5rem)",
                color: "#f4d08a",
                fontWeight: 500,
                fontStyle: "italic",
                lineHeight: 1,
                textShadow: "0 2px 30px rgba(244, 208, 138, 0.5)",
              }}>
                {levelUpEvent.levelsGained.length > 1
                  ? `Levels ${levelUpEvent.levelsGained[0].level}–${levelUpEvent.levelsGained[levelUpEvent.levelsGained.length - 1].level}`
                  : `Level ${levelUpEvent.levelsGained[0].level}`}
              </div>

              {/* Nickname reveal - for the highest level reached */}
              {(() => {
                const top = levelUpEvent.levelsGained[levelUpEvent.levelsGained.length - 1];
                return (
                  <div style={{ marginTop: "1.5rem", marginBottom: "1.5rem" }}>
                    <div style={{
                      color: "#a88860",
                      fontSize: "0.7rem",
                      letterSpacing: "0.35em",
                      textTransform: "uppercase",
                      marginBottom: "0.5rem",
                    }}>
                      New Title Earned
                    </div>
                    <div style={{
                      fontFamily: "'Cormorant Garamond', serif",
                      fontStyle: "italic",
                      fontSize: "clamp(1.6rem, 5vw, 2.3rem)",
                      color: "#f0d9a8",
                      fontWeight: 500,
                      lineHeight: 1.2,
                      textShadow: "0 2px 20px rgba(212, 162, 86, 0.3)",
                    }}>
                      “{top.nickname}”
                    </div>
                  </div>
                );
              })()}

              {/* Show all gained if more than one */}
              {levelUpEvent.levelsGained.length > 1 && (
                <div style={{
                  fontSize: "0.85rem",
                  color: "#c9a97a",
                  fontStyle: "italic",
                  marginBottom: "1rem",
                }}>
                  {levelUpEvent.levelsGained.length} titles unlocked this game
                </div>
              )}

              <button
                onClick={() => setLevelUpEvent(null)}
                style={{
                  background: "linear-gradient(180deg, #d4a256, #a87838)",
                  border: "none",
                  color: "#1a0f0a",
                  padding: "0.7rem 2rem",
                  fontFamily: "'Cormorant Garamond', serif",
                  fontStyle: "italic",
                  fontSize: "1.1rem",
                  fontWeight: 500,
                  borderRadius: "2px",
                  cursor: "pointer",
                }}
                className="transition-transform hover:scale-105"
              >
                Continue
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Achievement toasts */}
      {achievementToasts.length > 0 && (
        <div style={{
          position: "fixed",
          top: "1rem",
          left: "50%",
          transform: "translateX(-50%)",
          zIndex: 60,
          display: "flex",
          flexDirection: "column",
          gap: "0.5rem",
          maxWidth: "90vw",
          pointerEvents: "none",
        }}>
          {achievementToasts.map((t, i) => (
            <div
              key={t.id}
              className="modal-in"
              style={{
                background: "linear-gradient(180deg, #3a2419 0%, #1a0f0a 100%)",
                border: "1px solid rgba(212, 162, 86, 0.6)",
                borderRadius: "2px",
                padding: "0.75rem 1.25rem",
                display: "flex",
                alignItems: "center",
                gap: "0.75rem",
                boxShadow: "0 8px 30px rgba(0,0,0,0.6)",
                animationDelay: `${i * 0.15}s`,
                pointerEvents: "auto",
              }}
              onClick={() => setAchievementToasts(prev => prev.filter(a => a.id !== t.id))}
            >
              <span style={{ fontSize: "1.6rem" }}>{t.icon}</span>
              <div>
                <div style={{ color: "#a88860", fontSize: "0.7rem", letterSpacing: "0.2em", textTransform: "uppercase" }}>
                  Achievement Unlocked
                </div>
                <div style={{
                  fontFamily: "'Cormorant Garamond', serif",
                  color: "#f0d9a8",
                  fontSize: "1.1rem",
                  fontStyle: "italic",
                  lineHeight: 1.1,
                }}>
                  {t.name}
                </div>
                <div style={{ color: "#c9a97a", fontSize: "0.82rem", marginTop: "0.1rem" }}>
                  {t.desc}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================================
// Sub-components
// ============================================================

// Quality → visual marker
const QUALITY_META = {
  good:       { icon: "✓", color: "#7ac96d", label: "Good move" },
  inaccuracy: { icon: "?!", color: "#e8c469", label: "Inaccuracy" },
  mistake:    { icon: "?",  color: "#e89344", label: "Mistake" },
  blunder:    { icon: "??", color: "#e85c44", label: "Blunder" },
};

function ReviewModal({ gameLog, reviewIndex, setReviewIndex, playerColor, onClose }) {
  // Keyboard navigation
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "ArrowLeft") setReviewIndex(i => Math.max(0, i - 1));
      else if (e.key === "ArrowRight") setReviewIndex(i => Math.min(gameLog.length - 1, i + 1));
      else if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [gameLog.length, setReviewIndex, onClose]);

  const entry = gameLog[reviewIndex];
  if (!entry) return null;

  // Flip board for display
  const displayBoard = playerColor === "b"
    ? entry.board.slice().reverse().map(r => r.slice().reverse())
    : entry.board;
  const toDisplay = (r, c) => playerColor === "b" ? [7 - r, 7 - c] : [r, c];

  const lastMoveD = entry.lastMove ? {
    from: toDisplay(entry.lastMove.from[0], entry.lastMove.from[1]),
    to: toDisplay(entry.lastMove.to[0], entry.lastMove.to[1]),
  } : null;
  const bestMoveD = entry.bestMove && entry.color === playerColor && entry.quality && entry.quality !== "good" ? {
    from: toDisplay(entry.bestMove.from[0], entry.bestMove.from[1]),
    to: toDisplay(entry.bestMove.to[0], entry.bestMove.to[1]),
  } : null;

  const qualityInfo = entry.quality ? QUALITY_META[entry.quality] : null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col" style={{
      background: "radial-gradient(ellipse at top, #3a2419 0%, #1a0f0a 55%, #0d0605 100%)",
    }}>
      <style>{`
        @keyframes revealBoard {
          from { opacity: 0; transform: scale(0.98); }
          to { opacity: 1; transform: scale(1); }
        }
        .review-board { animation: revealBoard 0.25s ease-out; }
      `}</style>
      <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: "1px solid rgba(138, 109, 71, 0.25)" }}>
        <button
          onClick={onClose}
          className="flex items-center gap-2 transition-opacity hover:opacity-80"
          style={{
            color: "#c9a97a", fontFamily: "'Cormorant Garamond', serif",
            fontStyle: "italic", fontSize: "1.05rem",
            background: "transparent", border: "none", cursor: "pointer",
          }}
        >
          <ChevronLeft size={18} /> Close
        </button>
        <div style={{
          fontFamily: "'Cormorant Garamond', serif",
          color: "#d4a256", fontSize: "1rem",
          letterSpacing: "0.2em", textTransform: "uppercase",
        }}>
          Game Review
        </div>
        <div style={{ width: "4rem" }} />
      </div>

      <div className="flex-1 overflow-auto px-3 md:px-6 py-4">
        <div className="max-w-4xl mx-auto grid md:grid-cols-[1fr_260px] gap-6">
          <div>
            {/* Board */}
            <div className="review-board" style={{
              background: "linear-gradient(135deg, #5a3a1f 0%, #3a2411 100%)",
              padding: "12px", borderRadius: "4px",
              boxShadow: "0 15px 50px rgba(0, 0, 0, 0.7)",
              border: "1px solid rgba(212, 162, 86, 0.3)",
            }}>
              <div style={{
                display: "grid",
                gridTemplateColumns: "repeat(8, 1fr)",
                gridTemplateRows: "repeat(8, 1fr)",
                aspectRatio: "1 / 1",
                width: "100%",
                border: "1px solid rgba(212, 162, 86, 0.4)",
                position: "relative",
                overflow: "hidden",
              }}>
                {displayBoard.flatMap((row, dr) =>
                  row.map((piece, dc) => {
                    const isLight = (dr + dc) % 2 === 0;
                    const isFrom = lastMoveD && lastMoveD.from[0] === dr && lastMoveD.from[1] === dc;
                    const isTo = lastMoveD && lastMoveD.to[0] === dr && lastMoveD.to[1] === dc;
                    const isBestFrom = bestMoveD && bestMoveD.from[0] === dr && bestMoveD.from[1] === dc;
                    const isBestTo = bestMoveD && bestMoveD.to[0] === dr && bestMoveD.to[1] === dc;
                    let bg = isLight ? "#efd9b4" : "#8a5a3c";
                    if (isFrom || isTo) bg = isLight ? "#e8d089" : "#a8823a";
                    return (
                      <div key={`${dr}-${dc}`} style={{
                        background: bg,
                        display: "flex", alignItems: "center", justifyContent: "center",
                        position: "relative", minWidth: 0, minHeight: 0, overflow: "hidden",
                      }}>
                        {piece && (
                          <span style={{
                            fontSize: "clamp(1.6rem, 6vw, 3rem)",
                            lineHeight: 1,
                            display: "inline-block",
                            color: colorOf(piece) === "w" ? "#fdf3dc" : "#1a0a04",
                            textShadow: colorOf(piece) === "w"
                              ? "0 1px 2px rgba(60, 30, 10, 0.8)"
                              : "0 1px 2px rgba(255, 240, 200, 0.35)",
                          }}>
                            {PIECES[piece]}
                          </span>
                        )}
                        {/* Best-move indicator: green dashed ring on from/to */}
                        {(isBestFrom || isBestTo) && (
                          <div style={{
                            position: "absolute", inset: "8%",
                            border: "2px dashed rgba(122, 201, 109, 0.8)",
                            borderRadius: "50%",
                            pointerEvents: "none",
                          }} />
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-between gap-2 mt-4">
              <button
                onClick={() => setReviewIndex(0)}
                disabled={reviewIndex === 0}
                style={reviewBtnStyle(reviewIndex === 0)}
              >
                « Start
              </button>
              <button
                onClick={() => setReviewIndex(i => Math.max(0, i - 1))}
                disabled={reviewIndex === 0}
                style={reviewBtnStyle(reviewIndex === 0)}
              >
                ‹ Prev
              </button>
              <div style={{
                flex: 1,
                textAlign: "center",
                fontFamily: "'Cormorant Garamond', serif",
                color: "#c9a97a",
                fontStyle: "italic",
                fontSize: "0.95rem",
              }}>
                {reviewIndex === 0 ? "Initial position" : `Move ${Math.ceil(reviewIndex / 2)}${entry.color === "w" ? " — White" : " — Black"}`}
              </div>
              <button
                onClick={() => setReviewIndex(i => Math.min(gameLog.length - 1, i + 1))}
                disabled={reviewIndex >= gameLog.length - 1}
                style={reviewBtnStyle(reviewIndex >= gameLog.length - 1)}
              >
                Next ›
              </button>
              <button
                onClick={() => setReviewIndex(gameLog.length - 1)}
                disabled={reviewIndex >= gameLog.length - 1}
                style={reviewBtnStyle(reviewIndex >= gameLog.length - 1)}
              >
                End »
              </button>
            </div>

            {/* Current move info */}
            {entry.san && (
              <div className="mt-4 flex items-center justify-center gap-3 flex-wrap" style={{
                background: "rgba(30, 18, 12, 0.5)",
                border: "1px solid rgba(138, 109, 71, 0.25)",
                padding: "0.75rem 1rem",
                borderRadius: "2px",
              }}>
                <div style={{
                  fontFamily: "'EB Garamond', serif",
                  color: "#e8cfa0",
                  fontSize: "1.2rem",
                }}>
                  {entry.color === "w" ? "White" : "Black"} played{" "}
                  <span style={{ fontWeight: 600, color: "#f0d9a8" }}>{entry.san}</span>
                </div>
                {qualityInfo && entry.color === playerColor && (
                  <div className="flex items-center gap-1.5" style={{
                    background: `${qualityInfo.color}22`,
                    border: `1px solid ${qualityInfo.color}`,
                    padding: "0.25rem 0.6rem",
                    borderRadius: "2px",
                  }}>
                    <span style={{ color: qualityInfo.color, fontWeight: 600 }}>{qualityInfo.icon}</span>
                    <span style={{ color: qualityInfo.color, fontSize: "0.9rem", fontStyle: "italic" }}>
                      {qualityInfo.label}
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Move list */}
          <div style={{
            background: "rgba(30, 18, 12, 0.6)",
            border: "1px solid rgba(138, 109, 71, 0.3)",
            borderRadius: "2px",
            padding: "1rem",
            maxHeight: "70vh",
            overflowY: "auto",
          }}>
            <div style={{
              fontFamily: "'Cormorant Garamond', serif",
              color: "#d4a256",
              fontSize: "0.8rem",
              letterSpacing: "0.2em",
              textTransform: "uppercase",
              marginBottom: "0.75rem",
              paddingBottom: "0.5rem",
              borderBottom: "1px solid rgba(138, 109, 71, 0.3)",
            }}>
              Moves
            </div>
            <div style={{ fontFamily: "'EB Garamond', serif", color: "#e8cfa0", fontSize: "0.92rem" }}>
              {Array.from({ length: Math.ceil((gameLog.length - 1) / 2) }, (_, i) => {
                const wIdx = i * 2 + 1;
                const bIdx = i * 2 + 2;
                const w = gameLog[wIdx];
                const b = gameLog[bIdx];
                return (
                  <div key={i} className="flex items-center py-0.5">
                    <span style={{ color: "#8a6d47", width: "1.8rem", fontStyle: "italic", fontSize: "0.85rem" }}>
                      {i + 1}.
                    </span>
                    {w && (
                      <button
                        onClick={() => setReviewIndex(wIdx)}
                        style={{
                          background: reviewIndex === wIdx ? "rgba(212, 162, 86, 0.2)" : "transparent",
                          border: "none",
                          color: "#e8cfa0",
                          padding: "2px 6px",
                          cursor: "pointer",
                          fontFamily: "inherit",
                          fontSize: "inherit",
                          borderRadius: "2px",
                          display: "inline-flex",
                          alignItems: "center",
                          gap: "3px",
                          minWidth: "4.5rem",
                          textAlign: "left",
                        }}
                      >
                        {w.san}
                        {w.quality && w.color === playerColor && (
                          <span style={{ color: QUALITY_META[w.quality].color, fontSize: "0.75rem" }}>
                            {QUALITY_META[w.quality].icon}
                          </span>
                        )}
                      </button>
                    )}
                    {b && (
                      <button
                        onClick={() => setReviewIndex(bIdx)}
                        style={{
                          background: reviewIndex === bIdx ? "rgba(212, 162, 86, 0.2)" : "transparent",
                          border: "none",
                          color: "#e8cfa0",
                          padding: "2px 6px",
                          cursor: "pointer",
                          fontFamily: "inherit",
                          fontSize: "inherit",
                          borderRadius: "2px",
                          display: "inline-flex",
                          alignItems: "center",
                          gap: "3px",
                          minWidth: "4.5rem",
                          textAlign: "left",
                        }}
                      >
                        {b.san}
                        {b.quality && b.color === playerColor && (
                          <span style={{ color: QUALITY_META[b.quality].color, fontSize: "0.75rem" }}>
                            {QUALITY_META[b.quality].icon}
                          </span>
                        )}
                      </button>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Legend */}
            <div className="mt-4 pt-3" style={{ borderTop: "1px solid rgba(138, 109, 71, 0.3)" }}>
              <div style={{ color: "#a88860", fontSize: "0.7rem", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: "0.5rem" }}>
                Legend
              </div>
              {Object.entries(QUALITY_META).map(([k, v]) => (
                <div key={k} className="flex items-center gap-2 py-0.5" style={{ fontSize: "0.82rem", color: "#c9a97a" }}>
                  <span style={{ color: v.color, fontWeight: 600, width: "1.5rem" }}>{v.icon}</span>
                  {v.label}
                </div>
              ))}
              <div className="mt-2" style={{ fontSize: "0.75rem", color: "#8a6d47", fontStyle: "italic" }}>
                Green rings show the engine's suggested move.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function reviewBtnStyle(disabled) {
  return {
    background: "rgba(30, 18, 12, 0.6)",
    border: "1px solid rgba(138, 109, 71, 0.4)",
    color: "#c9a97a",
    padding: "0.5rem 0.8rem",
    fontFamily: "'Cormorant Garamond', serif",
    fontStyle: "italic",
    fontSize: "0.9rem",
    borderRadius: "2px",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.3 : 1,
    transition: "opacity 0.2s",
  };
}

function SettingsSection({ title, children }) {
  return (
    <div style={{ marginBottom: "1.5rem" }}>
      <div style={{
        fontFamily: "'Cormorant Garamond', serif",
        color: "#d4a256",
        fontSize: "0.72rem",
        letterSpacing: "0.25em",
        textTransform: "uppercase",
        marginBottom: "0.6rem",
        paddingBottom: "0.4rem",
        borderBottom: "1px solid rgba(138, 109, 71, 0.2)",
      }}>
        {title}
      </div>
      {children}
    </div>
  );
}

function ToggleRow({ label, description, active, onClick, accent }) {
  const trackOn = accent === "danger" ? "#b54a3a" : "#d4a256";
  return (
    <button
      onClick={onClick}
      style={{
        width: "100%",
        background: "transparent",
        border: "none",
        color: "inherit",
        padding: "0.6rem 0",
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "1rem",
        textAlign: "left",
      }}
    >
      <div className="min-w-0">
        <div style={{
          fontFamily: "'EB Garamond', serif",
          color: "#f0d9a8",
          fontSize: "1rem",
          lineHeight: 1.2,
        }}>
          {label}
        </div>
        {description && (
          <div style={{
            color: "#a88860",
            fontSize: "0.8rem",
            fontStyle: "italic",
            marginTop: "2px",
          }}>
            {description}
          </div>
        )}
      </div>
      {/* Toggle switch */}
      <div style={{
        width: "2.4rem",
        height: "1.3rem",
        borderRadius: "999px",
        background: active ? trackOn : "rgba(138, 109, 71, 0.3)",
        border: `1px solid ${active ? trackOn : "rgba(138, 109, 71, 0.4)"}`,
        position: "relative",
        transition: "all 0.2s ease",
        flexShrink: 0,
      }}>
        <div style={{
          position: "absolute",
          top: "1px",
          left: active ? "calc(100% - 1.2rem - 1px)" : "1px",
          width: "1.1rem",
          height: "1.1rem",
          borderRadius: "50%",
          background: active ? "#1a0f0a" : "#c9a97a",
          transition: "left 0.2s ease, background 0.2s ease",
        }} />
      </div>
    </button>
  );
}

function VolumeSlider({ label, value, onChange }) {
  const pct = Math.round(value * 100);
  return (
    <div style={{ padding: "0.4rem 0 0.6rem", paddingLeft: "0.2rem" }}>
      <div className="flex items-center justify-between mb-1.5">
        <div style={{
          fontFamily: "'EB Garamond', serif",
          color: "#c9a97a",
          fontSize: "0.85rem",
          fontStyle: "italic",
        }}>
          {label}
        </div>
        <div style={{
          color: "#8a6d47",
          fontSize: "0.75rem",
          fontFamily: "'Cormorant Garamond', serif",
        }}>
          {pct}%
        </div>
      </div>
      <input
        type="range"
        min={0}
        max={100}
        step={1}
        value={pct}
        onChange={(e) => onChange(Number(e.target.value) / 100)}
        style={{
          width: "100%",
          appearance: "none",
          WebkitAppearance: "none",
          background: `linear-gradient(to right, #d4a256 0%, #d4a256 ${pct}%, rgba(138, 109, 71, 0.3) ${pct}%, rgba(138, 109, 71, 0.3) 100%)`,
          height: "3px",
          borderRadius: "2px",
          outline: "none",
          cursor: "pointer",
        }}
        className="volume-slider"
      />
    </div>
  );
}

function formatClock(ms) {
  if (ms === null || ms === undefined) return null;
  const totalSec = Math.ceil(ms / 1000);
  const mins = Math.floor(totalSec / 60);
  const secs = totalSec % 60;
  // Show tenths when under 10 seconds
  if (ms < 10000 && ms > 0) {
    const tenths = Math.floor((ms % 1000) / 100);
    return `${mins}:${String(secs).padStart(2, "0")}.${tenths}`;
  }
  return `${mins}:${String(secs).padStart(2, "0")}`;
}

function PlayerPanel({ name, emoji, color, captured, materialDiff, isActive, thinking, clockMs, pieceSet }) {
  const clockStr = formatClock(clockMs);
  const lowTime = clockMs !== null && clockMs !== undefined && clockMs < 30000;
  const criticalTime = clockMs !== null && clockMs !== undefined && clockMs < 10000;
  const ps = pieceSet || PIECE_SETS.classic;
  return (
    <div className="flex items-center justify-between gap-3 px-3 py-2" style={{
      background: isActive ? "rgba(212, 162, 86, 0.08)" : "rgba(30, 18, 12, 0.4)",
      border: isActive ? "1px solid rgba(212, 162, 86, 0.4)" : "1px solid rgba(138, 109, 71, 0.2)",
      borderRadius: "2px", transition: "all 0.3s ease",
    }}>
      <div className="flex items-center gap-3 min-w-0">
        <div style={{
          width: "2.4rem", height: "2.4rem", borderRadius: "50%",
          background: emoji
            ? "linear-gradient(135deg, #3a2419, #1a0f0a)"
            : (color === "w"
              ? "linear-gradient(135deg, #f8ebcc, #d4b78a)"
              : "linear-gradient(135deg, #2a1a10, #0d0605)"),
          border: "1px solid rgba(212, 162, 86, 0.5)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: emoji ? "1.2rem" : "1.1rem",
          color: color === "w" ? "#3a2419" : "#d4a256", flexShrink: 0,
          lineHeight: 1,
        }}>
          {emoji ? emoji : (color === "w" ? "♔" : "♚")}
        </div>
        <div className="min-w-0">
          <div style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontStyle: "italic", color: "#f0d9a8",
            fontSize: "1.05rem", lineHeight: 1,
          }}>
            {name} {thinking && <span style={{ color: "#d4a256" }}>· thinking</span>}
          </div>
          <div className="flex items-center gap-1 mt-1 flex-wrap" style={{ minHeight: "1.1rem" }}>
            {captured.map((p, i) => (
              <span key={i} style={{
                fontSize: "1rem",
                color: colorOf(p) === "w" ? ps.whiteColor : ps.blackColor,
                textShadow: colorOf(p) === "w" ? ps.whiteShadow : ps.blackShadow,
                fontFamily: ps.fontFamily,
                fontWeight: ps.weight,
                lineHeight: 1,
              }}>
                {ps.glyphs[p]}
              </span>
            ))}
            {materialDiff > 0 && (
              <span style={{ color: "#d4a256", fontSize: "0.85rem", fontStyle: "italic", marginLeft: "0.25rem" }}>
                +{materialDiff}
              </span>
            )}
          </div>
        </div>
      </div>
      {clockStr && (
        <div
          className={criticalTime && isActive ? "clock-critical" : ""}
          style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontWeight: 500,
            fontSize: "1.4rem",
            letterSpacing: "0.05em",
            padding: "0.3rem 0.7rem",
            borderRadius: "2px",
            background: isActive
              ? (criticalTime ? "rgba(232, 92, 68, 0.18)" : "rgba(212, 162, 86, 0.15)")
              : "rgba(30, 18, 12, 0.5)",
            color: criticalTime ? "#e85c44" : lowTime ? "#e8c469" : (isActive ? "#f0d9a8" : "#a88860"),
            border: criticalTime ? "1px solid rgba(232, 92, 68, 0.5)" : "1px solid rgba(138, 109, 71, 0.3)",
            minWidth: "4.5rem",
            textAlign: "center",
            transition: "all 0.3s ease",
            flexShrink: 0,
          }}
        >
          {clockStr}
        </div>
      )}
    </div>
  );
}

const ChessBoard = React.forwardRef(function ChessBoard(
  {
    displayBoard, playerColor, onSquareClick, isSelected, isLegalTarget, isLastMove, isKingInCheck,
    isHintFrom, isHintTo, isThreatened, animatingMove, toDisplayCoord,
    theme, pieceSet,
    onPieceDragStart, onDragOverSquare, onDropSquare,
    draggingFrom,
  },
  ref
) {
  const fileLabels = playerColor === "w" ? files : files.slice().reverse();
  const rankLabels = playerColor === "w" ? ranks : ranks.slice().reverse();
  const th = theme || BOARD_THEMES.classic;
  const ps = pieceSet || PIECE_SETS.classic;

  const renderPiece = (piece, opts = {}) => {
    if (!piece) return null;
    const isWhite = colorOf(piece) === "w";
    const glyph = ps.glyphs[piece];
    return (
      <span style={{
        fontSize: ps.fontSize,
        lineHeight: 1,
        display: "inline-block",
        color: isWhite ? ps.whiteColor : ps.blackColor,
        textShadow: isWhite ? ps.whiteShadow : ps.blackShadow,
        fontWeight: ps.weight,
        fontFamily: ps.fontFamily,
        fontVariantEmoji: "text",
        pointerEvents: "none",
        position: "relative",
        zIndex: 2,
        ...(opts.style || {}),
      }}>
        {glyph}
      </span>
    );
  };

  // For animation: compute display positions
  let animFromD = null, animToD = null, animSecFromD = null, animSecToD = null, animCapturedD = null;
  if (animatingMove) {
    animFromD = toDisplayCoord(animatingMove.from[0], animatingMove.from[1]);
    animToD = toDisplayCoord(animatingMove.to[0], animatingMove.to[1]);
    if (animatingMove.secondary) {
      animSecFromD = toDisplayCoord(animatingMove.secondary.from[0], animatingMove.secondary.from[1]);
      animSecToD = toDisplayCoord(animatingMove.secondary.to[0], animatingMove.secondary.to[1]);
    }
    if (animatingMove.capturedAt) {
      animCapturedD = toDisplayCoord(animatingMove.capturedAt[0], animatingMove.capturedAt[1]);
    }
  }

  return (
    <div style={{
      background: th.frame,
      padding: "14px", borderRadius: "4px",
      boxShadow: "0 15px 50px rgba(0, 0, 0, 0.7), inset 0 1px 0 rgba(255, 255, 255, 0.08)",
      border: `1px solid ${th.frameBorder}`,
    }}>
      <div style={{
        display: "grid",
        gridTemplateColumns: "1.25rem 1fr",
        gridTemplateRows: "1fr 1.25rem",
        gap: "4px",
      }}>
        <div style={{
          display: "grid", gridTemplateRows: "repeat(8, 1fr)",
          color: th.coordColor, fontSize: "0.7rem",
          fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic",
        }}>
          {rankLabels.map((r, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>{r}</div>
          ))}
        </div>

        <div ref={ref} style={{
          display: "grid",
          gridTemplateColumns: "repeat(8, 1fr)",
          gridTemplateRows: "repeat(8, 1fr)",
          aspectRatio: "1 / 1",
          width: "100%",
          border: `1px solid ${th.frameBorder}`,
          position: "relative",
          overflow: "hidden",
        }}>
          {displayBoard.flatMap((row, dr) =>
            row.map((piece, dc) => {
              const isLight = (dr + dc) % 2 === 0;
              const sel = isSelected(dr, dc);
              const legal = isLegalTarget(dr, dc);
              const last = isLastMove(dr, dc);
              const checkSq = isKingInCheck(dr, dc);
              const hintFrom = isHintFrom ? isHintFrom(dr, dc) : false;
              const hintTo = isHintTo ? isHintTo(dr, dc) : false;
              const threat = isThreatened ? isThreatened(dr, dc) : false;
              const hasPiece = !!piece;

              // Hide the origin piece (it's being animated) and the destination piece during animation
              const isAnimSource = animatingMove && animFromD[0] === dr && animFromD[1] === dc;
              const isAnimDest = animatingMove && animToD[0] === dr && animToD[1] === dc;
              const isSecSource = animatingMove && animSecFromD && animSecFromD[0] === dr && animSecFromD[1] === dc;
              const isSecDest = animatingMove && animSecToD && animSecToD[0] === dr && animSecToD[1] === dc;
              const isCapturedSq = animatingMove && animCapturedD && animCapturedD[0] === dr && animCapturedD[1] === dc && !isAnimDest;
              const isDragSource = draggingFrom && draggingFrom[0] === dr && draggingFrom[1] === dc;

              let bg;
              if (isLight) bg = th.light;
              else bg = th.dark;
              if (last) bg = isLight ? th.lastLight : th.lastDark;
              if (sel) bg = isLight ? th.selLight : th.selDark;

              const hideStaticPiece = isAnimSource || isAnimDest || isSecSource || isSecDest || isDragSource;

              const handleDragStart = (e) => {
                if (!onPieceDragStart || !piece) return;
                e.preventDefault?.();
                const pt = e.touches ? e.touches[0] : e;
                onPieceDragStart(dr, dc, pt.clientX, pt.clientY);
              };

              return (
                <div
                  key={`${dr}-${dc}`}
                  onClick={() => onSquareClick(dr, dc)}
                  onMouseDown={handleDragStart}
                  onTouchStart={handleDragStart}
                  onMouseEnter={() => onDragOverSquare && onDragOverSquare(dr, dc)}
                  data-sq={`${dr}-${dc}`}
                  className={checkSq ? "king-check" : ""}
                  style={{
                    background: bg,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    cursor: hasPiece ? "grab" : "pointer", position: "relative",
                    transition: "background 0.15s ease",
                    userSelect: "none",
                    minWidth: 0, minHeight: 0,
                    overflow: "hidden",
                    touchAction: "none",
                  }}
                >
                  {/* Threat marker (pulsing red tint behind piece) */}
                  {threat && (
                    <div
                      className="threat-marker"
                      style={{
                        position: "absolute",
                        inset: 0,
                        background: "radial-gradient(circle, rgba(232, 92, 68, 0.55), rgba(232, 92, 68, 0) 70%)",
                        pointerEvents: "none",
                      }}
                    />
                  )}
                  {piece && !hideStaticPiece && !isCapturedSq && renderPiece(piece)}
                  {/* Animate captured piece fading out - absolute so it can't affect cell layout */}
                  {piece && isCapturedSq && (
                    <span
                      className="piece-capturing"
                      style={{
                        position: "absolute",
                        inset: 0,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        pointerEvents: "none",
                      }}
                    >
                      {renderPiece(piece)}
                    </span>
                  )}
                  {legal && !hasPiece && (
                    <div style={{
                      position: "absolute",
                      width: "28%", height: "28%",
                      borderRadius: "50%",
                      background: "rgba(30, 18, 12, 0.35)",
                      pointerEvents: "none",
                    }} />
                  )}
                  {legal && hasPiece && (
                    <div style={{
                      position: "absolute", inset: "6%",
                      borderRadius: "50%",
                      border: "3px solid rgba(30, 18, 12, 0.4)",
                      pointerEvents: "none",
                    }} />
                  )}
                  {/* Hint: golden ring on from-square, golden dot on to-square */}
                  {hintFrom && (
                    <div
                      className="hint-marker"
                      style={{
                        position: "absolute",
                        inset: "4%",
                        borderRadius: "50%",
                        border: "3px solid #f4d08a",
                        boxShadow: "0 0 16px rgba(244, 208, 138, 0.7)",
                        pointerEvents: "none",
                      }}
                    />
                  )}
                  {hintTo && !hintFrom && (
                    <div
                      className="hint-marker"
                      style={{
                        position: "absolute",
                        width: hasPiece ? "auto" : "32%",
                        height: hasPiece ? "auto" : "32%",
                        inset: hasPiece ? "4%" : "auto",
                        borderRadius: "50%",
                        border: hasPiece ? "3px dashed #f4d08a" : "none",
                        background: hasPiece ? "transparent" : "radial-gradient(circle, #f4d08a, rgba(244, 208, 138, 0) 70%)",
                        boxShadow: hasPiece ? "0 0 16px rgba(244, 208, 138, 0.5)" : "0 0 12px rgba(244, 208, 138, 0.8)",
                        pointerEvents: "none",
                      }}
                    />
                  )}
                </div>
              );
            })
          )}

          {/* Animated sliding piece layer */}
          {animatingMove && (
            <SlidingPiece
              piece={animatingMove.piece}
              from={animFromD}
              to={animToD}
              pieceSet={ps}
            />
          )}
          {animatingMove && animatingMove.secondary && (
            <SlidingPiece
              piece={animatingMove.secondary.piece}
              from={animSecFromD}
              to={animSecToD}
              pieceSet={ps}
            />
          )}
        </div>

        <div />

        <div style={{
          display: "grid", gridTemplateColumns: "repeat(8, 1fr)",
          color: th.coordColor, fontSize: "0.7rem",
          fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic",
        }}>
          {fileLabels.map((f, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>{f}</div>
          ))}
        </div>
      </div>
    </div>
  );
});

// A piece that slides smoothly from one square to another
function SlidingPiece({ piece, from, to, pieceSet }) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const id = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(id);
  }, []);

  const [fromR, fromC] = from;
  const [toR, toC] = to;
  const startX = fromC * 12.5;
  const startY = fromR * 12.5;
  const endX = toC * 12.5;
  const endY = toR * 12.5;

  const x = mounted ? endX : startX;
  const y = mounted ? endY : startY;
  const ps = pieceSet || PIECE_SETS.classic;
  const isWhite = colorOf(piece) === "w";

  return (
    <div
      className="piece-sliding"
      style={{
        position: "absolute",
        left: 0, top: 0,
        width: "12.5%", height: "12.5%",
        transform: `translate(${x * 8}%, ${y * 8}%)`,
        display: "flex", alignItems: "center", justifyContent: "center",
      }}
    >
      <span style={{
        fontSize: ps.fontSize,
        lineHeight: 1,
        color: isWhite ? ps.whiteColor : ps.blackColor,
        textShadow: isWhite ? ps.whiteShadow : ps.blackShadow,
        fontWeight: ps.weight,
        fontFamily: ps.fontFamily,
        filter: "drop-shadow(0 4px 6px rgba(0,0,0,0.4))",
      }}>
        {ps.glyphs[piece]}
      </span>
    </div>
  );
}

// ============================================================
// COORDINATE TRAINING COMPONENT
// ============================================================

function CoordTraining({ onBack, theme, playerColor, profile, onBestScore, initAudio }) {
  const [phase, setPhase] = useState("menu"); // menu | playing | done
  const [orientation, setOrientation] = useState(playerColor || "w");
  const [showCoords, setShowCoords] = useState(false); // training wheels

  const [timeLeft, setTimeLeft] = useState(30);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [targetSquare, setTargetSquare] = useState(null); // [r, c]
  const [feedback, setFeedback] = useState(null); // { square, correct }
  const [roundsAttempted, setRoundsAttempted] = useState(0);

  const ROUND_SECS = 30;
  const th = theme || BOARD_THEMES.classic;

  const pickNewTarget = (avoid) => {
    let r, c;
    do {
      r = Math.floor(Math.random() * 8);
      c = Math.floor(Math.random() * 8);
    } while (avoid && avoid[0] === r && avoid[1] === c);
    setTargetSquare([r, c]);
    setFeedback(null);
  };

  const start = () => {
    initAudio?.();
    setScore(0);
    setStreak(0);
    setRoundsAttempted(0);
    setTimeLeft(ROUND_SECS);
    setFeedback(null);
    pickNewTarget();
    setPhase("playing");
  };

  // Timer
  useEffect(() => {
    if (phase !== "playing") return;
    const start = Date.now();
    const id = setInterval(() => {
      const elapsed = (Date.now() - start) / 1000;
      const remaining = Math.max(0, ROUND_SECS - elapsed);
      setTimeLeft(remaining);
      if (remaining <= 0) {
        clearInterval(id);
        setPhase("done");
      }
    }, 100);
    return () => clearInterval(id);
  }, [phase]);

  // On done, record best
  useEffect(() => {
    if (phase !== "done") return;
    const best = profile?.coordBest ?? 0;
    if (score > best) {
      onBestScore(score);
    }
  }, [phase]); // eslint-disable-line

  const handleSquareTap = (dr, dc) => {
    if (phase !== "playing" || !targetSquare || feedback) return;
    // Convert display coord → logical coord
    const [r, c] = orientation === "b" ? [7 - dr, 7 - dc] : [dr, dc];
    const correct = r === targetSquare[0] && c === targetSquare[1];
    setFeedback({ square: [r, c], correct });
    setRoundsAttempted(n => n + 1);
    if (correct) {
      setScore(s => s + 1);
      setStreak(s => s + 1);
    } else {
      setStreak(0);
    }
    // After brief feedback, pick next target
    setTimeout(() => {
      const prev = targetSquare;
      pickNewTarget(prev);
    }, correct ? 300 : 700);
  };

  const targetName = targetSquare ? files[targetSquare[1]] + ranks[targetSquare[0]] : "";
  const accuracy = roundsAttempted > 0 ? Math.round((score / roundsAttempted) * 100) : 0;
  const best = profile?.coordBest ?? 0;

  const fileLabels = orientation === "w" ? files : files.slice().reverse();
  const rankLabels = orientation === "w" ? ranks : ranks.slice().reverse();

  // Render an empty themed board with optional coord hints + target flash
  const renderBoard = () => (
    <div style={{
      background: th.frame,
      padding: "12px", borderRadius: "4px",
      boxShadow: "0 15px 50px rgba(0, 0, 0, 0.7)",
      border: `1px solid ${th.frameBorder}`,
      maxWidth: "520px",
      margin: "0 auto",
      width: "100%",
    }}>
      <div style={{
        display: "grid",
        gridTemplateColumns: "1.25rem 1fr",
        gridTemplateRows: "1fr 1.25rem",
        gap: "4px",
      }}>
        <div style={{
          display: "grid", gridTemplateRows: "repeat(8, 1fr)",
          color: th.coordColor, fontSize: "0.7rem",
          fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic",
        }}>
          {rankLabels.map((r, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>{r}</div>
          ))}
        </div>
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(8, 1fr)",
          gridTemplateRows: "repeat(8, 1fr)",
          aspectRatio: "1 / 1",
          width: "100%",
          border: `1px solid ${th.frameBorder}`,
          position: "relative",
          overflow: "hidden",
        }}>
          {Array.from({ length: 64 }).map((_, i) => {
            const dr = Math.floor(i / 8);
            const dc = i % 8;
            const [r, c] = orientation === "b" ? [7 - dr, 7 - dc] : [dr, dc];
            const isLight = (dr + dc) % 2 === 0;
            const isFeedback = feedback && feedback.square[0] === r && feedback.square[1] === c;

            let bg = isLight ? th.light : th.dark;
            if (isFeedback) {
              bg = feedback.correct
                ? (isLight ? "#a8d89a" : "#5b8d4f")
                : (isLight ? "#e89a92" : "#a84e44");
            }

            return (
              <div
                key={i}
                onClick={() => handleSquareTap(dr, dc)}
                style={{
                  background: bg,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  cursor: phase === "playing" ? "pointer" : "default",
                  transition: "background 0.2s ease",
                  minWidth: 0, minHeight: 0,
                  position: "relative",
                  userSelect: "none",
                }}
              >
                {showCoords && (
                  <span style={{
                    fontSize: "0.7rem",
                    fontFamily: "'Cormorant Garamond', serif",
                    fontStyle: "italic",
                    color: isLight ? "rgba(0,0,0,0.4)" : "rgba(255,255,255,0.5)",
                    position: "absolute",
                    bottom: "2px",
                    right: "3px",
                    pointerEvents: "none",
                  }}>
                    {files[c]}{ranks[r]}
                  </span>
                )}
              </div>
            );
          })}
        </div>
        <div />
        <div style={{
          display: "grid", gridTemplateColumns: "repeat(8, 1fr)",
          color: th.coordColor, fontSize: "0.7rem",
          fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic",
        }}>
          {fileLabels.map((f, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>{f}</div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div
      className="fixed inset-0 overflow-auto"
      style={{
        background: "radial-gradient(ellipse at top, #3a2419 0%, #1a0f0a 55%, #0d0605 100%)",
        fontFamily: "'EB Garamond', Georgia, serif",
      }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap');
        @keyframes flashTarget {
          from { transform: scale(0.7); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }
        .target-flash { animation: flashTarget 0.3s ease-out; }
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .fade-up { animation: fadeUp 0.6s ease-out both; }
      `}</style>

      <div className="min-h-screen px-4 md:px-6 py-6 max-w-3xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={onBack}
            className="flex items-center gap-2 transition-opacity hover:opacity-80"
            style={{
              color: "#c9a97a",
              fontFamily: "'Cormorant Garamond', serif",
              fontStyle: "italic", fontSize: "1.05rem",
              background: "transparent", border: "none", cursor: "pointer",
            }}
          >
            <ChevronLeft size={18} /> Back
          </button>
          <div style={{
            fontFamily: "'Cormorant Garamond', serif",
            color: "#d4a256", fontSize: "1rem",
            letterSpacing: "0.2em", textTransform: "uppercase",
          }}>
            Coordinate Training
          </div>
          <div style={{ width: "4rem" }} />
        </div>

        {phase === "menu" && (
          <div className="fade-up">
            <div className="text-center mb-8">
              <h2 style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontWeight: 500, fontStyle: "italic",
                color: "#f0d9a8", fontSize: "clamp(2.2rem, 6vw, 3.5rem)",
                lineHeight: 1.1,
                marginBottom: "0.5rem",
              }}>
                Know Your Squares
              </h2>
              <div style={{ color: "#c9a97a", fontSize: "1.05rem", fontStyle: "italic", maxWidth: "28rem", margin: "0 auto" }}>
                A square name will flash. Tap the matching square as fast as you can. You have {ROUND_SECS} seconds.
              </div>
            </div>

            {/* Options */}
            <div className="mb-6 flex flex-col gap-3 max-w-sm mx-auto">
              <div>
                <div style={{ color: "#a88860", fontSize: "0.72rem", letterSpacing: "0.25em", textTransform: "uppercase", marginBottom: "0.5rem" }}>
                  Board orientation
                </div>
                <div className="flex gap-2">
                  {[{id:"w",label:"White"},{id:"b",label:"Black"}].map(opt => (
                    <button
                      key={opt.id}
                      onClick={() => setOrientation(opt.id)}
                      style={{
                        flex: 1,
                        background: orientation === opt.id ? "linear-gradient(180deg, #d4a256, #a87838)" : "rgba(30, 18, 12, 0.6)",
                        border: orientation === opt.id ? "1px solid #d4a256" : "1px solid rgba(138, 109, 71, 0.3)",
                        color: orientation === opt.id ? "#1a0f0a" : "#c9a97a",
                        padding: "0.55rem 0.9rem",
                        fontFamily: "'Cormorant Garamond', serif",
                        fontStyle: "italic", fontSize: "1rem",
                        fontWeight: 500,
                        borderRadius: "2px", cursor: "pointer",
                      }}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
              <button
                onClick={() => setShowCoords(v => !v)}
                style={{
                  background: showCoords ? "rgba(212, 162, 86, 0.15)" : "rgba(30, 18, 12, 0.6)",
                  border: showCoords ? "1px solid #d4a256" : "1px solid rgba(138, 109, 71, 0.3)",
                  color: showCoords ? "#f4d08a" : "#c9a97a",
                  padding: "0.55rem 0.9rem",
                  fontFamily: "'Cormorant Garamond', serif",
                  fontStyle: "italic", fontSize: "0.95rem",
                  borderRadius: "2px", cursor: "pointer",
                }}
              >
                {showCoords ? "✓ " : ""}Show coordinates on squares (training wheels)
              </button>
            </div>

            {best > 0 && (
              <div className="text-center mb-6" style={{
                color: "#d4a256",
                fontFamily: "'Cormorant Garamond', serif",
                fontStyle: "italic",
                fontSize: "1.1rem",
              }}>
                Personal best: <span style={{ color: "#f0d9a8", fontWeight: 500 }}>{best}</span>
              </div>
            )}

            <div className="flex justify-center">
              <button
                onClick={start}
                style={{
                  background: "linear-gradient(180deg, #3a2419 0%, #1a0f0a 100%)",
                  border: "1px solid #d4a256",
                  color: "#f0d9a8",
                  padding: "1rem 2.5rem",
                  fontFamily: "'Cormorant Garamond', serif",
                  fontStyle: "italic",
                  fontSize: "1.3rem",
                  fontWeight: 500,
                  letterSpacing: "0.05em",
                  borderRadius: "2px",
                  cursor: "pointer",
                  boxShadow: "0 4px 20px rgba(212, 162, 86, 0.2)",
                }}
                className="transition-transform hover:scale-105"
              >
                Begin
              </button>
            </div>
          </div>
        )}

        {phase === "playing" && (
          <div>
            {/* HUD */}
            <div className="flex items-center justify-around mb-4" style={{
              background: "rgba(30, 18, 12, 0.5)",
              border: "1px solid rgba(138, 109, 71, 0.25)",
              borderRadius: "2px",
              padding: "0.75rem 1rem",
            }}>
              <HudStat label="Time" value={timeLeft.toFixed(1) + "s"} accent={timeLeft < 5 ? "#e85c44" : "#f0d9a8"} />
              <HudStat label="Score" value={score} />
              <HudStat label="Streak" value={streak} accent={streak >= 5 ? "#f4d08a" : "#f0d9a8"} />
            </div>

            {/* Target coord */}
            <div className="text-center mb-4" style={{ minHeight: "5rem" }}>
              <div style={{ color: "#a88860", fontSize: "0.75rem", letterSpacing: "0.25em", textTransform: "uppercase", marginBottom: "0.4rem" }}>
                Tap this square
              </div>
              <div
                key={targetName}
                className="target-flash"
                style={{
                  fontFamily: "'Cormorant Garamond', serif",
                  fontStyle: "italic",
                  fontSize: "clamp(3rem, 10vw, 5rem)",
                  color: "#f0d9a8",
                  fontWeight: 500,
                  lineHeight: 1,
                  textShadow: "0 2px 20px rgba(212, 162, 86, 0.35)",
                }}
              >
                {targetName}
              </div>
            </div>

            {renderBoard()}
          </div>
        )}

        {phase === "done" && (
          <div className="fade-up text-center">
            <div style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontWeight: 300, letterSpacing: "0.4em", color: "#a88860",
              fontSize: "0.75rem", textTransform: "uppercase", marginBottom: "0.5rem",
            }}>
              Round Complete
            </div>
            <div style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontWeight: 500, fontStyle: "italic",
              color: "#f0d9a8", fontSize: "clamp(3rem, 9vw, 5rem)",
              lineHeight: 1,
              marginBottom: "1.5rem",
              textShadow: "0 2px 20px rgba(212, 162, 86, 0.3)",
            }}>
              {score}
              <span style={{ color: "#8a6d47", fontSize: "1.5rem", fontStyle: "normal" }}> squares</span>
            </div>

            {score > best && (
              <div style={{
                color: "#7ac96d",
                fontStyle: "italic",
                fontSize: "1.1rem",
                marginBottom: "1.25rem",
              }}>
                🏆 New personal best!
              </div>
            )}

            <div className="grid grid-cols-3 gap-2 max-w-md mx-auto mb-6">
              <StatCard label="Score" value={score} />
              <StatCard label="Accuracy" value={accuracy + "%"} />
              <StatCard label="Best" value={Math.max(best, score)} />
            </div>

            <div className="flex gap-3 justify-center flex-wrap">
              <button
                onClick={start}
                style={{
                  background: "linear-gradient(180deg, #d4a256, #a87838)",
                  border: "none", color: "#1a0f0a",
                  padding: "0.75rem 1.5rem",
                  fontFamily: "'Cormorant Garamond', serif",
                  fontStyle: "italic", fontSize: "1.15rem",
                  fontWeight: 500, borderRadius: "2px", cursor: "pointer",
                }}
                className="transition-transform hover:scale-105"
              >
                Play again
              </button>
              <button
                onClick={onBack}
                style={{
                  background: "transparent",
                  border: "1px solid rgba(212, 162, 86, 0.4)",
                  color: "#c9a97a",
                  padding: "0.75rem 1.5rem",
                  fontFamily: "'Cormorant Garamond', serif",
                  fontStyle: "italic", fontSize: "1.15rem",
                  borderRadius: "2px", cursor: "pointer",
                }}
                className="transition-opacity hover:opacity-80"
              >
                Back to menu
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function HudStat({ label, value, accent }) {
  return (
    <div className="text-center">
      <div style={{
        color: "#a88860",
        fontSize: "0.7rem",
        letterSpacing: "0.2em",
        textTransform: "uppercase",
      }}>
        {label}
      </div>
      <div style={{
        fontFamily: "'Cormorant Garamond', serif",
        fontSize: "1.6rem",
        color: accent || "#f0d9a8",
        lineHeight: 1,
        fontWeight: 500,
        transition: "color 0.2s",
      }}>
        {value}
      </div>
    </div>
  );
}

function StatCard({ label, value }) {
  return (
    <div style={{
      background: "rgba(30, 18, 12, 0.6)",
      border: "1px solid rgba(138, 109, 71, 0.3)",
      borderRadius: "2px",
      padding: "1rem 0.6rem",
      textAlign: "center",
    }}>
      <div style={{
        fontFamily: "'Cormorant Garamond', serif",
        fontSize: "2rem",
        color: "#d4a256",
        lineHeight: 1,
        fontWeight: 500,
      }}>
        {value}
      </div>
      <div style={{
        color: "#a88860", fontSize: "0.7rem",
        letterSpacing: "0.2em", textTransform: "uppercase",
        marginTop: "0.3rem",
      }}>
        {label}
      </div>
    </div>
  );
}
