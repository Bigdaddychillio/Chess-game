// Shim for the window.storage API that the chess app uses for persistence.
// In the original Claude artifact environment this is provided by the sandbox;
// on a real website we back it with localStorage so profiles/prefs persist
// across browser sessions on the same device.

(function installStorageShim() {
  if (typeof window === "undefined") return;
  if (window.storage) return; // already provided

  const PREFIX = "chessroom:";

  window.storage = {
    async get(key) {
      try {
        const raw = window.localStorage.getItem(PREFIX + key);
        if (raw === null) return null;
        return { key, value: raw, shared: false };
      } catch (e) {
        console.warn("storage.get failed", e);
        return null;
      }
    },

    async set(key, value) {
      try {
        window.localStorage.setItem(PREFIX + key, String(value));
        return { key, value: String(value), shared: false };
      } catch (e) {
        console.warn("storage.set failed", e);
        return null;
      }
    },

    async delete(key) {
      try {
        window.localStorage.removeItem(PREFIX + key);
        return { key, deleted: true, shared: false };
      } catch (e) {
        console.warn("storage.delete failed", e);
        return null;
      }
    },

    async list(prefix = "") {
      try {
        const keys = [];
        for (let i = 0; i < window.localStorage.length; i++) {
          const k = window.localStorage.key(i);
          if (k && k.startsWith(PREFIX)) {
            const stripped = k.slice(PREFIX.length);
            if (!prefix || stripped.startsWith(prefix)) {
              keys.push(stripped);
            }
          }
        }
        return { keys, prefix, shared: false };
      } catch (e) {
        console.warn("storage.list failed", e);
        return { keys: [] };
      }
    },
  };
})();
