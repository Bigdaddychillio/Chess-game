import React from "react";
import ReactDOM from "react-dom/client";
import ChessApp from "./chess.jsx";
import "./index.css";
import "./storage-shim.js"; // must run before ChessApp mounts

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <ChessApp />
  </React.StrictMode>
);
